<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta tag properties start here -->
  <meta charset="utf-8">

  <meta name="language" content="english">
  <meta http-equiv="content-language" content="en">

  <meta name="google-site-verification" content="qYC3doxIvybN5KSFiBXT8IohYU9A9Wmer1u2CG7h110" />

  <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
  <meta name="robots" content="NOODP">
  <meta name="robots" content="index, follow" />
  <meta name="DC.title" content="Best African Safari & Indian Tiger Safari" >

  <meta name="description" content="Get a comprehensive list of the various species of Birds in India. India has around 1301 species of birds with 26 rare species. Out of the various birds, peacock is the national bird of India. Birds checklist from The Earth Safari." />

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Meta tag properties end here -->
  <title>Birds of India- Checklist: The Earth Safari</title>

  <!-- jQuery library file -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
   
  <base href="" />
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

  <!--[if lt IE 9]>
    <script src="assets/js/html5shiv.js"> </script>
  <![endif]-->
  <link rel="publisher" href="https://plus.google.com/+Theearthsafaritours"/>
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
  <!-- CSS file -->
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="assets/css/slick.css">
  <link rel="stylesheet" type="text/css" media="screen, projection" href="assets/css/main.css" />
  <link rel="stylesheet" href="assets/css/media.css">
</head>

<body class="inner">

<noscript>
<div class="popup-box" style="z-index: 99999999999;"></div>
	<div class="popup-box-container" style="z-index: 99999999999;">
  	<img alt="The Earth Safari" src="assets/img/the-earth-safari-logo.png" style="float:left;" />
    <div class="popup-divider">&nbsp;</div>
    <div class="popup-righ-panel">
    	<span class="popup-heading">Warning!</span>
    	<span class="popup-text">It appears that JavaScript is disabled in your web browser. Please enable it and refresh page to have full system functionality. For instructions on how to enable javascipt in your browser: <a href="http://www.activatejavascript.org/" target="_blank" style="text-decoration: none;" rel="follow" >Click Here</a>.</span>
    </div>
  </div>
</noscript>
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-2 logo"><a href="https://www.theearthsafari.com/"><img src="assets/img/the-earth-safari-logo.png" alt=""/></a></div>
			
			<div class="col-md-10 rightCol">
				<p class="tagline">Inspirational Safaris in India & Africa</p>
				<nav>
					<div class="top">
						<form id="region-selector" name="region_select" action="region.php" method="POST">
							<input type="hidden" name="page" value="http://www.theearthsafari.com/checklist-of-birds-of-india.php">
															<input type="radio" name="r-selector" value="2" id="africa" onclick="this.form.submit()" style="display: none;">
								<label for="africa">Visit Africa</label>
													</form>

						<a class="menuToggle" href="javascript:;"><i class="fa fa-bars"></i></a>
						<ul>
							<li><a href="https://www.theearthsafari.com/">Home</a></li>
							<li><a href="https://www.theearthsafari.com/about-us">About Us</a></li>
							<li><a href="https://www.theearthsafari.com/client-testimonials">Client testimonials</a></li>
							<li><a href="https://www.theearthsafari.com/contact-us">Contact</a></li>
							<li><a href="https://www.theearthsafari.com/blog">Blog</a></li>
							<li><a href="tel:+91 8447870008">CALL: +91 8447870008</a></li>
						</ul>
					</div><!---End of top-->
					
					<div class="exploreDestination">
						<ul  class="exploreLinkks">
														<li>Explore By : </li>
							<li><a href="javascript:;">Destinations</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/destination/ranthambore-national-park">Ranthambore National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/bandhavgarh-national-park">Bandhavgarh National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kanha-national-park">Kanha National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/pench-national-park">Pench National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/tadoba-andhari-tiger-reserve">Tadoba-Andhari Tiger Reserve</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/jim-corbett-national-park">Jim Corbett National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/gir-forest-national-park">Gir Forest National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kaziranga-national-park">Kaziranga National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/sunderbans-national-park">Sunderbans National Park</a></li>
																	</ul>
							</li>
							<li><a href="javascript:;">Interest</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/interest/tiger-safari-india">Tiger Safari India</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-high-end-luxury-safaris">India High End Luxury Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-short-duration-safaris">India Short Duration Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-culture-and-heritage-tours">India Culture and Heritage Tours</a></li>
																	</ul>
							</li>
							<li><a href="https://www.theearthsafari.com/private-safari.php">Private Safari</a></li>
							<li><a href="https://www.theearthsafari.com/group-safari.php">Group Safari</a></li>
						</ul>
					</div><!--end  of exploreDestination-->
				</nav>
			</div>
		</div><!-- End of row -->
	</div><!-- End of container-->
</header>

<section class="masterSection staticPage">
	<div class="container">
		<div class="grayBg margin-top-50">
			<div class="row safariList">
				<div class="col-md-9">
					<div class="title"><h2>Checklist of Birds of India</h2></div>
					
					<p class="profilePic"><img src="assets/img/checklist-of-birds.jpg" alt=""/></p>
					<p>This is a list of the bird species recorded in India. The avifauna of India includes around 1301 species of which 42 are endemic, 1 has been introduced by humans and 26 are rare or accidental. One species has been extirpated in India and 82 species are globally threatened. The Indian Peacock (Pavo cristatus) is the national bird of India.</p>
					<p>More recent birds discovered in India include the Bugun liocichla which was discovered in Arunachal Pradesh in 2006. Besides this, a few birds are considered to be extinct which have been rediscovered as an example being the Jerdon's Courser. Some others have been elevated from subspecies to full species.</p>
					<p>This list's taxonomic treatment (designation and sequence of orders, families and species) and nomenclature (common and scientific names) are based on Clement's 5th edition but include more recent revisions. The family accounts at the beginning of each heading reflect this taxonomy, as do the species counts found in each family account.</p>
					<p>The following tags have been used to highlight certain relevant categories. It must be noted that not all species fall into one of these categories. Those that do not, are commonly occurring native species.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Symbols used:</h5>
					<ul class="bulletPoints">
						<li>R = widespread resident</li>
						<li>r = very local resident</li>
						<li>W = widespread winter visitor</li>
						<li>w = sparse winter visitor</li>
						<li>P = widespread migrant</li>
						<li>p = sparse migrant</li> 	 	
						<li>V = vagrant or irregular visitor</li>
						<li>I = introduced resident</li>
						<li>(Ex) = extinct</li>
						<li>? = requires status confirmation</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: CRACIFORMES</h5>
					<h6>Family: Megapodiidae</h6>
					<p>Nicobar Scrubfowl r Megapodius nicobariensis</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: GALLIFORMES</h5>
					<h6>Family: Phasianidae</h6>
					<ul class="bulletPoints">
						<li>Snow Partridge r Lerwa lerwa</li>
						<li>Tibetan Snowcock r Tetraogallus tibetanus</li>
						<li>Himalayan Snowcock r Tetraogallus himalayensis</li>
						<li>Buff-throated Partridge ? Tetraophasis szechenyii</li>
						<li>Chukar R Alectoris chukar</li>
						<li>Black Francolin R Francolinus francolinus</li>
						<li>Painted Francolin R Francolinus pictus</li>
						<li>Chinese Francolin r Francolinus pintadeanus</li>
						<li>Grey Francolin R Francolinus pondicerianus</li>
						<li>Swamp Francolin r Francolinus gularis</li>
						<li>Tibetan Partridge r Perdix hodgsoniae</li>
						<li>Common Quail rw Coturnix coturnix</li>
						<li>Japanese Quail w Coturnix japonica</li>
						<li>Rain Quail r Coturnix coromandelica</li>
						<li>Blue-breasted Quail r Coturnix chinensis</li>
						<li>Rock Bush Quail R Perdicula argoondahJungle Bush Quail R Perdicula asiatica</li>
						<li>Painted Bush Quail r Perdicula erythrorhyncha</li>
						<li>Manipur Bush Quail r Perdicula manipurensis</li>
						<li>Small Buttonquail R Turnix sylvatica</li>
						<li>Yellow-legged Buttonquail R Turnix tanki</li>
						<li>Barred Buttonquail R Turnix suscitator</li>
						<li>Hill Partridge r Arborophila torqueola</li>
						<li>Rufous-throated Partridge r Arborophila rufogularis</li>
						<li>White-cheeked Partridge r Arborophila atrogularis</li>
						<li>Chestnut-breasted Partridge r Arborophila mandellii</li>
						<li>Mountain Bamboo Partridge r Bambusicola fytchi</li>
						<li>Red Spurfowl r Galloperdix spadicea</li>
						<li>Painted Spurfowl r Galloperdix lunulata</li>
						<li>Himalayan Quail (Ex) Ophrysia superciliosa</li>
						<li>Blood Pheasant r Ithaginis cruentus</li>
						<li>Western Tragopan r Tragopan melanocephalu</li>
						<li>Satyr Tragopan r Tragopan satyra</li>
						<li>Blyth’s Tragopan r Tragopan blythii</li>
						<li>Temminck’s Tragopan r Tragopan temminckii</li>
						<li>Koklass Pheasant r Pucrasia macrolopha</li>
						<li>Himalayan Monal r Lophophorus impejanus</li>
						<li>Sclater’s Monal r Lophophorus sclateri</li>
						<li>Red Junglefowl R Gallus gallus</li>
						<li>Grey Junglefowl R Gallus sonneratii</li>
						<li>Kalij Pheasant R Lophura leucomelanos</li>
						<li>Tibetan Eared Pheasant ? Crossoptilon</li>
						<li>Cheer Pheasant r Catreus wallichii</li>
						<li>Mrs Hume’s Pheasant r Syrmaticus humiae</li>
						<li>Grey Peacock Pheasant r Polyplectron bicalcaratum</li>
						<li>Indian Peafowl R Pavo cristatus</li>
						<li>Green Peafowl r Pavo muticus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: ANSERIFORMES</h5>
					<h6>Family: Dendrocygndiae</h6>
					<ul class="bulletPoints">
						<li>Fulvous Whistling-duck r Dendrocygna bicolor</li>
						<li>Lesser Whistling-duck R Dendrocygna javanica</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Family: Anatidae</h5>
					<ul class="bulletPoints">
						<li>Oxyurinae</li>
						<li>White-headed Duck V Oxyura leucocephala</li>
						<li>Cygninae</li>
						<li>Mute Swan V Cygnus olor</li>
						<li>Whooper Swan V Cygnus cygnus</li>
						<li>Tundra Swan V Cygnus columbianus</li>
						<li>Anatinae</li>
						<li>Anserini</li>
						<li>Bean Goose V Anser fabalis</li>
						<li>Greater White-fronted Goose V Anser albifrons</li>
						<li>Lesser White-fronted Goose V Anser erythropus</li>
						<li>Greylag Goose W Anser anser</li>
						<li>Bar-headed Goose rw Anser indicus</li>
						<li>Snow Goose ? Anser caerulescens</li>
						<li>Red-breasted Goose ? Branta ruficollis</li>
						<li>Ruddy Shelduck RW Tadorna ferruginea</li>
						<li>Common Shelduck w Tadorna tadorna</li>
						<li>White-winged Duck r Cairina scutulata</li>
						<li>Comb Duck r Sarkidiornis melanotos</li>
						<li>Cotton Pygmy-goose r Nettapus coromandelianus</li>
						<li>Anatini</li>
						<li>Mandarin Duck V Aix galericulata</li>
						<li>Gadwall W Anas strepera</li>
						<li>Falcated Duck V Anas falcata</li>
						<li>Eurasian Wigeon W Anas penelope</li>
						<li>Mallard rW Anas platyrhynchos</li>
						<li>Spot-billed Duck R Anas poecilorhyncha</li>
						<li>Northern Shoveler W Anas clypeata</li>
						<li>Sunda Teal r Anas gibberifrons</li>
						<li>Northern Pintail W Anas acuta</li>
						<li>Garganey W Anas querquedula</li>
						<li>Baikal Teal V Anas formosa</li>
						<li>Common Teal W Anas crecca</li>
						<li>Marbled Duck V Marmaronetta angustirostris</li>
						<li>Pink-headed Duck (Ex) Rhodonessa caryophyllacea</li>
						<li>Red-crested Pochard w Rhodonessa rufina</li>
						<li>Common Pochard W Aythya ferina</li>
						<li>Ferruginous Pochard w Aythya nyroca</li>
						<li>Baer’s Pochard w Aythya baeri</li>
						<li>Tufted Duck W Aythya fuligula</li>
						<li>Greater Scaup V Aythya marila</li>
						<li>Long-tailed Duck V Clangula hyemalis</li>
						<li>Common Goldeneye V Bucephala clangula</li>
						<li>Smew w Mergellus albellus</li>
						<li>Red-breasted Merganser V Mergus serrator</li>
						<li>Common Merganser RW Mergus merganser</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: TURNICIFORMES</h5>
					<h6>Family: Turnicidae </h6>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: PICIFORMES</h5>
					<h6>Family: Indicatoridae</h6>
					<ul class="bulletPoints">
						<li>Yellow-rumped Honeyguide r Indicator xanthonotus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Picidae </h6>
					<ul class="bulletPoints">
						<li>Eurasian Wryneck sw Jynx torquilla</li>
						<li>Speckled Piculet r Picumnus innominatus</li>
						<li>White-browed Piculet r Sasia ochracea</li>
						<li>Rufous Woodpecker R Celeus brachyurus</li>
						<li>White-bellied Woodpecker r Dryocopus javensis</li>
						<li>Andaman Woodpecker r Dryocopus hodgei</li>
						<li>Pale-headed Woodpecker r Gecinulus grantia</li>
						<li>Bay Woodpecker r Blythipicus pyrrhotis</li>
						<li>Heart-spotted Woodpecker r Hemicircus canente</li>
						<li>Great Slaty Woodpecker r Mulleripicus pulverulentus</li>
						<li>Brown-capped Pygmy Woodpecker R Dendrocopos nanus</li>
						<li>Grey-capped Pygmy Woodpecker R Dendrocopos canicapillus</li>
						<li>Brown-fronted Woodpecker R Dendrocopos auriceps</li>
						<li>Fulvous-breasted Woodpecker R Dendrocopos macei</li>
						<li>Stripe-breasted Woodpecker r Dendrocopos atratus</li>
						<li>Yellow-crowned Woodpecker R Dendrocopos mahrattensis</li>
						<li>Rufous-bellied Woodpecker r Dendrocopos hyperythrus</li>
						<li>Crimson-breasted Woodpecker r Dendrocopos cathpharius</li>
						<li>Darjeeling Woodpecker R Dendrocopos darjellensis</li>
						<li>Great Spotted Woodpecker R Dendrocopos major</li>
						<li>Himalayan Woodpecker R Dendrocopos himalayensis</li>
						<li>Lesser Yellownape R Picus chlorolophus</li>
						<li>Greater Yellownape R Picus flavinucha</li>
						<li>Streak-throated Woodpecker R Picus xanthopygaeus</li>
						<li>Scaly-bellied Woodpecker R Picus squamatus</li>
						<li>Grey-headed Woodpecker R Picus canus</li>
						<li>Himalayan Flameback R Dinopium shorii</li>
						<li>Common Flameback R Dinopium javanense</li>
						<li>Black-rumped Flameback R Dinopium benghalense</li>
						<li>Greater Flameback R Chrysocolaptes lucidus</li>
						<li>White-naped Woodpecker r Chrysocolaptes festivus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Megalaimidae </h6>
					<ul class="bulletPoints">
						<li>Great Barbet R Megalaima virens</li>
						<li>Brown-headed Barbet R Megalaima zeylanica</li>
						<li>Lineated Barbet R Megalaima lineata</li>
						<li>White-cheeked Barbet R Megalaima viridis</li>
						<li>Golden-throated Barbet r Megalaima franklinii</li>
						<li>Blue-throated Barbet R Megalaima asiatica</li>
						<li>Blue-eared Barbet r Megalaima australis</li>
						<li>Crimson-fronted Barbet r Megalaima rubricapilla</li>
						<li>Coppersmith Barbet R Megalaima haemacephala</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: BUCEROTIFORMES</h5>
					<h6>Family: Bucerotidae </h6>
					<ul class="bulletPoints">
						<li>Malabar Grey Hornbill R Ocyceros griseus</li>
						<li>Indian Grey Hornbill R Ocyceros birostris</li>
						<li>Malabar Pied Hornbill r Anthracoceros coronatus</li>
						<li>Oriental Pied Hornbill r Anthracoceros albirostris</li>
						<li>Great Hornbill R Buceros bicornis</li>
						<li>Brown Hornbill r Anorrhinus tickelli</li>
						<li>Rufous-necked Hornbill r Aceros nipalensis</li>
						<li>Wreathed Hornbill r Aceros undulatus</li>
						<li>Narcondam Hornbill r Aceros narcondami</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: UPUPIFORMES</h5>
					<h6>Family: Upupidae </h6>
					<ul class="bulletPoints">
						<li>Common Hoopoe RW Upupa epops</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: TROGONIFORMES</h5>
					<h6>Family: Trogonidae </h6>
					<ul class="bulletPoints">
						<li>Malabar Trogon r Harpactes fasciatus</li>
						<li>Red-headed Trogon r Harpactes erythrocephalus</li>
						<li>Ward’s Trogon r Harpactes wardi</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: CORACIIFORMES</h5>
					<h6>Family: Coraciidae</h6>
					<ul class="bulletPoints">
						<li>European Roller rp Coracias garrulus</li>
						<li>Indian Roller R Coracias benghalensis</li>
						<li>Dollarbird r Eurystomus orientalis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Alcedinidae </h6>
					<ul class="bulletPoints">
						<li>Blyth’s Kingfisher r Alcedo hercules</li>
						<li>Common Kingfisher R Alcedo atthis</li>
						<li>Blue-eared Kingfisher r Alcedo meninting</li>
						<li>Oriental Dwarf Kingfisher r Ceyx erithacus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Halcyonidae </h6>
					<ul class="bulletPoints">
						<li>Brown-winged Kingfisher r Halcyon amauroptera</li>
						<li>Stork-billed Kingfisher R Halcyon capensis</li>
						<li>Ruddy Kingfisher r Halcyon coromanda</li>
						<li>White-throated Kingfisher R Halcyon smyrnensis</li>
						<li>Black-capped Kingfisher R Halcyon pileata</li>
						<li>Collared Kingfisher r Todiramphus chloris</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Cerylidae </h6>
					<ul class="bulletPoints">
						<li>Crested Kingfisher R Megaceryle lugubris</li>
						<li>Pied Kingfisher R Ceryle rudis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Meropidae </h6>
					<ul class="bulletPoints">
						<li>Blue-bearded Bee-eater r Nyctyornis athertoni</li>
						<li>Green Bee-eater R Merops orientalis</li>
						<li>Blue-cheeked Bee-eater PS Merops persicus</li>
						<li>Blue-tailed Bee-eater R Merops philippinus</li>
						<li>European Bee-eater sP Merops apiaster</li>
						<li>Chestnut-headed Bee-eater R Merops leschenaulti</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: CUCULIFORMES</h5>
					<h6>Family: Cuculidae </h6>
					<ul class="bulletPoints">
						<li>Pied Cuckoo rS Clamator jacobinus</li>
						<li>Chestnut-winged Cuckoo r Clamator coromandus</li>
						<li>Large Hawk Cuckoo r Hierococcyx sparverioides</li>
						<li>Common Hawk Cuckoo R Hierococcyx varius</li>
						<li>Hodgson’s Hawk Cuckoo r Hierococcyx fugax</li>
						<li>Indian Cuckoo R Cuculus micropterus</li>
						<li>Eurasian Cuckoo R Cuculus canorus</li>
						<li>Oriental Cuckoo r Cuculus saturatus</li>
						<li>Lesser Cuckoo r Cuculus poliocephalus</li>
						<li>Banded Bay Cuckoo r Cacomantis sonneratii</li>
						<li>Grey-bellied Cuckoo r Cacomantis passerinus</li>
						<li>Plaintive Cuckoo r Cacomantis merulinus</li>
						<li>Asian Emerald Cuckoo r Chrysococcyx maculatus</li>
						<li>Violet Cuckoo r Chrysococcyx xanthorhynchus</li>
						<li>Drongo Cuckoo r Surniculus lugubris</li>
						<li>Asian Koel R Eudynamys scolopacea</li>
						<li>Green-billed Malkoha r Phaenicophaeus tristis</li>
						<li>Blue-faced Malkoha r Phaenicophaeus viridirostris</li>
						<li>Sirkeer Malkoha r Phaenicophaeus leschenaultii</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Centropodidae </h6>
					<ul class="bulletPoints">
						<li>Greater Coucal R Centropus sinensis</li>
						<li>Brown Coucal r Centropus andamanensis</li>
						<li>Lesser Coucal r Centropus bengalensis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: PSITTACIFORMES</h5>
					<h6>Family: Psittacidae </h6>
					<ul class="bulletPoints">
						<li>Vernal Hanging Parrot R Loriculus vernalis</li>
						<li>Alexandrine Parakeet R Psittacula eupatria</li>
						<li>Rose-ringed Parakeet R Psittacula krameri</li>
						<li>Slaty-headed Parakeet R Psittacula himalayana</li>
						<li>Grey-headed Parakeet R Psittacula finschii</li>
						<li>Plum-headed Parakeet R Psittacula cyanocephala</li>
						<li>Blossom-headed Parakeet R Psittacula roseata</li>
						<li>Malabar Parakeet R Psittacula columboides</li>
						<li>Derbyan Parakeet ? Psittacula derbiana</li>
						<li>Red-breasted Parakeet R Psittacula alexandri</li>
						<li>Nicobar Parakeet r Psittacula caniceps</li>
						<li>Long-tailed Parakeet R Psittacula longicauda</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: APODIFORMES</h5>
					<h6>Family: Apodidae </h6>
					<ul class="bulletPoints">
						<li>Glossy Swiftlet R Collocalia esculenta</li>
						<li>Indian Swiftlet R Collocalia unicolor</li>
						<li>Himalayan Swiftlet R Collocalia brevirostris</li>
						<li>Edible-nest Swiftlet R Collocalia fuciphaga</li>
						<li>White-rumped Needletail R Zoonavena sylvatica</li>
						<li>White-throated Needletail s Hirundapus caudacutus</li>
						<li>Silver-backed Needletail r Hirundapus cochinchinensis</li>
						<li>Brown-backed Needletail R Hirundapus giganteus</li>
						<li>Asian Palm Swift R Cypsiurus balasiensis</li>
						<li>Alpine Swift r Tachymarptis melba</li>
						<li>Common Swift W Apus apus</li>
						<li>Fork-tailed Swift r Apus pacificus</li>
						<li>Dark-rumped Swift r Apus acuticauda</li>
						<li>House Swift R Apus affinis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Hemiprocnidae </h6>
					<ul class="bulletPoints">
						<li>Crested Treeswift R Hemiprocne coronata</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: STRIGIFORMES</h5>
					<h6>Family: Tytonidae</h6>
					<ul class="bulletPoints">
						<li>Barn Owl r Tyto alba</li>
						<li>Andaman Masked Owl r Tyto deroepstorffi</li>
						<li>Grass Owl r Tyto capensis</li>
						<li>Oriental Bay Owl r Phodilus badius</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Strigidae </h6>
					<ul class="bulletPoints">
						<li>Andaman Scops Owl r Otus balli</li>
						<li>Mountain Scops Owl r Otus spilocephalus</li>
						<li>Pallid Scops Owl r Otus brucei</li>
						<li>Eurasian Scops Owl w Otus scops</li>
						<li>Moluccan Scops Owl ? Otus magicus</li>
						<li>Oriental Scops Owl R Otus sunia</li>
						<li>Collared Scops Owl R Otus bakkamoena</li>
						<li>Eurasian Eagle Owl R Bubo bubo</li>
						<li>Rock Eagle Owl R Bubo bengalensis</li>
						<li>Spot-bellied Eagle Owl r Bubo nipalensis</li>
						<li>Dusky Eagle Owl R Bubo coromandus</li>
						<li>Brown Fish Owl r Ketupa zeylonensis</li>
						<li>Tawny Fish Owl r Ketupa flavipes</li>
						<li>Buffy Fish Owl r Ketupa ketupu</li>
						<li>Mottled Wood Owl r Strix ocellata</li>
						<li>Brown Wood Owl r Strix leptogrammica</li>
						<li>Tawny Owl r Strix aluco</li>
						<li>Collared Owlet r Glaucidium brodiei</li>
						<li>Asian Barred Owlet r Glaucidium cuculoides</li>
						<li>Jungle Owlet R Glaucidium radiatum</li>
						<li>Little Owl r Athene noctua</li>
						<li>Spotted Owlet R Athene brama</li>
						<li>Forest Owlet r Athene blewitti</li>
						<li>Boreal Owl V Aegolius funereus</li>
						<li>Brown Hawk Owl r Ninox scutulata</li>
						<li>Andaman Hawk Owl r Ninox affinis</li>
						<li>Long-eared Owl rw Asio otus</li>
						<li>Short-eared Owl w Asio flammeus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Batrachostomidae </h6>
					<ul class="bulletPoints">
						<li>Sri Lanka Frogmouth r Batrachostomus moniliger</li>
						<li>Hodgson’s Frogmouth r Batrachostomus hodgsoni</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Eurostopodidae</h6>
					<ul class="bulletPoints">
						<li>Great Eared Nightjar r Eurostopodus macrotis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Caprimulgidae</h6>
					<ul class="bulletPoints">
						<li>Grey Nightjar R Caprimulgus indicus</li>
						<li>Eurasian Nightjar rp Caprimulgus europaeus</li>
						<li>Sykes’s Nightjar r Caprimulgus mahrattensis</li>
						<li>Large-tailed Nightjar R Caprimulgus macrurus</li>
						<li>Jerdon’s Nightjar R Caprimulgus atripennis</li>
						<li>Indian Nightjar R Caprimulgus asiaticus</li>
						<li>Savanna Nightjar r Caprimulgus affinis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: COLUMBIFORMES</h5>
					<h6>Family: Columbidae </h6>
					<ul class="bulletPoints">
						<li>Rock Pigeon R Columba livia</li>
						<li>Hill Pigeon R Columba rupestris</li>
						<li>Snow Pigeon R Columba leuconota</li>
						<li>Yellow-eyed Pigeon w Columba eversmanni</li>
						<li>Common Wood Pigeon w Columba palumbus</li>
						<li>Speckled Wood Pigeon r Columba hodgsonii</li>
						<li>Ashy Wood Pigeon r Columba pulchricollis</li>
						<li>Nilgiri Wood Pigeon r Columba elphinstonii</li>
						<li>Pale-capped Pigeon w Columba punicea</li>
						<li>Andaman Wood Pigeon r Columba palumboides</li>
						<li>European Turtle Dove V Streptopelia turtur</li>
						<li>Oriental Turtle Dove RW Streptopelia orientalis</li>
						<li>Laughing Dove R Streptopelia senegalensis</li>
						<li>Spotted Dove R Streptopelia chinensis</li>
						<li>Red Collared Dove R Streptopelia tranquebarica</li>
						<li>Eurasian Collared Dove R Streptopelia decaocto</li>
						<li>Barred Cuckoo Dove r Macropygia unchall</li>
						<li>Andaman Cuckoo Dove r Macropygia rufipennis</li>
						<li>Emerald Dove R Chalcophaps indica</li>
						<li>Nicobar Pigeon r Caloenas nicobarica</li>
						<li>Orange-breasted Green Pigeon r Treron bicincta</li>
						<li>Pompadour Green Pigeon r Treron pompadora</li>
						<li>Thick-billed Green Pigeon r Treron curvirostra</li>
						<li>Yellow-footed Green Pigeon R Treron phoenicoptera</li>
						<li>Pin-tailed Green Pigeon r Treron apicauda</li>
						<li>Wedge-tailed Green Pigeon r Treron sphenura</li>
						<li>Green Imperial Pigeon r Ducula aenea</li>
						<li>Mountain Imperial Pigeon r Ducula badia</li>
						<li>Pied Imperial Pigeon r Ducula bicolor</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: GRUIFORMES</h5>
					<h6>Family: Otididae </h6>
					<ul class="bulletPoints">
						<li>Little Bustard V Tetrax tetrax</li>
						<li>Indian Bustard r Ardeotis nigriceps</li>
						<li>McQueen’s Bustard w Chlamydotis macqueeni</li>
						<li>Bengal Florican r Houbaropsis bengalensis</li>
						<li>Lesser Florican r Sypheotides indica</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Gruidae </h6>
					<ul class="bulletPoints">
						<li>Siberian Crane w Grus leucogeranus</li>
						<li>Sarus Crane r Grus antigone</li>
						<li>Demoiselle Crane w Grus virgo</li>
						<li>Common Crane w Grus grus</li>
						<li>Black-necked Crane r Grus nigricollis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Columbidae </h6>
					<ul class="bulletPoints">
						<li>Masked Finfoot r Heliopais personata</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Rallidae </h6>
					<ul class="bulletPoints">
						<li>Andaman Crake r Rallina canningi</li>
						<li>Red-legged Crake ? Rallina fasciata</li>
						<li>Slaty-legged Crake r Rallina eurizonoides</li>
						<li>Slaty-breasted Rail r Gallirallus striatus</li>
						<li>Water Rail rw Rallus aquaticus</li>
						<li>Corn Crake ? Crex crex</li>
						<li>Brown Crake r Amaurornis akool</li>
						<li>White-breasted Waterhen R Amaurornis phoenicurus</li>
						<li>Black-tailed Crake r Porzana bicolor</li>
						<li>Little Crake V Porzana parva</li>
						<li>Baillon’s Crake rw Porzana pusilla</li>
						<li>Spotted Crake V Porzana porzana</li>
						<li>Ruddy-breasted Crake r Porzana fusca</li>
						<li>Watercock r Gallicrex cinerea</li>
						<li>Purple Swamphen R Porphyrio porphyrio</li>
						<li>Common Moorhen R Gallinula chloropus</li>
						<li>Common Coot RW Fulica atra</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: CICONIIFORMES</h5>
					<h6>Family: Pteroclidae </h6>
					<ul class="bulletPoints">
						<li>Tibetan Sandgrouse r Syrrhaptes tibetanus</li>
						<li>Pallas’s Sandgrouse V Syrrhaptes paradoxus</li>
						<li>Pin-tailed Sandgrouse w Pterocles alchata</li>
						<li>Chestnut-bellied Sandgrouse r Pterocles exustus</li>
						<li>Spotted Sandgrouse w Pterocles senegallus</li>
						<li>Black-bellied Sandgrouse rw Pterocles orientalis</li>
						<li>Crowned Sandgrouse ? Pterocles coronatus</li>
						<li>Painted Sandgrouse r Pterocles indicus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Scolopacidae </h6>
					<ul class="bulletPoints">
						<li>Scolopacinae</li>
						<li>Eurasian Woodcock rW Scolopax rusticola</li>
						<li>Solitary Snipe r Gallinago solitaria</li>
						<li>Wood Snipe r Gallinago nemoricola</li>
						<li>Pintail Snipe W Gallinago stenura</li>
						<li>Swinhoe’s Snipe w Gallinago megala</li>
						<li>Great Snipe V Gallinago media</li>
						<li>Common Snipe rW Gallinago gallinago</li>
						<li>Jack Snipe w Lymnocryptes minimus</li>
						<li>Tringinae</li>
						<li>Black-tailed Godwit W Limosa limosa</li>
						<li>Bar-tailed Godwit W Limosa lapponica</li>
						<li>Whimbrel W Numenius phaeopus</li>
						<li>Eurasian Curlew W Numenius arquata</li>
						<li>Spotted Redshank W Tringa erythropus</li>
						<li>Common Redshank sW Tringa totanus</li>
						<li>Marsh Sandpiper W Tringa stagnatilis</li>
						<li>Common Greenshank W Tringa nebularia</li>
						<li>Nordmann’s Greenshank ? Tringa guttifer</li>
						<li>Green Sandpiper W Tringa ochropus</li>
						<li>Wood Sandpiper W Tringa glareola</li>
						<li>Terek Sandpiper w Xenus cinereus</li>
						<li>Common Sandpiper sW Actitis hypoleucos</li>
						<li>Grey-tailed Tattler V Heteroscelus brevipes</li>
						<li>Ruddy Turnstone w Arenaria interpres</li>
						<li>Long Billed Dowitcher V Limnodromus scolopaceus</li>
						<li>Asian Dowitcher w Limnodromus semipalmatus</li>
						<li>Great Knot w Calidris tenuirostris</li>
						<li>Red Knot W Calidris canutus</li>
						<li>Sanderling w Calidris alba</li>
						<li>Spoon-billed Sandpiper w Calidris pygmea</li>
						<li>Little Stint W Calidris minuta</li>
						<li>Red-necked Stint w Calidris ruficollis</li>
						<li>Temminck’s Stint W Calidris temminckii</li>
						<li>Long-toed Stint w Calidris subminuta</li>
						<li>Sharp-tailed Sandpiper V Calidris acuminata</li>
						<li>Pectoral Sandpiper V Calidris melanotos</li>
						<li>Dunlin w Calidris alpina</li>
						<li>Curlew Sandpiper W Calidris ferruginea</li>
						<li>Buff-breasted Sandpiper V Tryngites subruficollis</li>
						<li>Broad-billed Sandpiper w Limicola falcinellus</li>
						<li>Ruff W Philomachus pugnax</li>
						<li>Red-necked Phalarope w Phalaropus lobatus</li>
						<li>Red Phalarope V Phalaropus fulicaria</li>
					</ul>
					<p>&nbsp;</p>
				
					<h6>Family: Rostratulidae </h6>
					<ul class="bulletPoints">
						Greater Painted-snipe r Rostratula benghalensis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Jacanidae </h6>
					<ul class="bulletPoints">
						<li>Pheasant-tailed Jacana R Hydrophasianus chirurgus</li>
						<li>Bronze-winged Jacana R Metopidius indicus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Burhinidae </h6>
					<ul class="bulletPoints">
						<li>Eurasian Thick-knee R Burhinus oedicnemus</li>
						<li>Great Thick-knee r Esacus recurvirostris</li>
						<li>Beach Thick-knee r Esacus neglectus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Charadriidae </h6>
					<ul class="bulletPoints">
						<li>Recurvirostrinae</li>
						<li>Haematopodini</li>
						<li>Eurasian Oystercatcher w Haematopus ostralegus</li>
						<li>Recurvirostrini</li>
						<li>Ibisbill r Ibidorhyncha struthersii</li>
						<li>Black-winged Stilt RW Himantopus himantopus</li>
						<li>Pied Avocet rW Recurvirostra avosetta</li>
						<li>Charadriinae</li>
						<li>European Golden Plover V Pluvialis apricaria</li>
						<li>Pacific Golden Plover W Pluvialis fulva</li>
						<li>Grey Plover w Pluvialis squatarola</li>
						<li>Common Ringed Plover w Charadrius hiaticula</li>
						<li>Long-billed Plover w Charadrius placidus</li>
						<li>Little Ringed Plover RW Charadrius dubius</li>
						<li>Kentish Plover RW Charadrius alexandrinus</li>
						<li>Lesser Sand Plover sW Charadrius mongolus</li>
						<li>Greater Sand Plover w Charadrius leschenaultii</li>
						<li>Caspian Plover V Charadrius asiaticus</li>
						<li>Oriental Plover V Charadrius veredus</li>
						<li>Black-fronted Dotterel ? Elseyornis melanops</li>
						<li>Northern Lapwing w Vanellus vanellus</li>
						<li>Yellow-wattled Lapwing r Vanellus malarbaricus</li>
						<li>River Lapwing R Vanellus duvaucelii</li>
						<li>Grey-headed Lapwing w Vanellus cinereus</li>
						<li>Red-wattled Lapwing R Vanellus indicus</li>
						<li>Sociable Lapwing w Vanellus gregarius</li>
						<li>White-tailed Lapwing W Vanellus leucurus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Glareolidae </h6>
					<ul class="bulletPoints">
						<li>Dromadinae</li>
						<li>Crab Plover w Dromas ardeola</li>
						<li>Glareolinae</li>
						<li>Jerdon&#39;s Courser r Rhinoptilus bitorquatus</li>
						<li>Cream-colored Courser rw Cursorius cursor</li>
						<li>Indian Courser r Cursorius coromandelicus</li>
						<li>Collared Pratincole rw Glareola pratincola</li>
						<li>Oriental Pratincole R Glareola maldivarum</li>
						<li>Small Pratincole R Glareola lactea</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Laridae </h6>
					<ul class="bulletPoints">
						<li>Larinae</li>
						<li>Stercorariini</li>
						<li>Brown Skua sp Catharacta antarctica</li>
						<li>South-Polar Skua V Catharacta maccormicki</li>
						<li>Long-tailed Jaeger ? Stercorarius longicaudus</li>
						<li>Pomarine Jaeger W Stercorarius pomarinus</li>
						<li>Parasitic Jaegar W Stercorarius parasiticus</li>
						<li>Rynchopini</li>
						<li>Indian Skimmer r Rynchops albicollis</li>
						<li>Larini</li>
						<li>Yellow-legged Gull w Larus cachinnans</li>
						<li>Armenian Gull ? Larus armenicus</li>
						<li>Heuglin’s Gull w Larus heuglini</li>
						<li>Pallas’s Gull w Larus ichthyaetus</li>
						<li>Mew Gull V Larus canus</li>
						<li>Sooty Gull V Larus hemprichii</li>
						<li>Brown-headed Gull sW Larus brunnicephalus</li>
						<li>Black-headed Gull W Larus ridibundus</li>
						<li>Slender-billed Gull w Larus genei</li>
						<li>Little Gull V Larus minutus</li>
						<li>Sternini</li>
						<li>Gull-billed Tern rW Gelochelidon nilotica</li>
						<li>Caspian Tern W Sterna caspia</li>
						<li>River Tern R Sterna aurantia</li>
						<li>Lesser Crested Tern r Sterna bengalensis</li>
						<li>Great Crested Tern r Sterna bergii</li>
						<li>Sandwich Tern w Sterna sandvicensis</li>
						<li>Roseate Tern r Sterna dougallii</li>
						<li>Black-naped Tern r Sterna sumatrana</li>
						<li>Common Tern sW Sterna hirundo</li>
						<li>Arctic Tern V Sterna paradisaea</li>
						<li>Little Tern r Sterna albifrons</li>
						<li>Saunders’s Tern r Sterna saundersi</li>
						<li>White-cheeked Tern p Sterna repressa</li>
						<li>Black-bellied Tern r Sterna acuticauda</li>
						<li>Bridled Tern s Sterna anaethetus</li>
						<li>Sooty Tern s Sterna fuscata</li>
						<li>Whiskered Tern RW Chlidonias hybridus</li>
						<li>White-winged Tern w Chlidonias leucopterus</li>
						<li>White Tern v Gygis alba</li>
						<li>Black Tern ? Chlidonias niger</li>
						<li>Brown Noddy V Anous stolidus</li>
						<li>Black Noddy V Anous minutus</li>
						<li>Lesser Noddy Anous tenuirostris</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6></h6>Family: Accipitridae 
					<ul class="bulletPoints">
						<li>Pandioninae</li>
						<li>Osprey rW Pandion haliaetus</li>
						<li>Accipitrinae</li>
						<li>Jerdon’s Baza r Aviceda jerdoni</li>
						<li>Black Baza r Aviceda leuphotes</li>
						<li>Oriental Honey-buzzard RW Pernis ptilorhyncus</li>
						<li>Black-shouldered Kite R Elanus caeruleus</li>
						<li>Red Kite ? Milvus milvus</li>
						<li>Black Kite RW Milvus migrans</li>
						<li>Brahminy Kite R Haliastur indus</li>
						<li>White-bellied Sea Eagle R Haliaeetus leucogaster</li>
						<li>Pallas’s Fish Eagle r Haliaeetus leucoryphus</li>
						<li>White-tailed Eagle w Haliaeetus albicilla</li>
						<li>Lesser Fish Eagle r Ichthyophaga humilis</li>
						<li>Grey-headed Fish Eagle r Ichthyophaga ichthyaetus</li>
						<li>Lammergeier r Gypaetus barbatus</li>
						<li>Egyptian Vulture R Neophron percnopterus</li>
						<li>White-rumped Vulture r Gyps bengalensis</li>
						<li>Indian Vulture r Gyps indicus</li>
						<li>Slender-billed Vulture r Gyps tenvirostris</li>
						<li>Himalayan Griffon r Gyps himalayensis</li>
						<li>Eurasian Griffon r Gyps fulvus</li>
						<li>Cinereous Vulture rw Aegypius monachus</li>
						<li>Red-headed Vulture r Sarcogyps calvus</li>
						<li>Short-toed Snake Eagle r Circaetus gallicus</li>
						<li>Crested Serpent Eagle R Spilornis cheela</li>
						<li>Nicobar Serpent Eagle r Spilornis minimus</li>
						<li>Andaman Serpent Eagle r Spilornis elgini</li>
						<li>Eurasian Marsh Harrier W Circus aeruginosus</li>
						<li>Hen Harrier w Circus cyaneus</li>
						<li>Pallid Harrier w Circus macrourus</li>
						<li>Pied Harrier rw Circus melanoleucos</li>
						<li>Montagu’s Harrier w Circus pygargus</li>
						<li>Crested Goshawk r Accipiter trivirgatus</li>
						<li>Shikra R Accipiter badius</li>
						<li>Nicobar Sparrowhawk r Accipiter butleri</li>
						<li>Chinese Sparrowhawk W Accipiter soloensis</li>
						<li>Japanese Sparrowhawk w Accipiter gularis</li>
						<li>Besra r Accipiter virgatus</li>
						<li>Eurasian Sparrowhawk rw Accipiter nisus</li>
						<li>Northern Goshawk rw Accipiter gentilis</li>
						<li>White-eyed Buzzard R Butastur teesa</li>
						<li>Grey-faced Buzzard ? Butastur indicus</li>
						<li>Common Buzzard rw Buteo buteo</li>
						<li>Long-legged Buzzard rW Buteo rufinus</li>
						<li>Upland Buzzard w Buteo hemilasius</li>
						<li>Rough-legged Buzzard ? Buteo lagopus</li>
						<li>Black Eagle r Ictinaetus malayensis</li>
						<li>Indian Spotted Eagle r Aquila hastata</li>
						<li>Greater Spotted Eagle W Aquila clanga</li>
						<li>Tawny Eagle R Aquila rapax</li>
						<li>Steppe Eagle W Aquila nipalensis</li>
						<li>Imperial Eagle w Aquila heliaca</li>
						<li>Golden Eagle r Aquila chrysaetos</li>
						<li>Bonelli’s Eagle r Hieraaetus fasciatus</li>
						<li>Booted Eagle w Hieraaetus pennatus</li>
						<li>Rufous-bellied Eagle r Hieraaetus kienerii</li>
						<li>Changeable Hawk Eagle R Spizaetus cirrhatus</li>
						<li>Mountain Hawk Eagle r Spizaetus nipalensis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Falconidae </h6>
					<ul class="bulletPoints">
						<li>Collared Falconet r Microhierax caerulescens</li>
						<li>Pied Falconet r Microhierax melanoleucus</li>
						<li>Lesser Kestrel p Falco naumanni</li>
						<li>Common Kestrel RW Falco tinnunculus</li>
						<li>Red-necked Falcon r Falco chicquera</li>
						<li>Amur Falcon p Falco amurensis</li>
						<li>Merlin w Falco columbarius</li>
						<li>Eurasian Hobby rp Falco subbuteo</li>
						<li>Oriental Hobby r Falco severus</li>
						<li>Laggar Falcon r Falco jugger</li>
						<li>Saker Falcon w Falco cherrug</li>
						<li>Peregrine Falcon rw Falco peregrinus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Podicipedidae </h6>
					<ul class="bulletPoints">
						<li>Little Grebe R Tachybaptus ruficollis</li>
						<li>Red-necked Grebe W Podiceps grisegena</li>
						<li>Great Crested Grebe rw Podiceps cristatus</li>
						<li>Horned Grebe w Podiceps auritus</li>
						<li>Black-necked Grebe rw Podiceps nigricollis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Phaethontidae </h6>
					<ul class="bulletPoints">
						<li>Red-billed Tropicbird w Phaethon aethereus</li>
						<li>Red-tailed Tropicbird r Phaethon rubricauda</li>
						<li>White-tailed Tropicbird r Phaethon lepturus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Sulidae </h6>
					<ul class="bulletPoints">
						<li>Masked Booby r Sula dactylatra</li>
						<li>Red-footed Booby r Sula sula</li>
						<li>Brown Booby r Sula leucogaster</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Anhingidae </h6>
					<ul class="bulletPoints">
						<li>Darter R Anhinga melanogaster</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Phalacrocoracidae </h6>
					<ul class="bulletPoints">
						<li>Little Cormorant R Phalacrocorax niger</li>
						<li>Indian Cormorant R Phalacrocorax fuscicollis</li>
						<li>Great Cormorant RW Phalacrocorax carbo</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Ardeidae</h6>
					<ul class="bulletPoints">
						<li>Little Egret R Egretta garzetta</li>
						<li>Western Reef Egret R Egretta gularis</li>
						<li>Pacific Reef Egret r Egretta sacra</li>
						<li>Grey Heron RW Ardea cinerea</li>
						<li>Goliath Heron r Ardea goliath</li>
						<li>White-bellied Heron r Ardea insignis</li>
						<li>Great-billed Heron ? Ardea sumatrana</li>
						<li>Purple Heron R Ardea purpurea</li>
						<li>Great Egret RW Casmerodius albus</li>
						<li>Intermediate Egret R Mesophoyx intermedia</li>
						<li>Cattle Egret R Bubulcus ibis</li>
						<li>Indian Pond Heron R Ardeola grayii</li>
						<li>Chinese Pond Heron r Ardeola bacchus</li>
						<li>Little Heron r Butorides striatus</li>
						<li>Black-crowned Night Heron R Nycticorax nycticorax</li>
						<li>Malayan Night Heron r Gorsachius melanolophus</li>
						<li>Little Bittern r Ixobrychus minutus</li>
						<li>Yellow Bittern r Ixobrychus sinensis</li>
						<li>Cinnamon Bittern r Ixobrychus cinnamomeus</li>
						<li>Black Bittern r Dupetor flavicollis</li>
						<li>Great Bittern w Botaurus stellaris</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Phoenicopteridae </h6>
					<ul class="bulletPoints">
						<li>Greater Flamingo rW Phoenicopterus ruber</li>
						<li>Lesser Flamingo r Phoenicopterus minor</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Threskiornithidae </h6>
					<ul class="bulletPoints">
						<li>Glossy Ibis RW Plegadis falcinellus</li>
						<li>Black-headed Ibis R Threskiornis melanocephalus</li>
						<li>Black Ibis R Pseudibis papillosa</li>
						<li>Eurasian Spoonbill RW Platalea leucorodia</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Pelecanidae </h6>
					<ul class="bulletPoints">
						<li>Great White Pelican rW Pelecanus onocrotalus</li>
						<li>Dalmatian Pelican w Pelecanus crispus</li>
						<li>Spot-billed Pelican R Pelecanus philippensis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Ciconiidae</h6>
					<ul class="bulletPoints">
						<li>Painted Stork R Mycteria leucocephala</li>
						<li>Asian Openbill R Anastomus oscitans</li>
						<li>Black Stork w Ciconia nigra</li>
						<li>Woolly-necked Stork R Ciconia episcopus</li>
						<li>White Stork w Ciconia ciconia</li>
						<li>Oriental Stork ? Ciconia boyciana</li>
						<li>Black-necked Stork r Ephippiorhynchus asiaticus</li>
						<li>Lesser Adjutant r Leptoptilos javanicus</li>
						<li>Greater Adjutant r Leptoptilos dubius</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Fregatidae </h6>
					<ul class="bulletPoints">
						<li>Great Frigatebird P Fregata minor</li>
						<li>Lesser Frigatebird r Fregata ariel</li>
						<li>Christmas Island Frigatebird V Fregata andrewsi</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Pelecanidae </h6>
					<ul class="bulletPoints">
						<li>Great White Pelican rW Pelecanus onocrotalus</li>
						<li>Dalmatian Pelican w Pelecanus crispus</li>
						<li>Spot-billed Pelican R Pelecanus philippensis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Gaviidae </h6>
					<ul class="bulletPoints">
						<li>Black-throated Loon V Gavia arctica</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Procellariidae</h6>
					<ul class="bulletPoints">
						<li>Procellariinae</li>
						<li>Cape Petrel V Daption capense</li>
						<li>Barau’s Petrel V Pterodroma baraui</li>
						<li>Bulwer’s Petrel V Bulweria bulwerii</li>
						<li>Jouanin’s Petrel V Bulweria fallax</li>
						<li>Streaked Shearwater V Calonectris leucomelas</li>
						<li>Wedge-tailed Shearwater s Puffinus pacificus</li>
						<li>Flesh-footed Shearwater s Puffinus carneipes</li>
						<li>Audubon’s Shearwater r Puffinus Iherminieri</li>
						<li>Persian Shearwater P Puffinus persicus</li>
						<li>Hydrobatinae</li>
						<li>Wilson’s Storm-petrel P Oceanites oceanicus</li>
						<li>White-faced Storm-petrel V Pelagodroma marina</li>
						<li>Black-bellied Storm-petrel V Fregetta tropica</li>
						<li>Swinhoe’s Storm-petrel p Oceanodroma monorhis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">ORDER: PASSERIFORMES</h5>
					<h6>Family: Pittidae </h6>
					<ul class="bulletPoints">
						<li>Blue-naped Pitta r Pitta nipalensis</li>
						<li>Blue Pitta r Pitta cyanea</li>
						<li>Hooded Pitta r Pitta sordida</li>
						<li>Indian Pitta R Pitta brachyura</li>
						<li>Mangrove Pitta r Pitta megarhyncha</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Eurylaimidae </h6>
					<ul class="bulletPoints">
						<li>Silver-breasted Broadbill r Serilophus lunatus</li>
						<li>Long-tailed Broadbill r Psarisomus dalhousiae</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Irenidae </h6>
					<ul class="bulletPoints">
						<li>Asian Fairy Bluebird r Irena puella</li>
						<li>Blue-winged Leafbird R Chloropsis cochinchinensis</li>
						<li>Golden-fronted Leafbird R Chloropsis aurifrons</li>
						<li>Orange-bellied Leafbird r Chloropsis hardwickii</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Laniidae </h6>
					<ul class="bulletPoints">
						<li>Red-backed Shrike p Lanius collurio</li>
						<li>Rufous-tailed Shrike W Lanius isabellinus</li>
						<li>Brown Shrike W Lanius cristatus</li>
						<li>Burmese Shrike p Lanius collurioides</li>
						<li>Bay-backed Shrike R Lanius vittatus</li>
						<li>Long-tailed Shrike R Lanius schach</li>
						<li>Grey-backed Shrike rW Lanius tephronotus</li>
						<li>Lesser Grey Shrike V Lanius minor</li>
						<li>Great Grey Shrike V Lanius excubitor</li>
						<li>Southern Grey Shrike R Lanius meridionalis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Corvidae </h6>
					<ul class="bulletPoints">
						<li>Pachycephalinae</li>
						<li>Mangrove Whistler r Pachycephala grisola</li>
						<li>Corvinae</li>
						<li>Corvini</li>
						<li>Eurasian Jay R Garrulus glandarius</li>
						<li>Black-headed Jay R Garrulus lanceolatus</li>
						<li>Yellow-billed Blue Magpie R Urocissa flavirostris</li>
						<li>Red-billed Blue Magpie R Urocissa erythrorhyncha</li>
						<li>Common Green Magpie r Cissa chinensis</li>
						<li>Rufous Treepie R Dendrocitta vagabunda</li>
						<li>Grey Treepie R Dendrocitta formosae</li>
						<li>White-bellied Treepie r Dendrocitta leucogastra</li>
						<li>Collared Treepie r Dendrocitta frontalis</li>
						<li>Andaman Treepie R Dendrocitta bayleyi</li>
						<li>Black-billed Magpie r Pica pica</li>
						<li>Hume’s Groundpecker r Pseudopodoces humilis</li>
						<li>Spotted Nutcracker r Nucifraga caryocatactes</li>
						<li>Red-billed Chough R Pyrrhocorax pyrrhocorax</li>
						<li>Yellow-billed Chough R Pyrrhocorax graculus</li>
						<li>Eurasian Jackdaw rw Corvus monedula</li>
						<li>House Crow R Corvus splendens</li>
						<li>Rook w Corvus frugilegus</li>
						<li>Carrion Crow rw Corvus corone</li>
						<li>Large-billed Crow R Corvus macrorhynchos</li>
						<li>Common Raven r Corvus corax</li>
						<li>Artamini</li>
						<li>Ashy Woodswallow R Artamus fuscus</li>
						<li>White-breasted Woodswallow r Artamus leucorynchus</li>
						<li>Oriolini</li>
						<li>Eurasian Golden Oriole R Oriolus oriolus</li>
						<li>Black-naped Oriole rw Oriolus chinensis</li>
						<li>Slender-billed Oriole r Oriolus tenuirostris</li>
						<li>Black-hooded Oriole R Oriolus xanthornus</li>
						<li>Maroon Oriole r Oriolus traillii</li>
						<li>Large Cuckooshrike r Coracina macei</li>
						<li>Bar-bellied Cuckooshrike r Coracina striata</li>
						<li>Black-winged Cuckooshrike r Coracina melaschistos</li>
						<li>Black-headed Cuckooshrike r Coracina melanoptera</li>
						<li>Pied Triller r Lalage nigra</li>
						<li>Rosy Minivet rw Pericrocotus roseus</li>
						<li>Swinhoe&#39;s Minivet ? Pericrocotus cantonensis</li>
						<li>Ashy Minivet w Pericrocotus divaricatus</li>
						<li>Small Minivet R Pericrocotus cinnamomeus</li>
						<li>White-bellied Minivet r Pericrocotus erythropygius</li>
						<li>Grey-chinned Minivet r Pericrocotus solaris</li>
						<li>Long-tailed Minivet R Pericrocotus ethologus</li>
						<li>Short-billed Minivet r Pericrocotus brevirostris</li>
						<li>Scarlet Minivet R Pericrocotus flammeus</li>
						<li>Bar-winged Flycatcher-shrike R Hemipus picatus</li>
						<li>Dicrurinae</li>
						<li>Rhipidurini</li>
						<li>Yellow-bellied Fantail R Rhipidura hypoxantha</li>
						<li>White-throated Fantail R Rhipidura albicollis</li>
						<li>White-browed Fantail Flycatcher R Rhipidura aureola</li>
						<li>Dicrurini</li>
						<li>Black Drongo R Dicrurus macrocercus</li>
						<li>Ashy Drongo R Dicrurus leucophaeus</li>
						<li>White-bellied Drongo r Dicrurus caerulescens</li>
						<li>Crow-billed Drongo r Dicrurus annectans</li>
						<li>Bronzed Drongo r Dicrurus aeneus</li>
						<li>Lesser Racket-tailed Drongo r Dicrurus remifer</li>
						<li>Spangled Drongo R Dicrurus hottentottus</li>
						<li>Andaman Drongo R Dicrurus andamanensis</li>
						<li>Greater Racket-tailed Drongo r Dicrurus paradiseus</li>
						<li>Monarchini</li>
						<li>Black-naped Monarch r Hypothymis azurea</li>
						<li>Asian Paradise-flycatcher R Terpsiphone paradisi</li>
						<li>Aegithininae</li>
						<li>Common Iora R Aegithina tiphia</li>
						<li>Marshall’s Iora r Aegithina nigrolutea</li>
						<li>Malaconotinae</li>
						<li>Large Woodshrike r Tephrodornis gularis</li>
						<li>Common Woodshrike R Tephrodornis pondicerianus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Bombycillidae </h6>
					<ul class="bulletPoints">
						<li>Bohemian Waxwing V Bombycilla garrulus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Cinclidae </h6>
					<ul class="bulletPoints">
						<li>White-throated Dipper R Cinclus cinclus</li>
						<li>Brown Dipper R Cinclus pallasii</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Muscicapidae </h6>
					<ul class="bulletPoints">
						<li>Turdinae</li>
						<li>Rufous-tailed Rock Thrush sp Monticola saxatilis</li>
						<li>Blue-capped Rock Thrush R Monticola cinclorhynchus</li>
						<li>Chestnut-bellied Rock Thrush r Monticola rufiventris</li>
						<li>Blue Rock Thrush rW Monticola solitarius</li>
						<li>Malabar Whistling Thrush R Myophonus horsfieldii</li>
						<li>Blue Whistling Thrush R Myophonus caeruleus</li>
						<li>Pied Thrush sp Zoothera wardii</li>
						<li>Orange-headed Thrush R Zoothera citrina</li>
						<li>Siberian Thrush w Zoothera sibirica</li>
						<li>Plain-backed Thrush r Zoothera mollissima</li>
						<li>Long-tailed Thrush r Zoothera dixoni</li>
						<li>Scaly Thrush r Zoothera dauma</li>
						<li>Long-billed Thrush r Zoothera monticola</li>
						<li>Dark-sided Thrush r Zoothera marginata</li>
						<li>Tickell’s Thrush R Turdus unicolor</li>
						<li>Black-breasted Thrush w Turdus dissimilis</li>
						<li>White-collared Blackbird r Turdus albocinctus</li>
						<li>Grey-winged Blackbird r Turdus boulboul</li>
						<li>Eurasian Blackbird r Turdus merula</li>
						<li>Chestnut Thrush r Turdus rubrocanus</li>
						<li>Kessler’s Thrush V Turdus kessleri</li>
						<li>Grey-sided Thrush w Turdus feae</li>
						<li>Eyebrowed Thrush w Turdus obscurus</li>
						<li>Dark-throated Thrush w Turdus ruficollis</li>
						<li>Dusky Thrush w Turdus naumanni</li>
						<li>Fieldfare ? Turdus pilaris</li>
						<li>Song Thrush V Turdus philomelos</li>
						<li>Mistle Thrush r Turdus viscivorus</li>
						<li>Gould’s Shortwing r Brachypteryx stellata</li>
						<li>Rusty-bellied Shortwing r Brachypteryx hyperythra</li>
						<li>White-bellied Shortwing r Brachypteryx major</li>
						<li>Lesser Shortwing r Brachypteryx leucophrys</li>
						<li>White-browed Shortwing r Brachypteryx montana</li>
						<li>Muscicapinae</li>
						<li>Muscicapini</li>
						<li>Brown-chested Jungle Flycatcher wr Rhinomyias brunneatus</li>
						<li>Spotted Flycatcher p Muscicapa striata</li>
						<li>Dark-sided Flycatcher r Muscicapa sibirica</li>
						<li>Asian Brown Flycatcher rw Muscicapa dauurica</li>
						<li>Rusty-tailed Flycatcher r Muscicapa ruficauda</li>
						<li>Brown-breasted Flycatcher r Muscicapa muttui</li>
						<li>Ferruginous Flycatcher r Muscicapa ferruginea</li>
						<li>Yellow-rumped Flycatcher V Ficedula zanthopygia</li>
						<li>Slaty-backed Flycatcher r Ficedula hodgsonii</li>
						<li>Rufous-gorgeted Flycatcher r Ficedula strophiata</li>
						<li>Red-breasted Flycatcher W Ficedula parva</li>
						<li>Red-throated Flycatcher W Ficedula albicilla</li>
						<li>Kashmir Flycatcher r Ficedula subrubra</li>
						<li>White-gorgeted Flycatcher r Ficedula monileger</li>
						<li>Snowy-browed Flycatcher r Ficedula hyperythra</li>
						<li>Little Pied Flycatcher r Ficedula westermanni</li>
						<li>Ultramarine Flycatcher r Ficedula superciliaris</li>
						<li>Slaty-blue Flycatcher r Ficedula tricolor</li>
						<li>Sapphire Flycatcher r Ficedula sapphira</li>
						<li>Black-and-orange Flycatcher r Ficedula nigrorufa</li>
						<li>Verditer Flycatcher R Eumyias thalassina</li>
						<li>Nilgiri Flycatcher r Eumyias albicaudata</li>
						<li>Large Niltava r Niltava grandis</li>
						<li>Small Niltava r Niltava macgrigoriae</li>
						<li>Rufous-bellied Niltava r Niltava sundara</li>
						<li>Vivid Niltava r Niltava vivida</li>
						<li>White-tailed Flycatcher r Cyornis concretus</li>
						<li>White-bellied Blue Flycatcher r Cyornis pallipes</li>
						<li>Pale-chinned Flycatcher r Cyornis poliogenys</li>
						<li>Pale Blue Flycatcher r Cyornis unicolor</li>
						<li>Blue-throated Flycatcher r Cyornis rubeculoides</li>
						<li>Hill Blue Flycatcher r Cyornis banyumas</li>
						<li>Tickell’s Blue Flycatcher R Cyornis tickelliae</li>
						<li>Pygmy Blue Flycatcher r Muscicapella hodgsoni</li>
						<li>Grey-headed Canary Flycatcher R Culicicapa ceylonensis</li>
						<li>Saxicolini</li>
						<li>European Robin V Erithacus rubecula</li>
						<li>Common Nightingale ? Luscinia megarhynchos</li>
						<li>Siberian Rubythroat w Luscinia calliope</li>
						<li>White-tailed Rubythroat rW Luscinia pectoralis</li>
						<li>Bluethroat sW Luscinia svecica</li>
						<li>Firethroat V Luscinia pectardens</li>
						<li>Indian Blue Robin r Luscinia brunnea</li>
						<li>Siberian Blue Robin V Luscinia cyane</li>
						<li>Orange-flanked Bush Robin r Tarsiger cyanurus</li>
						<li>Golden Bush Robin r Tarsiger chrysaeus</li>
						<li>White-browed Bush Robin r Tarsiger indicus</li>
						<li>Rufous-breasted Bush Robin r Tarsiger hyperythrus</li>
						<li>Rufous-tailed Scrub Robin p Cercotrichas galactotes</li>
						<li>Oriental Magpie Robin R Copsychus saularis</li>
						<li>White-rumped Shama R Copsychus malabaricus</li>
						<li>Indian Robin R Saxicoloides fulicata</li>
						<li>Rufous-backed Redstart w Phoenicurus eryth</li>
						<li>ronota Blue-capped Redstart r Phoenicurus coeruleocephalus</li>
						<li>Black Redstart rW Phoenicurus ochruros</li>
						<li>Hodgson’s Redstart w Phoenicurus hodgsoni</li>
						<li>White-throated Redstart r Phoenicurus schisticeps</li>
						<li>Daurian Redstart rw Phoenicurus auroreus</li>
						<li>White-winged Redstart r Phoenicurus erythrogaster</li>
						<li>Blue-fronted Redstart r Phoenicurus frontalis</li>
						<li>White-capped Water Redstart r Chaimarrornis leucocephalus</li>
						<li>Plumbeous Water Redstart r Rhyacornis fuliginosus</li>
						<li>White-bellied Redstart r Hodgsonius phaenicuroides</li>
						<li>White-tailed Robin r Myiomela leucura</li>
						<li>Blue-fronted Robin r Cinclidium frontale</li>
						<li>Grandala r Grandala coelicolor</li>
						<li>Little Forktail r Enicurus scouleri</li>
						<li>Black-backed Forktail r Enicurus immaculatus</li>
						<li>Slaty-backed Forktail r Enicurus schistaceus</li>
						<li>White-crowned Forktail r Enicurus leschenaulti</li>
						<li>Spotted Forktail r Enicurus maculatus</li>
						<li>Purple Cochoa r Cochoa purpurea</li>
						<li>Green Cochoa r Cochoa viridis</li>
						<li>Stoliczka’s Bushchat r Saxicola macrorhyncha</li>
						<li>Hodgson’s Bushchat w Saxicola insignis</li>
						<li>Siberian Stonechat R Saxicola torquata</li>
						<li>White-tailed Stonechat r Saxicola leucura</li>
						<li>Pied Bushchat R Saxicola caprata</li>
						<li>Jerdon’s Bushchat r Saxicola jerdoni</li>
						<li>Grey Bushchat R Saxicola ferrea</li>
						<li>Hume’s Wheatear r Oenanthe alboniger</li>
						<li>Northern Wheatear P Oenanthe oenanthe</li>
						<li>Variable Wheatear rw Oenanthe picata</li>
						<li>Pied Wheatear rw Oenanthe pleschanka</li>
						<li>Rufous-tailed Wheatear rw Oenanthe xanthoprymna</li>
						<li>Desert Wheatear rw Oenanthe deserti</li>
						<li>Isabelline Wheatear rw Oenanthe isabellina</li>
						<li>Brown Rock-chat R Cercomela fusca</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Sturnidae </h6>
					<ul class="bulletPoints">
						<li>Asian Glossy Starling r Aplonis panayensis</li>
						<li>Spot-winged Starling r Saroglossa spiloptera</li>
						<li>Chestnut-tailed Starling R Sturnus malabaricus</li>
						<li>White-headed Starling r Sturnus erythropygius</li>
						<li>Brahminy Starling R Sturnus pagodarum</li>
						<li>Purple-backed Starling V Sturnus sturninus</li>
						<li>Chestnut-cheeked Starling V Sturnus philippensis</li>
						<li>White-shouldered Starling ? Sturnus sinensis</li>
						<li>Rosy Starling WP Sturnus roseus</li>
						<li>Common Starling wp Sturnus vulgaris</li>
						<li>Asian Pied Starling R Sturnus contra</li>
						<li>Common Myna R Acridotheres tristis</li>
						<li>Bank Myna R Acridotheres ginginianus</li>
						<li>Jungle Myna R Acridotheres fuscus</li>
						<li>White-Vented Myna r Acridotheres cinereus</li>
						<li>Collared Myna r Acridotheres albocinctus</li>
						<li>Golden-crested Myna r Ampeliceps coronatus</li>
						<li>Common Hill Myna r Gracula religiosa</li>
						<li>Southern Hill Myna r Gracula indica</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Sittidae </h6>
					<ul class="bulletPoints">
						<li>Sittinae</li>
						<li>Chestnut-vented Nuthatch r Sitta nagaensis</li>
						<li>Kashmir Nuthatch r Sitta cashmirensis</li>
						<li>Chestnut-bellied Nuthatch R Sitta castanea</li>
						<li>White-tailed Nuthatch r Sitta himalayensis</li>
						<li>White-cheeked Nuthatch r Sitta leucopsis</li>
						<li>Velvet-fronted Nuthatch R Sitta frontalis</li>
						<li>Beautiful Nuthatch r Sitta formosa</li>
						<li>Tichodrominae</li>
						<li>Wallcreeper rw Tichodroma muraria</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Certhiidae </h6>
					<ul class="bulletPoints">
						<li>Certhiinae</li>
						<li>Certhinii</li>
						<li>Eurasian Treecreeper R Certhia familiaris</li>
						<li>Bar-tailed Treecreeper R Certhia himalayana</li>
						<li>Rusty-flanked Treecreeper r Certhia nipalensis</li>
						<li>Brown-throated Treecreeper r Certhia discolor</li>
						<li>Salpornithini</li>
						<li>Spotted Creeper r Salpornis spilonotus</li>
						<li>Troglodytinae</li>
						<li>Winter Wren r Troglodytes troglodytes</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Paridae </h6>
					<ul class="bulletPoints">
						<li>Remizinae</li>
						<li>White-crowned Penduline Tit r Remiz coronatus</li>
						<li>Fire-capped Tit r Cephalopyrus flammiceps</li>
						<li>Parinae</li>
						<li>Rufous-naped Tit r Parus rufonuchalis</li>
						<li>Rufous-vented Tit r Parus rubidiventris</li>
						<li>Spot-winged Tit r Parus melanolophus</li>
						<li>Coal Tit r Parus ater</li>
						<li>Grey-crested Tit r Parus dichrous</li>
						<li>Great Tit R Parus major</li>
						<li>Green-backed Tit R Parus monticolus</li>
						<li>White-naped Tit r Parus nuchalis</li>
						<li>Black-lored Tit r Parus xanthogenys</li>
						<li>Yellow-cheeked Tit r Parus spilonotus</li>
						<li>Yellow-browed Tit r Sylviparus modestus</li>
						<li>Sultan Tit r Melanochlora sultanea</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Aegithalidae </h6>
					<ul class="bulletPoints">
						<li>White-cheeked Tit r Aegithalos leucogenys</li>
						<li>Black-throated Tit R Aegithalos concinnus</li>
						<li>White-throated Tit r Aegithalos niveogularis</li>
						<li>Rufous-fronted Tit r Aegithalos iouschistos</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Hirundinidae </h6>
					<ul class="bulletPoints">
						<li>Pale Martin pr Riparia diluta</li>
						<li>Sand Martin r Riparia riparia</li>
						<li>Plain Martin R Riparia paludicola</li>
						<li>Eurasian Crag Martin r Hirundo rupestris</li>
						<li>Rock Martin V Hirundo fuligula</li>
						<li>Dusky Crag Martin R Hirundo concolor</li>
						<li>Barn Swallow RW Hirundo rustica</li>
						<li>Pacific Swallow r Hirundo tahitica</li>
						<li>Wire-tailed Swallow R Hirundo smithii</li>
						<li>Red-rumped Swallow RW Hirundo daurica</li>
						<li>Striated Swallow r Hirundo striolata</li>
						<li>Streak-throated Swallow R Hirundo fluvicola</li>
						<li>Northern House Martin rw Delichon urbica</li>
						<li>Asian House Martin r Delichon dasypus</li>
						<li>Nepal House Martin r Delichon nipalensis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Regulidae </h6>
					<ul class="bulletPoints">
						<li>Goldcrest r Regulus regulus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Pycnonotidae </h6>
					<ul class="bulletPoints">
						<li>Crested Finchbill r Spizixos canifrons</li>
						<li>Striated Bulbul r Pycnonotus striatus</li>
						<li>Grey-headed Bulbul r Pycnonotus priocephalus</li>
						<li>Black-headed Bulbul r Pycnonotus atriceps</li>
						<li>Black-crested Bulbul R Pycnonotus melanicterus</li>
						<li>Red-whiskered Bulbul R Pycnonotus jocosus</li>
						<li>White-eared Bulbul R Pycnonotus leucotis</li>
						<li>Himalayan Bulbul R Pycnonotus leucogenys</li>
						<li>Red-vented Bulbul R Pycnonotus cafer</li>
						<li>Yellow-throated Bulbul r Pycnonotus xantholaemus</li>
						<li>Flavescent Bulbul r Pycnonotus flavescens</li>
						<li>White-browed Bulbul r Pycnonotus luteolus</li>
						<li>White-throated Bulbul r Alophoixus flaveolus</li>
						<li>Olive Bulbul r Iole virescens</li>
						<li>Yellow-browed Bulbul r Iole indica</li>
						<li>Ashy Bulbul r Hemixos flavala</li>
						<li>Mountain Bulbul r Hypsipetes mcclellandii</li>
						<li>Black Bulbul R Hypsipetes leucocephalus</li>
						<li>Nicobar Bulbul r Hypsipetes nicobariensis</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Hypocoliidae</h6>
					<ul class="bulletPoints">
						<li>Grey Hypocolius w Hypocolius ampelinus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Cisticolidae </h6>
					<ul class="bulletPoints">
						<li>Zitting Cisticola R Cisticola juncidis</li>
						<li>Bright-headed Cisticola r Cisticola exilis</li>
						<li>Rufous-vented Prinia r Prinia burnesii</li>
						<li>Striated Prinia R Prinia criniger</li>
						<li>Hill Prinia r Prinia atrogularis</li>
						<li>Grey-crowned Prinia r Prinia cinereocapilla</li>
						<li>Rufous-fronted Prinia R Prinia buchanani</li>
						<li>Rufescent Prinia r Prinia rufescens</li>
						<li>Grey-breasted Prinia R Prinia hodgsonii</li>
						<li>Graceful Prinia R Prinia gracilis</li>
						<li>Jungle Prinia R Prinia sylvatica</li>
						<li>Yellow-bellied Prinia R Prinia flaviventris</li>
						<li>Ashy Prinia R Prinia socialis</li>
						<li>Plain Prinia R Prinia inornata</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Zosteropidae </h6>
					<ul class="bulletPoints">
						<li>Oriental White-eye R Zosterops palpebrosus</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Sylviidae </h6>
					<ul class="bulletPoints">
						<li>Acrocephalinae</li>
						<li>Chestnut-headed Tesia r Tesia castaneocoronata</li>
						<li>Slaty-bellied Tesia r Tesia olivea</li>
						<li>Grey-bellied Tesia r Tesia cyaniventer</li>
						<li>Pale-footed Bush Warbler r Cettia pallidipes</li>
						<li>Japanese Bush Warbler V Cettia diphone</li>
						<li>Brownish-flanked Bush Warbler r Cettia fortipes</li>
						<li>Chestnut-crowned Bush Warbler r Cettia major</li>
						<li>Aberrant Bush Warbler r Cettia flavolivacea</li>
						<li>Yellowish-bellied Bush Warbler r Cettia acanthizoides</li>
						<li>Grey-sided Bush Warbler r Cettia brunnifrons</li>
						<li>Cetti’s Bush Warbler w Cettia cetti</li>
						<li>Spotted Bush Warbler r Bradypterus thoracicus</li>
						<li>Long-billed Bush Warbler N r Bradypterus major</li>
						<li>Chinese Bush Warbler V Bradypterus tacsanowskius</li>
						<li>Brown Bush Warbler r Bradypterus luteoventris</li>
						<li>Russet Bush Warbler V Bradypterus seebohmi</li>
						<li>Lanceolated Warbler w Locustella lanceolata</li>
						<li>Grasshopper Warbler w Locustella naevia</li>
						<li>Rusty-rumped Warbler w Locustella certhiola</li>
						<li>Moustached Warbler rw Acrocephalus melanopogon</li>
						<li>Sedge Warbler ? Acrocephalus schoenobaenus</li>
						<li>Black-browed Reed Warbler w Acrocephalus bistrigiceps</li>
						<li>Paddyfield Warbler w Acrocephalus agricola</li>
						<li>Large-billed Reed Warbler r Acrocephalus orinus</li>
						<li>Blunt-winged Warbler r Acrocephalus concinens</li>
						<li>Blyth’s Reed Warbler W Acrocephalus dumetorum</li>
						<li>Great Reed Warbler w Acrocephalus arundinaceus</li>
						<li>Oriental Reed Warbler w Acrocephalus orientalis</li>
						<li>Clamorous Reed Warbler R Acrocephalus stentoreus</li>
						<li>Thick-billed Warbler w Acrocephalus aedon</li>
						<li>Booted Warbler rw Hippolais caligata</li>
						<li>Sykes’s Warbler Hippolais rama</li>
						<li>Mountain Tailorbird r Orthotomus cuculatus</li>
						<li>Common Tailorbird R Orthotomus sutorius</li>
						<li>Dark-necked Tailorbird r Orthotomus atrogularis</li>
						<li>White-browed Tit Warbler r Leptopoecile sophiae</li>
						<li>Common Chiffchaff sW Phylloscopus collybita</li>
						<li>Mountain Chiffchaff Rw Phylloscopus sindianus</li>
						<li>Plain Leaf Warbler w Phylloscopus neglectus</li>
						<li>Dusky Warbler w Phylloscopus fuscatus</li>
						<li>Smoky Warbler sw Phylloscopus fuligiventer</li>
						<li>Tickell’s Leaf Warbler sW Phylloscopus affinis</li>
						<li>Buff-throated Warbler V Phylloscopus subaffinis</li>
						<li>Sulphur-bellied Warbler sw Phylloscopus griseolus</li>
						<li>Radde’s Warbler ? Phylloscopus schwarzi</li>
						<li>Buff-barred Warbler r Phylloscopus pulcher</li>
						<li>Ashy-throated Warbler r Phylloscopus maculipennis</li>
						<li>Lemon-rumped Warbler rW Phylloscopus chloronotus</li>
						<li>Chinese Leaf Warbler Phylloscopus sichuanensis</li>
						<li>Brooks’s Leaf Warbler w Phylloscopus subviridis</li>
						<li>Yellow-browed Warbler rW Phylloscopus inornatus</li>
						<li>Hume’s Warbler W Phylloscopus humei</li>
						<li>Arctic Warbler V Phylloscopus borealis</li>
						<li>Greenish Warbler rW Phylloscopus trochiloides</li>
						<li>Pale-legged Leaf Warbler V Phylloscopus tenellipes</li>
						<li>Large-billed Leaf Warbler rw Phylloscopus magnirostris</li>
						<li>Tytler’s Leaf Warbler r Phylloscopus tytleri</li>
						<li>Western Crowned Warbler r Phylloscopus occipitalis</li>
						<li>Eastern Crowned Warbler w Phylloscopus coronatus</li>
						<li>Blyth’s Leaf Warbler r Phylloscopus reguloides</li>
						<li>Yellow-vented Warbler r Phylloscopus cantator</li>
						<li>Golden-spectacled Warbler R Seicercus burkii</li>
						<li>Grey-crowned Warbler R Seicercus tephrocephalus</li>
						<li>Grey-hooded Warbler R Seicercus xanthoschistos</li>
						<li>White-spectacled Warbler r Seicercus affinis</li>
						<li>Whistler&#39;s Warbler r Seicercus whistleri</li>
						<li>Grey-cheeked Warbler r Seicercus poliogenys</li>
						<li>Chestnut-crowned Warbler r Seicercus castaniceps</li>
						<li>Broad-billed Warbler r Tickellia hodgsoni</li>
						<li>Rufous-faced Warbler r Abroscopus albogularis</li>
						<li>Black-faced Warbler r Abroscopus schisticeps</li>
						<li>Yellow-bellied Warbler r Abroscopus superciliaris</li>
						<li>Megalurinae</li>
						<li>Striated Grassbird R Megalurus palustris</li>
						<li>Bristled Grassbird r Chaetornis striatus</li>
						<li>Rufous-rumped Grassbird r Graminicola bengalensis</li>
						<li>Broad-tailed Grassbird r Schoenicola platyura</li>
						<li>Garrulacinae</li>
						<li>White-throated Laughingthrush R Garrulax albogularis</li>
						<li>White-crested Laughingthrush R Garrulax leucolophus</li>
						<li>Lesser Necklaced Laughingthrush r Garrulax monileger</li>
						<li>Greater Necklaced Laughingthrush r Garrulax pectoralis</li>
						<li>Striated Laughingthrush r Garrulax striatus</li>
						<li>Rufous-necked Laughingthrush r Garrulax ruficollis</li>
						<li>Chestnut-backed Laughingthrush r Garrulax nuchalis</li>
						<li>Yellow-throated Laughingthrush r Garrulax galbanus</li>
						<li>Wynaad Laughingthrush r Garrulax delesserti</li>
						<li>Rufous-vented Laughingthrush r Garrulax gularis</li>
						<li>Moustached Laughingthrush r Garrulax cineraceus</li>
						<li>Rufous-chinned Laughingthrush r Garrulax rufogularis</li>
						<li>Spotted Laughingthrush r Garrulax ocellatus</li>
						<li>Grey-sided Laughingthrush r Garrulax caerulatus</li>
						<li>Spot-breasted Laughingthrush r Garrulax merulinus</li>
						<li>White-browed Laughingthrush r Garrulax sannio</li>
						<li>Nilgiri Laughingthrush r Garrulax cachinnans</li>
						<li>Grey-breasted Laughingthrush r Garrulax jerdoni</li>
						<li>Streaked Laughingthrush R Garrulax lineatus</li>
						<li>Striped Laughingthrush r Garrulax virgatus</li>
						<li>Brown-capped Laughingthrush r Garrulax austeni</li>
						<li>Blue-winged Laughingthrush r Garrulax squamatus</li>
						<li>Scaly Laughingthrush r Garrulax subunicolor</li>
						<li>Elliot’s Laughingthrush ? Garrulax elliotii</li>
						<li>Variegated Laughingthrush r Garrulax variegatus</li>
						<li>Brown-cheeked Laughingthrush ? Garrulax henrici</li>
						<li>Black-faced Laughingthrush r Garrulax affinis</li>
						<li>Chestnut-crowned Laughingthrush r Garrulax erythrocephalus</li>
						<li>Red-faced Liocichla r Liocichla phoenicea</li>
						<li>Bugun Liocichla r Liocichla bugunorum</li>
						<li>Sylviinae</li>
						<li>Timaliini</li>
						<li>Abbott’s Babbler r Malacocincla abbotti</li>
						<li>Buff-breasted Babbler r Pellorneum tickelli</li>
						<li>Spot-throated Babbler r Pellorneum albiventre</li>
						<li>Marsh Babbler r Pellorneum palustre</li>
						<li>Puff-throated Babbler R Pellorneum ruficeps</li>
						<li>Large Scimitar Babbler r Pomatorhinus hypoleucos</li>
						<li>Spot-breasted Scimitar Babbler r Pomatorhinus erythrocnemis</li>
						<li>Rusty-cheeked Scimitar Babbler r Pomatorhinus erythrogenys</li>
						<li>White-browed Scimitar Babbler r Pomatorhinus schisticeps</li>
						<li>Indian Scimitar Babbler r Pomatorhinus horsfieldii</li>
						<li>Streak-breasted Scimitar Babbler r Pomatorhinus ruficollis</li>
						<li>Red-billed Scimitar Babbler r Pomatorhinus ochraciceps</li>
						<li>Coral-billed Scimitar Babbler r Pomatorhinus ferruginosus</li>
						<li>Slender-billed Scimitar Babbler r Xiphirhynchus superciliaris</li>
						<li>Long-billed Wren Babbler r Rimator malacoptilus</li>
						<li>Streaked Wren Babbler r Napothera brevicaudata</li>
						<li>Eyebrowed Wren Babbler r Napothera epilepidota</li>
						<li>Scaly-breasted Wren Babbler r Pnoepyga albiventer</li>
						<li>Nepal Wren Babbler r Pnoepyga immaculata</li>
						<li>Pygmy Wren Babbler r Pnoepyga pusilla</li>
						<li>Rufous-throated Wren Babbler r Spelaeornis caudatus</li>
						<li>Rusty-throated Wren Babbler r Spelaeornis badeigularis</li>
						<li>Bar-winged Wren Babbler r Spelaeornis troglodytoides</li>
						<li>Spotted Wren Babbler r Spelaeornis formosus</li>
						<li>Long-tailed Wren Babbler r Spelaeornis chocolatinus</li>
						<li>Tawny-breasted Wren Babbler r Spelaeornis longicaudatus</li>
						<li>Wedge-billed Wren Babbler r Sphenocichla humei</li>
						<li>Rufous-fronted Babbler r Stachyris rufifrons</li>
						<li>Rufous-capped Babbler r Stachyris ruficeps</li>
						<li>Black-chinned Babbler R Stachyris pyrrhops</li>
						<li>Golden Babbler r Stachyris chrysaea</li>
						<li>Grey-throated Babbler r Stachyris nigriceps</li>
						<li>Snowy-throated Babbler r Stachyris oglei</li>
						<li>Tawny-bellied Babbler R Dumetia hyperythra</li>
						<li>Dark-fronted Babbler r Rhopocichla atriceps</li>
						<li>Striped Tit Babbler R Macronous gularis</li>
						<li>Chestnut-capped Babbler R Timalia pileata</li>
						<li>Yellow-eyed Babbler R Chrysomma sinense</li>
						<li>Jerdon’s Babbler r Chrysomma altirostre</li>
						<li>Common Babbler R Turdoides caudatus</li>
						<li>Striated Babbler R Turdoides earlei</li>
						<li>Slender-billed Babbler r Turdoides longirostris</li>
						<li>Large Grey Babbler R Turdoides malcolmi</li>
						<li>Rufous Babbler r Turdoides subrufus</li>
						<li>Jungle Babbler R Turdoides striatus</li>
						<li>Yellow-billed Babbler R Turdoides affinis</li>
						<li>Chinese Babax V Babax lanceolatus</li>
						<li>Giant Babax ? Babax waddelli</li>
						<li>Silver-eared Mesia r Leiothrix argentauris</li>
						<li>Red-billed Leiothrix r Leiothrix lutea</li>
						<li>Cutia r Cutia nipalensis</li>
						<li>Black-headed Shrike Babbler r Pteruthius rufiventer</li>
						<li>White-browed Shrike Babbler r Pteruthius flaviscapis</li>
						<li>Green Shrike Babbler r Pteruthius xanthochlorus</li>
						<li>Black-eared Shrike Babbler r Pteruthius melanotis</li>
						<li>Chestnut-fronted Shrike Babbler r Pteruthius aenobarbus</li>
						<li>White-hooded Babbler r Gampsorhynchus rufulus</li>
						<li>Rusty-fronted Barwing r Actinodura egertoni</li>
						<li>Hoary-throated Barwing r Actinodura nipalensis</li>
						<li>Streak-throated Barwing r Actinodura waldeni</li>
						<li>Blue-winged Minla r Minla cyanouroptera</li>
						<li>Chestnut-tailed Minla r Minla strigula</li>
						<li>Red-tailed Minla r Minla ignotincta</li>
						<li>Golden-breasted Fulvetta r Alcippe chrysotis</li>
						<li>Yellow-throated Fulvetta r Alcippe cinerea</li>
						<li>Rufous-winged Fulvetta r Alcippe castaneceps</li>
						<li>White-browed Fulvetta r Alcippe vinipectus</li>
						<li>Streak-throated Fulvetta r Alcippe cinereiceps</li>
						<li>Brown-throated Fulvetta r Alcippe ludlowi</li>
						<li>Rufous-throated Fulvetta r Alcippe rufogularis</li>
						<li>Rusty-capped Fulvetta r Alcippe dubia</li>
						<li>Brown-cheeked Fulvetta R Alcippe poioicephala</li>
						<li>Nepal Fulvetta r Alcippe nipalensis</li>
						<li>Rufous-backed Sibia r Heterophasia annectans</li>
						<li>Rufous Sibia R Heterophasia capistrata</li>
						<li>Grey Sibia r Heterophasia gracilis</li>
						<li>Beautiful Sibia r Heterophasia pulchella</li>
						<li>Long-tailed Sibia r Heterophasia picaoides</li>
						<li>Striated Yuhina r Yuhina castaniceps</li>
						<li>White-naped Yuhina r Yuhina bakeri</li>
						<li>Whiskered Yuhina R Yuhina flavicollis</li>
						<li>Stripe-throated Yuhina R Yuhina gularis</li>
						<li>Rufous-vented Yuhina r Yuhina occipitalis</li>
						<li>Black-chinned Yuhina R Yuhina nigrimenta</li>
						<li>White-bellied Yuhina r Yuhina zantholeuca</li>
						<li>Fire-tailed Myzornis r Myzornis pyrrhoura</li>
						<li>Great Parrotbill r Conostoma oemodium</li>
						<li>Brown Parrotbill r Paradoxornis unicolor</li>
						<li>Grey-headed Parrotbill r Paradoxornis gularis</li>
						<li>Black-breasted Parrotbill r Paradoxornis flavirostris</li>
						<li>Spot-breasted Parrotbill r Paradoxornis guttaticollis</li>
						<li>Fulvous Parrotbill r Paradoxornis fulvifrons</li>
						<li>Black-throated Parrotbill r Paradoxornis nipalensis</li>
						<li>Lesser Rufous-headed Parrotbill r Paradoxornis atrosuperciliaris</li>
						<li>Greater Rufous-headed Parrotbill r Paradoxornis ruficeps</li>
						<li>Sylviini</li>
						<li>Garden Warbler ? Sylvia borin</li>
						<li>Greater Whitethroat p Sylvia communis</li>
						<li>Lesser Whitethroat W Sylvia curruca blythi</li>
						<li>Hume’s Lesser Whitethroat W Sylvia althaea</li>
						<li>Small Whitethroat w Sylvia minula</li>
						<li>Eastern Desert Warbler w Sylvia nana</li>
						<li>Barred Warbler V Sylvia nisoria</li>
						<li>Eastern Orphean Warbler rW Sylvia crassirostris</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Alaudidae </h6>
					<ul class="bulletPoints">
						<li>Singing Bushlark r Mirafra cantillans</li>
						<li>Indian Bushlark R Mirafra erythroptera</li>
						<li>Bengal Bushlark R Mirafra assamica</li>
						<li>Rufous-winged Bushlark R Mirafra affinis</li>
						<li>Black-crowned Sparrow Lark r Eremopterix nigriceps</li>
						<li>Ashy-crowned Sparrow Lark R Eremopterix grisea</li>
						<li>Rufous-tailed Lark R Ammomanes phoenicurus</li>
						<li>Desert Lark r Ammomanes deserti</li>
						<li>Greater Hoopoe Lark r Alaemon alaudipes</li>
						<li>Bimaculated Lark w Melanocorypha bimaculata</li>
						<li>Tibetan Lark r Melanocorypha maxima</li>
						<li>Greater Short-toed Lark W Calandrella brachydactyla</li>
						<li>Hume’s Short-toed Lark rw Calandrella acutirostris</li>
						<li>Lesser Short-toed Lark W Calandrella rufescens</li>
						<li>Asian Short-toed Lark V Calandrella cheleensis</li>
						<li>Sand Lark R Calandrella raytal</li>
						<li>Crested Lark R Galerida cristata</li>
						<li>Malabar Lark r Galerida malabarica</li>
						<li>Sykes’s Lark r Galerida deva</li>
						<li>Eurasian Skylark w Alauda arvensis</li>
						<li>Oriental Skylark R Alauda gulgula</li>
						<li>Horned Lark r Eremophila alpestris</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Nectariniidae </h6>
					<ul class="bulletPoints">
						<li>Nectariniinae</li>
						<li>Dicaeini</li>
						<li>Thick-billed Flowerpecker R Dicaeum agile</li>
						<li>Yellow-vented Flowerpecker r Dicaeum chrysorrheum</li>
						<li>Yellow-bellied Flowerpecker r Dicaeum melanoxanthum</li>
						<li>Orange-bellied Flowerpecker r Dicaeum trigonostigma</li>
						<li>Pale-billed Flowerpecker R Dicaeum erythrorhynchos</li>
						<li>Plain Flowerpecker r Dicaeum concolor</li>
						<li>Fire-breasted Flowerpecker r Dicaeum ignipectus</li>
						<li>Scarlet-backed Flowerpecker r Dicaeum cruentatum</li>
						<li>Nectariniini</li>
						<li>Ruby-cheeked Sunbird r Anthreptes singalensis</li>
						<li>Purple-rumped Sunbird R Nectarinia zeylonica</li>
						<li>Crimson-backed Sunbird r Nectarinia minima</li>
						<li>Purple-throated Sunbird r Nectarinia sperata</li>
						<li>Olive-backed Sunbird r Nectarinia jugularis</li>
						<li>Purple Sunbird R Nectarinia asiatica</li>
						<li>Loten’s Sunbird R Nectarinia lotenia</li>
						<li>Mrs Gould’s Sunbird r Aethopyga gouldiae</li>
						<li>Green-tailed Sunbird r Aethopyga nipalensis</li>
						<li>Black-throated Sunbird r Aethopyga saturata</li>
						<li>Crimson Sunbird R Aethopyga siparaja</li>
						<li>Fire-tailed Sunbird r Aethopyga ignicauda</li>
						<li>Little Spiderhunter r Arachnothera longirostra</li>
						<li>Streaked Spiderhunter r Arachnothera magna</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Passeridae</h6>
					<ul class="bulletPoints">
						<li>Passerinae</li>
						<li>House Sparrow R Passer domesticus</li>
						<li>Spanish Sparrow w Passer hispaniolensis</li>
						<li>Sind Sparrow r Passer pyrrhonotus</li>
						<li>Russet Sparrow R Passer rutilans</li>
						<li>Eurasian Tree Sparrow R Passer montanus</li>
						<li>Chestnut-shouldered Petronia R Petronia xanthocollis</li>
						<li>Rock Sparrow w Petronia petronia</li>
						<li>Tibetan Snowfinch r Montifringilla adamsi</li>
						<li>White-rumped Snowfinch r Pyrgilauda taczanowskii</li>
						<li>Rufous-necked Snowfinch w Pyrgilauda ruficollis</li>
						<li>Plain-backed Snowfinch w Pyrgilauda blanfordi</li>
						<li>Motacillinae</li>
						<li>Forest Wagtail rW Dendronanthus indicus</li>
						<li>White Wagtail rW Motacilla alba</li>
						<li>White-browed Wagtail R Motacilla maderaspatensis</li>
						<li>Citrine Wagtail rW Motacilla citreola citreola</li>
						<li>Yellow Wagtail W Motacilla flava</li>
						<li>Grey Wagtail rW Motacilla cinerea</li>
						<li>Richard’s Pipit W Anthus richardi</li>
						<li>Paddyfield Pipit R Anthus rufulus</li>
						<li>Tawny Pipit W Anthus campestris</li>
						<li>Blyth’s Pipit w Anthus godlewskii</li>
						<li>Long-billed Pipit Rw Anthus similis</li>
						<li>Tree Pipit rW Anthus trivialis</li>
						<li>Olive-backed Pipit RW Anthus hodgsoni</li>
						<li>Red-throated Pipit p Anthus cervinus</li>
						<li>Rosy Pipit r Anthus roseatus</li>
						<li>Water Pipit w Anthus spinoletta</li>
						<li>Buff-bellied Pipit w Anthus rubescens</li>
						<li>Upland Pipit r Anthus sylvanus</li>
						<li>Nilgiri Pipit r Anthus nilghiriensis</li>
						<li>Prunellinae</li>
						<li>Alpine Accentor r Prunella collaris</li>
						<li>Altai Accentor w Prunella himalayana</li>
						<li>Robin Accentor R Prunella rubeculoides</li>
						<li>Rufous-breasted Accentor r Prunella strophiata</li>
						<li>Brown Accentor r Prunella fulvescens</li>
						<li>Black-throated Accentor w Prunella atrogularis</li>
						<li>Maroon-backed Accentor r Prunella immaculata</li>
						<li>Ploceinae</li>
						<li>Black-breasted Weaver R Ploceus benghalensis</li>
						<li>Streaked Weaver R Ploceus manyar</li>
						<li>Baya Weaver R Ploceus philippinus</li>
						<li>Finn’s Weaver r Ploceus megarhynchus</li>
						<li>Estrildinae</li>
						<li>Red Avadavat R Amandava amandava</li>
						<li>Green Avadavat V r Amandava formosa</li>
						<li>Indian Silverbill R Lonchura malabarica</li>
						<li>White-rumped Munia R Lonchura striata</li>
						<li>Black-throated Munia r Lonchura kelaarti</li>
						<li>Scaly-breasted Munia R Lonchura punctulata</li>
						<li>Black-headed Munia R Lonchura malacca</li>
						<li>Java Sparrow Ir Lonchura oryzivora</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>Family: Fringillidae</h6>
					<ul class="bulletPoints">
						<li>Fringillinae</li>
						<li>Fringillini</li>
						<li>Chaffinch V Fringilla coelebs</li>
						<li>Brambling V Fringilla montif</li>
					</ul>
				</div><!---End of col-sm-8-->
				
				<div class="col-md-3">
	<form class="newsLetter" type="post">
		<input type="email" name="newsletter" id="newsletter" placeholder="Enter your email address" />
		<button type="button" name="button" id="nl-submit">
			<span id="text"><i class="fa fa-check-square-o"></i></span>
			<span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
		</button>
	</form>
	
	<p class="saranVaid"><a href="http://www.saranvaid.com" target="_blank" rel="nofollow"><img src="assets/img/saran-vaid-img.jpg" alt=""></a></p>
</div><!---End of col-sm-3-->				
			</div><!---End of row-->
		<!--end of grayBg-->
	</div>
</section>

<footer>
	<div class="container">
		<p class="membership"><a href="https://www.theearthsafari.com/wildlife-associations.php" title="African Travel & Tourism Association"><img src="assets/img/memberships.jpg" alt="African Travel & Tourism Association" /></a></p>
		
		<div class="links">
			<h6>Information Bank</h6>

							<a href="https://www.theearthsafari.com/responsible-ecotourism.php">RESPONSIBLE ECOTOURISM</a> 
                <a href="https://www.theearthsafari.com/safari-code-of-conduct.php">SAFARI CODE OF CONDUCT</a>
                <a href="https://www.theearthsafari.com/destination/ranthambore-national-park">RANTHAMBORE NATIONAL PARK</a>
                <a href="https://www.theearthsafari.com/interest/tiger-safari-india">TIGER SAFARI INDIA</a>
                <a href="https://www.theearthsafari.com/wildlife-photography-tips.php">WILDLIFE PHOTOGRAPHY TIPS</a> 
                <a href="https://www.theearthsafari.com/checklist-of-birds-of-india.php">CHECKLIST OF BIRDS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/popular-animal-species-of-india.php">POPULAR ANIMAL SPECIES OF INDIA</a> 
                <a href="https://www.theearthsafari.com/safari-packing-check-list.php">SAFARI PACKING CHECK LIST</a>
                <a href="https://www.theearthsafari.com/indian-wildlife-map-table.php">INDIAN WILDLIFE MAP TABLE</a>
                <a href="https://www.theearthsafari.com/list-of-tiger-reserves-in-india.php">LIST OF TIGER RESERVES IN INDIA</a> 
                <a href="https://www.theearthsafari.com/india-wildlife-experience.php">INDIAN WILDLIFE EXPERIENCE</a>
                <a href="https://www.theearthsafari.com/destination/kenya">KENYA SAFARI TOURS</a>
                <a href="https://www.theearthsafari.com/destination/tanzania">TANZANIA SAFARI TOURS</a> 
                <a href="https://www.theearthsafari.com/forests-of-india.php">FORESTS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/india-quick-facts.php">INDIA QUICK FACTS</a> 
                <a href="https://www.theearthsafari.com/tips-for-travel-in-india.php">TIPS FOR TRAVEL IN INDIA</a>
                <a href="https://www.theearthsafari.com/india-visa-info.php">INDIA VISA INFO</a>
		  
		</div><!---end of informationBank-->
		
		<div class="links">
			<h6>About The Earth Safari</h6>
			<a href="https://www.theearthsafari.com/">HOME</a>
			<a href="https://www.theearthsafari.com/about-us">ABOUT US</a>
			<a href="https://www.theearthsafari.com/client-testimonials">CLIENT TESTIMONIALS</a>
			<a href="https://www.theearthsafari.com/contact-us">CONTACT US</a>
			<a href="https://www.theearthsafari.com/terms">TERMS &amp; CONDITIONS</a>
			<a href="https://www.theearthsafari.com/sitemap.xml">XML SiteMap</a>
			<a href="https://www.theearthsafari.com/sitemap.html">HTML Site Map</a>
		</div><!---end of informationBank-->
		
		<div class="links">
			<div class="row">
				<div class="col-xs-9 disclaimer"><span>Disclaimer</span>: THE EARTH SAFARI is not liable for any errors or omissions. All pricing is indicative and subject to exchange rate fluctuations.</div>
				<div class="col-xs-3 media">
					<a href="https://plus.google.com/115282885713632754730" target="_blank" rel="nofollow" title="The Earth Safari Google+ Page"><i class="fa fa-google-plus"></i></a>
					<a href="https://www.facebook.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Facebook Page"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Twitter Page"><i class="fa fa-twitter"></i></a>
					<a href="https://www.theearthsafari.com/blog" target="_blank" title="The Earth Safari Blog"><i class="fa fa-wordpress"></i></a>
				</div>
			</div><!---End of row-->
		</div>
		
		<div class="copyright">Copyright &copy; 2011 - 2022 TheEarthSafari.com</div>
	</div>
</footer>

<div class="enquireBox na">
    <a class="toggle" href="javascript:;">Quick Enquiry <i class="fa fa-angle-double-down"></i></a>
    <h4>Send Your Enquiry now</h4>
    <form class="enquiry">
        <div class="enquiry-message"></div>
        <input type="text" name="name" id="name" class="form-control" placeholder="Name"/>
        <input type="email" name="email" id="email" class="form-control" placeholder="Email"/>
        <input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone"/>
        <textarea name="query" id="query" class="form-control" placeholder="Message"></textarea>
        <button type="button" id="enquiry-submit">
            <span id="text">Submit</span>
            <span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
        </button>
    </form>
</div>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37106525-1']);
  _gaq.push(['_setDomainName', 'theearthsafari.com']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Google Code for Remarketing Tag -->
<!--
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
-->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 972714909;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/972714909/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery("#enquiry-submit").click(function() {
        jQuery("#enquiry-submit #text").hide();
        jQuery("#enquiry-submit #loader").show();
        var from = 1;
        var data = jQuery(".enquiry").serialize();
            jQuery.ajax
            ({
            url: 'ajax/email-query.php?'+data,
            dataType: 'html',
            success: function(msg)
            {
                jQuery(".enquiry-message").show();
                jQuery(".enquiry-message").html(msg);
                jQuery("#enquiry-submit #text").show();
                jQuery("#enquiry-submit #loader").hide();
                if (msg == '<span id="success">Thank you for contact with The Earth Safari.</span>') {
                    jQuery("#name").val("");
                    jQuery("#email").val("");
                    jQuery("#phone").val("");
                    jQuery("#query").val("");
                }
                jQuery(".enquiry-message").delay(3000).hide(1000);
            }
        });
        return false;
    });
    jQuery("#nl-submit").click(function() {
        jQuery("#nl-submit #text").hide();
        jQuery("#nl-submit #loader").show();
        var emails = jQuery('#newsletter').val();
        jQuery.ajax
        ({
            type: 'POST',
            url: 'ajax/newsletter.php',
            data: {email:emails},
            dataType: 'html',
            success: function(msg)
            {
                jQuery("#nl-submit #text").show();
                jQuery("#nl-submit #loader").hide();
                jQuery(".newsletter-popup").show("slow");
                jQuery(".newsletter-popup").html(msg);
                jQuery("#newsletter").val('');
                jQuery(".close").click(function () {
                    jQuery(".newsletter-popup").hide("slow");
                });
            }
        });
    });
});
</script>

<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
  d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
  _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
  $.src='//v2.zopim.com/?1ltJ36Z0ARzUAnTSXmu2o4RKs2ndLWHU';z.t=+new Date;$.
  type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->

<script async src="//www.google.com/recaptcha/api.js"></script>

<script>
function onSubmit(token) {
    $("#enquiryForm").submit();
    return true;
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script type="text/javascript">
$().ready(function() {
  $("#enquiryForm").validate({
    rules: {
      name: "required",
      email: {
        required: true,
        email: true
      },
      phone: {
        required: true,
        minlength: 9
      },
      nationality: "required",
      city: "required",
      adult: "required",
      age_children: {
        required: {
            depends: function() {
              return $("#children").val()
            }
        }
      },
      curr_date: "required",
      month: "required",
      year: "required",
      duration: "required"
    },
    submitHandler: function (form) {
        if (grecaptcha.getResponse()) {
                // 2) finally sending form data
                form.submit();
        }else{
                // 1) Before sending we must validate captcha
            grecaptcha.reset();
            grecaptcha.execute();
        }           
    }
  });
});
</script>
<!--..........Javascript Libraries Start Here..........-->	
<script src="assets/js/slick.js"></script>
<script type="text/javascript" src="assets/js/init.js"></script>

</body>
</html>
