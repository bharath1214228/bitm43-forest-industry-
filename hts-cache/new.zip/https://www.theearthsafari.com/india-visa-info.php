<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta tag properties start here -->
  <meta charset="utf-8">

  <meta name="language" content="english">
  <meta http-equiv="content-language" content="en">

  <meta name="google-site-verification" content="qYC3doxIvybN5KSFiBXT8IohYU9A9Wmer1u2CG7h110" />

  <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
  <meta name="robots" content="NOODP">
  <meta name="robots" content="index, follow" />
  <meta name="DC.title" content="Best African Safari & Indian Tiger Safari" >

  <meta name="description" content="Get a comprehensive Visa Information to India. If you plan to visit India, a valid Passport and Visa from that country is necessary. India does not provide a Visa on arrival. do check with the requirements before you leave your country to India." />
  <meta name="keywords" content="visa for india,visa information for india,passport,theearthsafari.com" />

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Meta tag properties end here -->
  <title>India Visa Information by TheEarthSafari.com</title>

  <!-- jQuery library file -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
   
  <base href="" />
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

  <!--[if lt IE 9]>
    <script src="assets/js/html5shiv.js"> </script>
  <![endif]-->
  <link rel="publisher" href="https://plus.google.com/+Theearthsafaritours"/>
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
  <!-- CSS file -->
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="assets/css/slick.css">
  <link rel="stylesheet" type="text/css" media="screen, projection" href="assets/css/main.css" />
  <link rel="stylesheet" href="assets/css/media.css">
</head>

<body class="inner">

<noscript>
<div class="popup-box" style="z-index: 99999999999;"></div>
	<div class="popup-box-container" style="z-index: 99999999999;">
  	<img alt="The Earth Safari" src="assets/img/the-earth-safari-logo.png" style="float:left;" />
    <div class="popup-divider">&nbsp;</div>
    <div class="popup-righ-panel">
    	<span class="popup-heading">Warning!</span>
    	<span class="popup-text">It appears that JavaScript is disabled in your web browser. Please enable it and refresh page to have full system functionality. For instructions on how to enable javascipt in your browser: <a href="http://www.activatejavascript.org/" target="_blank" style="text-decoration: none;" rel="follow" >Click Here</a>.</span>
    </div>
  </div>
</noscript>
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-2 logo"><a href="https://www.theearthsafari.com/"><img src="assets/img/the-earth-safari-logo.png" alt=""/></a></div>
			
			<div class="col-md-10 rightCol">
				<p class="tagline">Inspirational Safaris in India & Africa</p>
				<nav>
					<div class="top">
						<form id="region-selector" name="region_select" action="region.php" method="POST">
							<input type="hidden" name="page" value="http://www.theearthsafari.com/india-visa-info.php">
															<input type="radio" name="r-selector" value="2" id="africa" onclick="this.form.submit()" style="display: none;">
								<label for="africa">Visit Africa</label>
													</form>

						<a class="menuToggle" href="javascript:;"><i class="fa fa-bars"></i></a>
						<ul>
							<li><a href="https://www.theearthsafari.com/">Home</a></li>
							<li><a href="https://www.theearthsafari.com/about-us">About Us</a></li>
							<li><a href="https://www.theearthsafari.com/client-testimonials">Client testimonials</a></li>
							<li><a href="https://www.theearthsafari.com/contact-us">Contact</a></li>
							<li><a href="https://www.theearthsafari.com/blog">Blog</a></li>
							<li><a href="tel:+91 8447870008">CALL: +91 8447870008</a></li>
						</ul>
					</div><!---End of top-->
					
					<div class="exploreDestination">
						<ul  class="exploreLinkks">
														<li>Explore By : </li>
							<li><a href="javascript:;">Destinations</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/destination/ranthambore-national-park">Ranthambore National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/bandhavgarh-national-park">Bandhavgarh National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kanha-national-park">Kanha National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/pench-national-park">Pench National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/tadoba-andhari-tiger-reserve">Tadoba-Andhari Tiger Reserve</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/jim-corbett-national-park">Jim Corbett National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/gir-forest-national-park">Gir Forest National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kaziranga-national-park">Kaziranga National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/sunderbans-national-park">Sunderbans National Park</a></li>
																	</ul>
							</li>
							<li><a href="javascript:;">Interest</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/interest/tiger-safari-india">Tiger Safari India</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-high-end-luxury-safaris">India High End Luxury Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-short-duration-safaris">India Short Duration Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-culture-and-heritage-tours">India Culture and Heritage Tours</a></li>
																	</ul>
							</li>
							<li><a href="https://www.theearthsafari.com/private-safari.php">Private Safari</a></li>
							<li><a href="https://www.theearthsafari.com/group-safari.php">Group Safari</a></li>
						</ul>
					</div><!--end  of exploreDestination-->
				</nav>
			</div>
		</div><!-- End of row -->
	</div><!-- End of container-->
</header>

<section class="masterSection staticPage">
	<div class="container">
		<div class="grayBg margin-top-50">
			<div class="row safariList">
				<div class="col-md-9">
					<div class="title"><h2>India Visa Info</h2></div>
					
					<p class="profilePic"><img src="assets/img/india-visa-info.jpg" alt=""/></p>
					<p class="clear">&nbsp;</p>
					
					<h5 class="text-orange">Indian Visa </h5>
					<p>A VISA Certificate is a stamp marked certificate on the applicant's passport by the immigration authorities of a country to indicate that the applicant's credentials have been verified and he or she has been granted permission to enter the country for a temporary stay within a specified period.</p>

					<p>Foreign Nationals desirous of coming into India are required to possess a valid passport of their country and a valid Indian Visa. The Consular Passport and Visa (CPV) Division of the Ministry of External Affairs is responsible for issuance of Indian visas to the foreign nationals for their visit for various purposes. This facility is granted through various Indian missions abroad. </p>

					<p>Visa fees are non-refundable and subject to change without notice. The High Commission reserves the right on granting and deciding type/ duration of visa irrespective of the fees tendered at the time of making application. Granting of Visa does not confer the right of entry to India and is subject to the discretion of the Immigration Authorities.</p>

					<p>There is no provision of 'Visa on Arrival' in India and no fee is charged for immigration facilities at the airports. Foreign passengers should ensure that they are in possession of valid Indian Visa before they start their journey to India. </p>

					<p>Gratis (Free) visa is issued to the nationals of many countries including Burundi, Cape Verde, Haiti, Mauritius, Jamaica, Maldives, Mongolia etc. </p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Visa Application Form  </h5>
					<p>Visa application form is available at the office of Indian Embassy in the country where the NRI/PIO resides. Visa form for nationals of Pakistan and Bangladesh are generally different. All NRIs/PIOs, including children (who don't possess OCI or PIO card) need to apply for Visa in separate visa forms.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Procedure for obtaining Visa </h5>
					<p>Visas can be applied in person or by post at the High Commission of India based in the country from where the candidate intends to depart for India. Specific visas are granted for a variety of purposes that are aforementioned.</p>
					Application form for Visa Note (File referring to external site opens in a new window)

					<p><a href="https://india.gov.in/outerwin.php?id=http://passport.gov.in/cpv/VisaNote.pdf" target="_blank" class="hyperlinks" rel="follow">Application form for Visa Note (File referring to external site opens in a new window)</a></p>

					<p><a href="https://india.gov.in/outerwin.php?id=http://www.immigrationindia.nic.in/Registration%20Form.pdf" target="_blank" class="hyperlinks" rel="follow">Registration Form (File referring to external site opens in a new window)</a></p>

					<p><a href="https://india.gov.in/outerwin.php?id=http://www.immigrationindia.nic.in/Extension%20Form.pdf" target="_blank" class="hyperlinks" rel="follow">Visa Extension Form/Return Visa/Multiple Entry Visa (File referring to external site opens in a new window)</a></p>
					
					<p><a href="https://india.gov.in/outerwin.php?id=http://www.mha.nic.in/pdfs/new_applicaton_form_visa.pdf" target="_blank" class="hyperlinks" rel="follow">Special Permit Form (File referring to external site opens in a new window)</a></p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Embassies & Consulates</h5>
					<p>Here is a list of all the Foreign Embassies and Consulates in India and the Indian Missions abroad. You can also access their addresses and contact numbers. The section will surely prove to be a boon for those planning to visit India for various purposes as well as Indians who would like to make their way to foreign shores. </p>
					<ul class="bulletPoints">
						<li><a href="https://india.gov.in/overseas/foreign_emb_india.php" target="_blank" class="bullet-points" rel="follow">Foreign Embassies in India</a></li>
						<li><a href="https://india.gov.in/overseas/indian_missions.php" target="_blank" class="bullet-points" rel="follow">Indian Missions Abroad</a></li>
					</ul>
					
				</div><!---End of col-sm-8-->
				
				<div class="col-md-3">
	<form class="newsLetter" type="post">
		<input type="email" name="newsletter" id="newsletter" placeholder="Enter your email address" />
		<button type="button" name="button" id="nl-submit">
			<span id="text"><i class="fa fa-check-square-o"></i></span>
			<span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
		</button>
	</form>
	
	<p class="saranVaid"><a href="http://www.saranvaid.com" target="_blank" rel="nofollow"><img src="assets/img/saran-vaid-img.jpg" alt=""></a></p>
</div><!---End of col-sm-3-->				
			</div><!---End of row-->
		<!--end of grayBg-->
	</div>
</section>

<footer>
	<div class="container">
		<p class="membership"><a href="https://www.theearthsafari.com/wildlife-associations.php" title="African Travel & Tourism Association"><img src="assets/img/memberships.jpg" alt="African Travel & Tourism Association" /></a></p>
		
		<div class="links">
			<h6>Information Bank</h6>

							<a href="https://www.theearthsafari.com/responsible-ecotourism.php">RESPONSIBLE ECOTOURISM</a> 
                <a href="https://www.theearthsafari.com/safari-code-of-conduct.php">SAFARI CODE OF CONDUCT</a>
                <a href="https://www.theearthsafari.com/destination/ranthambore-national-park">RANTHAMBORE NATIONAL PARK</a>
                <a href="https://www.theearthsafari.com/interest/tiger-safari-india">TIGER SAFARI INDIA</a>
                <a href="https://www.theearthsafari.com/wildlife-photography-tips.php">WILDLIFE PHOTOGRAPHY TIPS</a> 
                <a href="https://www.theearthsafari.com/checklist-of-birds-of-india.php">CHECKLIST OF BIRDS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/popular-animal-species-of-india.php">POPULAR ANIMAL SPECIES OF INDIA</a> 
                <a href="https://www.theearthsafari.com/safari-packing-check-list.php">SAFARI PACKING CHECK LIST</a>
                <a href="https://www.theearthsafari.com/indian-wildlife-map-table.php">INDIAN WILDLIFE MAP TABLE</a>
                <a href="https://www.theearthsafari.com/list-of-tiger-reserves-in-india.php">LIST OF TIGER RESERVES IN INDIA</a> 
                <a href="https://www.theearthsafari.com/india-wildlife-experience.php">INDIAN WILDLIFE EXPERIENCE</a>
                <a href="https://www.theearthsafari.com/destination/kenya">KENYA SAFARI TOURS</a>
                <a href="https://www.theearthsafari.com/destination/tanzania">TANZANIA SAFARI TOURS</a> 
                <a href="https://www.theearthsafari.com/forests-of-india.php">FORESTS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/india-quick-facts.php">INDIA QUICK FACTS</a> 
                <a href="https://www.theearthsafari.com/tips-for-travel-in-india.php">TIPS FOR TRAVEL IN INDIA</a>
                <a href="https://www.theearthsafari.com/india-visa-info.php">INDIA VISA INFO</a>
		  
		</div><!---end of informationBank-->
		
		<div class="links">
			<h6>About The Earth Safari</h6>
			<a href="https://www.theearthsafari.com/">HOME</a>
			<a href="https://www.theearthsafari.com/about-us">ABOUT US</a>
			<a href="https://www.theearthsafari.com/client-testimonials">CLIENT TESTIMONIALS</a>
			<a href="https://www.theearthsafari.com/contact-us">CONTACT US</a>
			<a href="https://www.theearthsafari.com/terms">TERMS &amp; CONDITIONS</a>
			<a href="https://www.theearthsafari.com/sitemap.xml">XML SiteMap</a>
			<a href="https://www.theearthsafari.com/sitemap.html">HTML Site Map</a>
		</div><!---end of informationBank-->
		
		<div class="links">
			<div class="row">
				<div class="col-xs-9 disclaimer"><span>Disclaimer</span>: THE EARTH SAFARI is not liable for any errors or omissions. All pricing is indicative and subject to exchange rate fluctuations.</div>
				<div class="col-xs-3 media">
					<a href="https://plus.google.com/115282885713632754730" target="_blank" rel="nofollow" title="The Earth Safari Google+ Page"><i class="fa fa-google-plus"></i></a>
					<a href="https://www.facebook.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Facebook Page"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Twitter Page"><i class="fa fa-twitter"></i></a>
					<a href="https://www.theearthsafari.com/blog" target="_blank" title="The Earth Safari Blog"><i class="fa fa-wordpress"></i></a>
				</div>
			</div><!---End of row-->
		</div>
		
		<div class="copyright">Copyright &copy; 2011 - 2022 TheEarthSafari.com</div>
	</div>
</footer>

<div class="enquireBox na">
    <a class="toggle" href="javascript:;">Quick Enquiry <i class="fa fa-angle-double-down"></i></a>
    <h4>Send Your Enquiry now</h4>
    <form class="enquiry">
        <div class="enquiry-message"></div>
        <input type="text" name="name" id="name" class="form-control" placeholder="Name"/>
        <input type="email" name="email" id="email" class="form-control" placeholder="Email"/>
        <input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone"/>
        <textarea name="query" id="query" class="form-control" placeholder="Message"></textarea>
        <button type="button" id="enquiry-submit">
            <span id="text">Submit</span>
            <span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
        </button>
    </form>
</div>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37106525-1']);
  _gaq.push(['_setDomainName', 'theearthsafari.com']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Google Code for Remarketing Tag -->
<!--
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
-->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 972714909;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/972714909/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery("#enquiry-submit").click(function() {
        jQuery("#enquiry-submit #text").hide();
        jQuery("#enquiry-submit #loader").show();
        var from = 1;
        var data = jQuery(".enquiry").serialize();
            jQuery.ajax
            ({
            url: 'ajax/email-query.php?'+data,
            dataType: 'html',
            success: function(msg)
            {
                jQuery(".enquiry-message").show();
                jQuery(".enquiry-message").html(msg);
                jQuery("#enquiry-submit #text").show();
                jQuery("#enquiry-submit #loader").hide();
                if (msg == '<span id="success">Thank you for contact with The Earth Safari.</span>') {
                    jQuery("#name").val("");
                    jQuery("#email").val("");
                    jQuery("#phone").val("");
                    jQuery("#query").val("");
                }
                jQuery(".enquiry-message").delay(3000).hide(1000);
            }
        });
        return false;
    });
    jQuery("#nl-submit").click(function() {
        jQuery("#nl-submit #text").hide();
        jQuery("#nl-submit #loader").show();
        var emails = jQuery('#newsletter').val();
        jQuery.ajax
        ({
            type: 'POST',
            url: 'ajax/newsletter.php',
            data: {email:emails},
            dataType: 'html',
            success: function(msg)
            {
                jQuery("#nl-submit #text").show();
                jQuery("#nl-submit #loader").hide();
                jQuery(".newsletter-popup").show("slow");
                jQuery(".newsletter-popup").html(msg);
                jQuery("#newsletter").val('');
                jQuery(".close").click(function () {
                    jQuery(".newsletter-popup").hide("slow");
                });
            }
        });
    });
});
</script>

<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
  d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
  _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
  $.src='//v2.zopim.com/?1ltJ36Z0ARzUAnTSXmu2o4RKs2ndLWHU';z.t=+new Date;$.
  type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->

<script async src="//www.google.com/recaptcha/api.js"></script>

<script>
function onSubmit(token) {
    $("#enquiryForm").submit();
    return true;
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script type="text/javascript">
$().ready(function() {
  $("#enquiryForm").validate({
    rules: {
      name: "required",
      email: {
        required: true,
        email: true
      },
      phone: {
        required: true,
        minlength: 9
      },
      nationality: "required",
      city: "required",
      adult: "required",
      age_children: {
        required: {
            depends: function() {
              return $("#children").val()
            }
        }
      },
      curr_date: "required",
      month: "required",
      year: "required",
      duration: "required"
    },
    submitHandler: function (form) {
        if (grecaptcha.getResponse()) {
                // 2) finally sending form data
                form.submit();
        }else{
                // 1) Before sending we must validate captcha
            grecaptcha.reset();
            grecaptcha.execute();
        }           
    }
  });
});
</script>
<!--..........Javascript Libraries Start Here..........-->	
<script type="text/javascript" src="assets/js/init.js"></script>

</body>
</html>
