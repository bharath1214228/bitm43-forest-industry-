<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tag properties start here -->
      <meta charset="utf-8">

        <meta name="language" content="english">
	  <meta http-equiv="content-language" content="en">

	    <meta name="google-site-verification" content="qYC3doxIvybN5KSFiBXT8IohYU9A9Wmer1u2CG7h110" />

	      <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
	        <meta name="robots" content="NOODP">
		  <meta name="robots" content="index, follow" />
		    <meta name="DC.title" content="Best African Safari & Indian Tiger Safari" >

		      <meta name="description" content="Get to know a comprehensive list of national parks of Kenya where you can do a wildlife safari in Africa. The most famous safari parks include, Masai Mara National Park, Amboseli National Park, Lake Nakuru National Park,Samburu National Park and more." />

		        <meta name="viewport" content="width=device-width, initial-scale=1">

			  <!-- Meta tag properties end here -->
			    <title>Popular National Parks of Kenya- National parks in Kenya for safari.</title>

			      <!-- jQuery library file -->
			        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
				   
				     <base href="" />
				       <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

				         <!--[if lt IE 9]>
					     <script src="assets/js/html5shiv.js"> </script>
					       <![endif]-->
					         <link rel="publisher" href="https://plus.google.com/+Theearthsafaritours"/>
						   <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
						     <!-- CSS file -->
						       <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
						         <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css" />
							   <link rel="stylesheet" href="assets/css/slick.css">
							     <link rel="stylesheet" type="text/css" media="screen, projection" href="assets/css/main.css" />
							       <link rel="stylesheet" href="assets/css/media.css">
</head>

<body class="inner">

<noscript>
<div class="popup-box" style="z-index: 99999999999;"></div>
	<div class="popup-box-container" style="z-index: 99999999999;">
  	<img alt="The Earth Safari" src="assets/img/the-earth-safari-logo.png" style="float:left;" />
    <div class="popup-divider">&nbsp;</div>
    <div class="popup-righ-panel">
    	<span class="popup-heading">Warning!</span>
    	<span class="popup-text">It appears that JavaScript is disabled in your web browser. Please enable it and refresh page to have full system functionality. For instructions on how to enable javascipt in your browser: <a href="http://www.activatejavascript.org/" target="_blank" style="text-decoration: none;" rel="follow" >Click Here</a>.</span>
    </div>
  </div>
</noscript>
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-2 logo"><a href="https://www.theearthsafari.com/"><img src="assets/img/the-earth-safari-logo.png" alt=""/></a></div>
			
			<div class="col-md-10 rightCol">
				<p class="tagline">Inspirational Safaris in India & Africa</p>
				<nav>
					<div class="top">
						<form id="region-selector" name="region_select" action="region.php" method="POST">
							<input type="hidden" name="page" value="http://www.theearthsafari.com/popular-national-parks-of-kenya.php">
															<input type="radio" name="r-selector" value="2" id="africa" onclick="this.form.submit()" style="display: none;">
								<label for="africa">Visit Africa</label>
													</form>

						<a class="menuToggle" href="javascript:;"><i class="fa fa-bars"></i></a>
						<ul>
							<li><a href="https://www.theearthsafari.com/">Home</a></li>
							<li><a href="https://www.theearthsafari.com/about-us">About Us</a></li>
							<li><a href="https://www.theearthsafari.com/client-testimonials">Client testimonials</a></li>
							<li><a href="https://www.theearthsafari.com/contact-us">Contact</a></li>
							<li><a href="https://www.theearthsafari.com/blog">Blog</a></li>
							<li><a href="tel:+91 8447870008">CALL: +91 8447870008</a></li>
						</ul>
					</div><!---End of top-->
					
					<div class="exploreDestination">
						<ul  class="exploreLinkks">
														<li>Explore By : </li>
							<li><a href="javascript:;">Destinations</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/destination/ranthambore-national-park">Ranthambore National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/bandhavgarh-national-park">Bandhavgarh National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kanha-national-park">Kanha National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/pench-national-park">Pench National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/tadoba-andhari-tiger-reserve">Tadoba-Andhari Tiger Reserve</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/jim-corbett-national-park">Jim Corbett National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/gir-forest-national-park">Gir Forest National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kaziranga-national-park">Kaziranga National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/sunderbans-national-park">Sunderbans National Park</a></li>
																	</ul>
							</li>
							<li><a href="javascript:;">Interest</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/interest/tiger-safari-india">Tiger Safari India</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-high-end-luxury-safaris">India High End Luxury Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-short-duration-safaris">India Short Duration Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-culture-and-heritage-tours">India Culture and Heritage Tours</a></li>
																	</ul>
							</li>
							<li><a href="https://www.theearthsafari.com/private-safari.php">Private Safari</a></li>
							<li><a href="https://www.theearthsafari.com/group-safari.php">Group Safari</a></li>
						</ul>
					</div><!--end  of exploreDestination-->
				</nav>
			</div>
		</div><!-- End of row -->
	</div><!-- End of container-->
</header>

<section class="masterSection">
	<div class="container">
		<div class="grayBg margin-top-50">
			<div class="row safariList">
				<div class="col-md-9">
					<div class="title"><h2>National Parks of Kenya</h2></div>
					<h5 class="text-orange">Masai Mara National Park</h5>
					<p>The Masai Mara, now the new 7th wonder of the world and 4th most preferred tourist destination in the world is a home to wildlife in such abundance and variety that it is difficult to imagine the annual migration of the wildebeest and the zebras starts from the Serengeti as they search for water and pasture while at the same time being followed on their heels by the predators of the savannah; Lion, cheetah, wild dog, jackal, hyena, and vultures. It hosts over 450 species of animals which includes lions, rhinos, hippos, crocodiles, giraffe, wildebeests, zebras, buffalo, leopard, many kinds of antelopes and elephants.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Amboseli National Park</h5>
					<p>Amboseli National Park is famous for its huge elephant herds. Africa's highest mountain, Mount Kilimanjaro sits in the upper slopes of Amboseli national park. Mt Kilimanjaro’s snow white peaks lie across the border of Tanzania. Seeing Kilimanjaro hovering above the clouds in the early hours of the morning is quite an experience. For an enthusiastic photographer, taking pictures arising against the dramatic backdrop of the mountain is quite a thrill. Apart from the elephants, buffalos, black rhino and other plain animals are in plenty.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Lake Nakuru National Park</h5>
					<p>Lake Nakuru National Park is a sea of flaming pink as far as the eye can see. These millions of flamingoes are always seeking for their food in the salty deep green waters of Lake Nakuru. The protected area is primarily for birds of which 400 to 500 species can be found here including cormorants and pelicans. Visitors to Lake Nakuru National Park are also sure to catch a glimpse of Thomson gazelles, impala, waterbucks, giraffes, and buffalos, white and black rhino as well as baboons.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Samburu National Park</h5>
					<p>Samburu National Park is a wildlife haven. Here you will spot Africa's big cats-lions, cheetahs and the elusive leopard. Some animals are unique to this northern Kenya Park; gravy's zebra, reticulated giraffe, kudus and gerenuk. The Ewaso Nyiro River, the boundary with the neighbouring buffalo springs national reserve, is where the elephants buffaloes and other animal species gather for a drink. You will find the scenic semiarid landscape quite dramatic. The reserve is located within the lands of the colourful semi-nomadic Samburu tribesmen.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Mt. Kenya National Park</h5>
					<p>Mt. Kenya National Park is located to the east of the Great Rift Valley and is the second highest peak in Africa. Mt. Kenya is an important water tower in the country as it provides water for about 50% of the country’s population and produces 70% of Kenya’s hydroelectric power. It is described as one of the most impressive landscapes in Eastern Africa with its rugged glacier-clad summits, Afro-alpine moorlands and diverse forests that illustrate outstanding ecological processes. Major attractions within the park include pristine wilderness, lakes, tarns, glaciers and peaks of great beauty, geological variety, forest, mineral springs, rare and endangered species of animals. Animals likely to be spotted in this park are black and white Colobus, Sykes monkey, bushbuck, buffalo, and elephant. At lower altitudes, animals like the olive baboon, waterbuck, black rhino, black fronted, duiker, leopard, giant forest hog, genet cat, bush pig and hyena are found. A rare sighting is the elusive bongo, a forest antelope.</p>
					<p><a href="javascript:;">Kenya Wildlife Safari Tours</a></p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Aberdare National Park</h5>
					<p>Aberdare National Park covers the higher areas of the Aberdare Mountains of central Kenya. The topography is diverse with deep ravines that cut through the forested eastern and western slopes. Animals easily observed in the park include; the Black Rhino, leopard, baboon, black and white Colobus monkey and Sykes monkey. Rarer sightings include those of lions, the golden cat and the bongo- an elusive forest antelope that lives in the bamboo forest. Animals like the eland and serval cats can be found higher up in the moorlands. Activities that can be enjoyed in this park include picnics, trout fishing in the rivers and camping in the moorlands. Bird viewing is rewarding, with over 250 species of birds in the park, including the Jackson's Francolin, Sparry hawk, goshawks, eagles, sunbirds and plovers.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Lake Naivasha</h5>
					Lake Naivasha is the highest of all the Rift Valley Lakes at 1880 m above sea level. Being a fresh water lake, it has the greatest number of residents living on its shore. It has become the centre of the booming horticultural export business which is one of Kenya’s leading foreign exchange earner. This area is a birdwatcher's paradise with over 450 species of recorded birds in the area, which are attracted by the yellow-barked acacia trees and blue water lilies. A small islet on the lake is home to a number of wildlife. Visitors can enjoy a boat ride safari as they view wildlife and birds from the tranquil lake. A private ranch (Kongoni Game Sanctuary) is located in the area which is a home to lions, leopards, cheetah and some translocated Gravy’s zebras.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Tsavo East National Park</h5>
					<p>Tsavo East National Park offers a vast and untapped arena of arid bush which is washed by azure and emerald meandering of Galana River. The park is guarded by the limitless lava reaches of Yatta plateau and patrolled by some of the largest elephant herds in Kenya. Major attractions within the park include dust-red elephants wallowing, rolling and spraying each other with the midnight blue waters of palm-shaded Galana River; the beautiful Aruba dam located on the north bank of the seasonal Voi River, visited by thousands of animals and a great game viewing destination; Mudanda Rock, which is a whale –backed Rock tower located above a natural dam, and which acts as a draw to thousands of Elephants; Lugards Falls, named after Captain Lugard, the first proconsul to East Africa, the falls feature bizarrely eroded rocks through which the waters of the Galana River plunge into foaming rapids and crocodile –infested pools. The park is also home to rhino, buffalo, lion, leopard, and pods of hippo, crocodile, and waterbucks, Lesser Kudu, Gerenuk and Hirola. Other activities available include camping, trekking and bird watching.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Tsavo West National Park</h5>
					<p>Tsavo West National Park consists of savannah ecosystem comprising of open grasslands, scrublands, and Acacia woodlands, belts of riverine vegetation and rocky ridges. Major wildlife found in the park include elephant, rhino, Hippos, lions, cheetah, wild dogs, giraffe, zebra, crocodile, mongoose, hyrax, dik dik, lesser kudu leopards, Buffalos, nocturnal porcupine as well as diverse plant and bird species including the threatened corncrake and near threatened Basra Reed Warbler. Major attractions within the park include recent Volcanoes; lava flows and caves with potential for geological studies; cave exploration and hiking the magical Mzima Springs; underwater hippo and fish watching.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Meru National Park</h5>
					<p>Meru National Park was made famous by conservationists George and Joy Adamson, and the film based on their book Born Free, the famous story of Elsa the lioness. Meru is a park of great scenic beauty, featuring 13 rivers and supporting a wide range of diverse habitats. It is a paradise for birdwatchers and home to several rare bird species. A section of the park has been designated a wilderness area with no roads, which adds to the air of wild, remote seclusion that is characteristic of Meru National Park.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Sweetwaters Game Reserve</h5>
					<p>Sweetwaters Game Reserve is 24,000 acres of privately owned wilderness in the heart of the Laikipia area of Kenya. Its game-to-area ratio tops the Kenyan park and reserve league It is the only park where the big 5 and chimpanzees can be seen and is also where the fastest growing population of rhino in Africa can be found. The reserve boasts abundant wildlife - over 400 species of birds, lion, elephant, rhino and cheetah to name just a few. Sweetwaters is noted for its black rhino and elephant, hippo, lion, giraffe, zebra, eland, warthog, Oryx, impala, gazelles etc. Night game drives offer opportunities of seeing some of the nocturnal animals like aardvark or even leopard. Within Sweetwaters there is a chimpanzee sanctuary where rescued chimpanzees are being looked after by a dedicated team. A visit to the sanctuary is a rewarding experience. At the visitors' information centre there is a small museum and nearby a tame black rhino, named Morani, reared as an orphan by the Kenya Wildlife Service. You can approach this fully-grown adult male black rhino quite safely on foot, escorted by a ranger.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Shaba National Reserve</h5>
					<p>Shaba National Reserve has a particular place in the history of Kenya game conservation for it was in this reserve that the authoress, Joy Adamson, died, her trilogy of books on the rehabilitation of the compliant leopard to a wild environment remained unfinished. Shaba was one of Joy Adamson's greatest African loves; it was in this tranquil wilderness where she released the first hand-raised leopards Shaba took its name from the Mount Shaba (1525 meters), a volcanic mountain that became extinct around 5,000 years ago. Mount Shaba lies on the border of the reserve.</p>
					<p>Animals commonly seen are elephants, lions, cheetahs, grevy's zebras, giraffes, gerenuks, buffalos, oryx, grants gazelles, dikdiks and waterbucks. The river forest attracts a wide variety of birds.</p> 
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Buffalo Springs National Reserve</h5>
					<p>Buffalo Springs National Reserve is separated from the Samburu National Reserve by the Ewaso Ngiro river; less hilly and less dense than its Samburu, it is equally as attractive. Buffalo Springs National Reserve takes its name from an oasis of limpid crystal clear water at the western end of the sanctuary. In addition to the wildlife found in Samburu National Reserve, the common zebra is also an attraction often marching with its cousin, the Grevy Zebra, although they do not interbreed.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Nairobi National Park</h5>
					<p>Nairobi National Park is a unique ecosystem by being the only protected area in the world close to a capital city. The park is located only 7 km from Nairobi city centre. The savannah ecosystem comprise of different vegetation types. Open grass plains with scattered acacia bush are predominant. The western side has a highland dry forest and a permanent river with a riverine forest. To the south are the Athi-Kapiti Plains and Kitengela migration corridor which are important wildlife dispersal areas during the rain season. Man-made dams within the park have added a further habitat, favourable to certain species of birds and other aquatic biome. Major wildlife attractions are the Black rhino, lion, leopard, cheetah, hyena, buffaloes, Giraffe, zebra, wildebeest, elands and diverse birdlife with over 400 species recorded. Other attractions include the Ivory burning site Monument, Nairobi Safari Walk, the Orphanage and the walking trails at hippo pools.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Lewa Downs</h5>
					<p>Lewa Downs was once a cattle ranch; it then became a guarded black rhino sanctuary, and it is now the headquarters for a non-profit wildlife Conservancy, which has gained a world-wide reputation for extending the benefits of conservation beyond its borders. The Craig/Douglas family first came to Lewa Downs in 1922 and managed it as a cattle ranch for over 50 years. Unlike many other ranchers in the area, they had always valued the wildlife that shared the land with the cattle and developed wildlife tourism as an additional activity.</p>
					<p>By the early 1980s it was uncertain whether any black rhinos would survive in Kenya. Poaching for horn had reduced Kenya’s rhinos from some 20,000 in the mid-1970s to a few hundred by 1986. It was clear that the only way to prevent their complete extinction was to create high security sanctuaries.</p>
					<p>In 1983 the Craigs and Mrs. Anna Merz — who funded the program — decided to establish the fenced and guarded Ngare Sergoi Rhino Sanctuary at the western end of Lewa Downs. The rhino sanctuary was stocked partly with animals from other reserves and partly by isolated individuals from northern Kenya, whose likely survival was a matter of months at most. The black rhino that were caught settled down and bred, and white rhino were added. After ten years, it was clear that the rhinos needed more space, and the sanctuary was expanded to cover the rest of the ranch, and the adjoining Ngare Ndare Forest Reserve.</p>
					<p>The perimeter was almost entirely fenced, for security and to ensure that elephants did not raid crops in neighboring farms, but the ecological connections between Lewa and neighboring wildlife areas were maintained by leaving gaps in the fence for animal movements. At the same time the entire property was converted to a wildlife sanctuary, as the Craig family handed over the management of the ranch to a non-profit organization — the Lewa Wildlife Conservancy.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Lake Bogoria</h5>
					<p>Lake Bogoria is a located in the northern Kenyan Rift Valley. The lake is famous for the pink flamingoes which are found in large numbers. Geothermal activity in the form of hot springs and geysers are located on the western shore.</p>
					<p>Lake Bogoria has the largest number of geyers in Africa. Lake Bogoria is possibly the most interesting of the Kenyan Rift Valley lakes. The lake is 17 x 3.5 km, and occupies a narrow, asymmetric half-graben within the rift floor. Bogoria Escarpment rises 700 m on the eastern side of the lake. A magnitude 7.0 earthquake occurred at the lake in 1828. The lake is alkaline, feeding blue-green algae which in turn feed flamingoes. At times the number of flamingoes feeding in the lake may be as high as two million. Raptors such as tawny eagles prey on the flamingoes. In total, 135 species of bird have been recorded. They include little grebe, pratincole, swift, little bee-eater, cape wigeon, yellow-billed stork, African spoonbill, augur buzzard, gabar goshawk, water dikkop, gret tit, starling, hornbill and crombec.</p>
					<p>The reserve has a herd of the relatively uncommon Greater Kudu. Other large mammals include buffalo, zebra, cheetah, baboon, warthog, caracal, spotted hyena, impala and dik dik.</p>
				</div><!---End of col-sm-8-->
				
				<div class="col-md-3">
	<form class="newsLetter" type="post">
		<input type="email" name="newsletter" id="newsletter" placeholder="Enter your email address" />
		<button type="button" name="button" id="nl-submit">
			<span id="text"><i class="fa fa-check-square-o"></i></span>
			<span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
		</button>
	</form>
	
	<p class="saranVaid"><a href="http://www.saranvaid.com" target="_blank" rel="nofollow"><img src="assets/img/saran-vaid-img.jpg" alt=""></a></p>
</div><!---End of col-sm-3-->				
			</div><!---End of row-->
		<!--end of grayBg-->
	</div>
</section>

<footer>
	<div class="container">
		<p class="membership"><a href="https://www.theearthsafari.com/wildlife-associations.php" title="African Travel & Tourism Association"><img src="assets/img/memberships.jpg" alt="African Travel & Tourism Association" /></a></p>
		
		<div class="links">
			<h6>Information Bank</h6>

							<a href="https://www.theearthsafari.com/responsible-ecotourism.php">RESPONSIBLE ECOTOURISM</a> 
                <a href="https://www.theearthsafari.com/safari-code-of-conduct.php">SAFARI CODE OF CONDUCT</a>
                <a href="https://www.theearthsafari.com/destination/ranthambore-national-park">RANTHAMBORE NATIONAL PARK</a>
                <a href="https://www.theearthsafari.com/interest/tiger-safari-india">TIGER SAFARI INDIA</a>
                <a href="https://www.theearthsafari.com/wildlife-photography-tips.php">WILDLIFE PHOTOGRAPHY TIPS</a> 
                <a href="https://www.theearthsafari.com/checklist-of-birds-of-india.php">CHECKLIST OF BIRDS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/popular-animal-species-of-india.php">POPULAR ANIMAL SPECIES OF INDIA</a> 
                <a href="https://www.theearthsafari.com/safari-packing-check-list.php">SAFARI PACKING CHECK LIST</a>
                <a href="https://www.theearthsafari.com/indian-wildlife-map-table.php">INDIAN WILDLIFE MAP TABLE</a>
                <a href="https://www.theearthsafari.com/list-of-tiger-reserves-in-india.php">LIST OF TIGER RESERVES IN INDIA</a> 
                <a href="https://www.theearthsafari.com/india-wildlife-experience.php">INDIAN WILDLIFE EXPERIENCE</a>
                <a href="https://www.theearthsafari.com/destination/kenya">KENYA SAFARI TOURS</a>
                <a href="https://www.theearthsafari.com/destination/tanzania">TANZANIA SAFARI TOURS</a> 
                <a href="https://www.theearthsafari.com/forests-of-india.php">FORESTS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/india-quick-facts.php">INDIA QUICK FACTS</a> 
                <a href="https://www.theearthsafari.com/tips-for-travel-in-india.php">TIPS FOR TRAVEL IN INDIA</a>
                <a href="https://www.theearthsafari.com/india-visa-info.php">INDIA VISA INFO</a>
		  
		</div><!---end of informationBank-->
		
		<div class="links">
			<h6>About The Earth Safari</h6>
			<a href="https://www.theearthsafari.com/">HOME</a>
			<a href="https://www.theearthsafari.com/about-us">ABOUT US</a>
			<a href="https://www.theearthsafari.com/client-testimonials">CLIENT TESTIMONIALS</a>
			<a href="https://www.theearthsafari.com/contact-us">CONTACT US</a>
			<a href="https://www.theearthsafari.com/terms">TERMS &amp; CONDITIONS</a>
			<a href="https://www.theearthsafari.com/sitemap.xml">XML SiteMap</a>
			<a href="https://www.theearthsafari.com/sitemap.html">HTML Site Map</a>
		</div><!---end of informationBank-->
		
		<div class="links">
			<div class="row">
				<div class="col-xs-9 disclaimer"><span>Disclaimer</span>: THE EARTH SAFARI is not liable for any errors or omissions. All pricing is indicative and subject to exchange rate fluctuations.</div>
				<div class="col-xs-3 media">
					<a href="https://plus.google.com/115282885713632754730" target="_blank" rel="nofollow" title="The Earth Safari Google+ Page"><i class="fa fa-google-plus"></i></a>
					<a href="https://www.facebook.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Facebook Page"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Twitter Page"><i class="fa fa-twitter"></i></a>
					<a href="https://www.theearthsafari.com/blog" target="_blank" title="The Earth Safari Blog"><i class="fa fa-wordpress"></i></a>
				</div>
			</div><!---End of row-->
		</div>
		
		<div class="copyright">Copyright &copy; 2011 - 2022 TheEarthSafari.com</div>
	</div>
</footer>

<div class="enquireBox na">
    <a class="toggle" href="javascript:;">Quick Enquiry <i class="fa fa-angle-double-down"></i></a>
    <h4>Send Your Enquiry now</h4>
    <form class="enquiry">
        <div class="enquiry-message"></div>
        <input type="text" name="name" id="name" class="form-control" placeholder="Name"/>
        <input type="email" name="email" id="email" class="form-control" placeholder="Email"/>
        <input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone"/>
        <textarea name="query" id="query" class="form-control" placeholder="Message"></textarea>
        <button type="button" id="enquiry-submit">
            <span id="text">Submit</span>
            <span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
        </button>
    </form>
</div>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37106525-1']);
  _gaq.push(['_setDomainName', 'theearthsafari.com']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Google Code for Remarketing Tag -->
<!--
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
-->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 972714909;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/972714909/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery("#enquiry-submit").click(function() {
        jQuery("#enquiry-submit #text").hide();
        jQuery("#enquiry-submit #loader").show();
        var from = 1;
        var data = jQuery(".enquiry").serialize();
            jQuery.ajax
            ({
            url: 'ajax/email-query.php?'+data,
            dataType: 'html',
            success: function(msg)
            {
                jQuery(".enquiry-message").show();
                jQuery(".enquiry-message").html(msg);
                jQuery("#enquiry-submit #text").show();
                jQuery("#enquiry-submit #loader").hide();
                if (msg == '<span id="success">Thank you for contact with The Earth Safari.</span>') {
                    jQuery("#name").val("");
                    jQuery("#email").val("");
                    jQuery("#phone").val("");
                    jQuery("#query").val("");
                }
                jQuery(".enquiry-message").delay(3000).hide(1000);
            }
        });
        return false;
    });
    jQuery("#nl-submit").click(function() {
        jQuery("#nl-submit #text").hide();
        jQuery("#nl-submit #loader").show();
        var emails = jQuery('#newsletter').val();
        jQuery.ajax
        ({
            type: 'POST',
            url: 'ajax/newsletter.php',
            data: {email:emails},
            dataType: 'html',
            success: function(msg)
            {
                jQuery("#nl-submit #text").show();
                jQuery("#nl-submit #loader").hide();
                jQuery(".newsletter-popup").show("slow");
                jQuery(".newsletter-popup").html(msg);
                jQuery("#newsletter").val('');
                jQuery(".close").click(function () {
                    jQuery(".newsletter-popup").hide("slow");
                });
            }
        });
    });
});
</script>

<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
  d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
  _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
  $.src='//v2.zopim.com/?1ltJ36Z0ARzUAnTSXmu2o4RKs2ndLWHU';z.t=+new Date;$.
  type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->

<script async src="//www.google.com/recaptcha/api.js"></script>

<script>
function onSubmit(token) {
    $("#enquiryForm").submit();
    return true;
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script type="text/javascript">
$().ready(function() {
  $("#enquiryForm").validate({
    rules: {
      name: "required",
      email: {
        required: true,
        email: true
      },
      phone: {
        required: true,
        minlength: 9
      },
      nationality: "required",
      city: "required",
      adult: "required",
      age_children: {
        required: {
            depends: function() {
              return $("#children").val()
            }
        }
      },
      curr_date: "required",
      month: "required",
      year: "required",
      duration: "required"
    },
    submitHandler: function (form) {
        if (grecaptcha.getResponse()) {
                // 2) finally sending form data
                form.submit();
        }else{
                // 1) Before sending we must validate captcha
            grecaptcha.reset();
            grecaptcha.execute();
        }           
    }
  });
});
</script>
<!--..........Javascript Libraries Start Here..........-->	
<script src="assets/js/slick.js"></script>
<script type="text/javascript" src="assets/js/init.js"></script>

</body>
</html>
