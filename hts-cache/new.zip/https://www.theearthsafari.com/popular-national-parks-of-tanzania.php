<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tag properties start here -->
      <meta charset="utf-8">

        <meta name="language" content="english">
	  <meta http-equiv="content-language" content="en">

	    <meta name="google-site-verification" content="qYC3doxIvybN5KSFiBXT8IohYU9A9Wmer1u2CG7h110" />

	      <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
	        <meta name="robots" content="NOODP">
		  <meta name="robots" content="index, follow" />
		    <meta name="DC.title" content="Best African Safari & Indian Tiger Safari" >

		      <meta name="description" content="The national parks of Tanzania list if huge to quench the need of any wildlife safari enthusiast. The popular national park list consists of Serengeti National Park,Ngorongoro Conservation Area, Lake Manyara National Park,Tarangire National Park,Arusha National Park and more." />

		        <meta name="viewport" content="width=device-width, initial-scale=1">

			  <!-- Meta tag properties end here -->
			    <title>Popular National Parks of Tanzania- Tanzania National Park Safari.</title>

			      <!-- jQuery library file -->
			        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
				   
				     <base href="" />
				       <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

				         <!--[if lt IE 9]>
					     <script src="assets/js/html5shiv.js"> </script>
					       <![endif]-->
					         <link rel="publisher" href="https://plus.google.com/+Theearthsafaritours"/>
						   <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
						     <!-- CSS file -->
						       <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
						         <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css" />
							   <link rel="stylesheet" href="assets/css/slick.css">
							     <link rel="stylesheet" type="text/css" media="screen, projection" href="assets/css/main.css" />
							       <link rel="stylesheet" href="assets/css/media.css">
</head>

<body class="inner">

<noscript>
<div class="popup-box" style="z-index: 99999999999;"></div>
	<div class="popup-box-container" style="z-index: 99999999999;">
  	<img alt="The Earth Safari" src="assets/img/the-earth-safari-logo.png" style="float:left;" />
    <div class="popup-divider">&nbsp;</div>
    <div class="popup-righ-panel">
    	<span class="popup-heading">Warning!</span>
    	<span class="popup-text">It appears that JavaScript is disabled in your web browser. Please enable it and refresh page to have full system functionality. For instructions on how to enable javascipt in your browser: <a href="http://www.activatejavascript.org/" target="_blank" style="text-decoration: none;" rel="follow" >Click Here</a>.</span>
    </div>
  </div>
</noscript>
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-2 logo"><a href="https://www.theearthsafari.com/"><img src="assets/img/the-earth-safari-logo.png" alt=""/></a></div>
			
			<div class="col-md-10 rightCol">
				<p class="tagline">Inspirational Safaris in India & Africa</p>
				<nav>
					<div class="top">
						<form id="region-selector" name="region_select" action="region.php" method="POST">
							<input type="hidden" name="page" value="http://www.theearthsafari.com/popular-national-parks-of-tanzania.php">
															<input type="radio" name="r-selector" value="2" id="africa" onclick="this.form.submit()" style="display: none;">
								<label for="africa">Visit Africa</label>
													</form>

						<a class="menuToggle" href="javascript:;"><i class="fa fa-bars"></i></a>
						<ul>
							<li><a href="https://www.theearthsafari.com/">Home</a></li>
							<li><a href="https://www.theearthsafari.com/about-us">About Us</a></li>
							<li><a href="https://www.theearthsafari.com/client-testimonials">Client testimonials</a></li>
							<li><a href="https://www.theearthsafari.com/contact-us">Contact</a></li>
							<li><a href="https://www.theearthsafari.com/blog">Blog</a></li>
							<li><a href="tel:+91 8447870008">CALL: +91 8447870008</a></li>
						</ul>
					</div><!---End of top-->
					
					<div class="exploreDestination">
						<ul  class="exploreLinkks">
														<li>Explore By : </li>
							<li><a href="javascript:;">Destinations</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/destination/ranthambore-national-park">Ranthambore National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/bandhavgarh-national-park">Bandhavgarh National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kanha-national-park">Kanha National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/pench-national-park">Pench National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/tadoba-andhari-tiger-reserve">Tadoba-Andhari Tiger Reserve</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/jim-corbett-national-park">Jim Corbett National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/gir-forest-national-park">Gir Forest National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kaziranga-national-park">Kaziranga National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/sunderbans-national-park">Sunderbans National Park</a></li>
																	</ul>
							</li>
							<li><a href="javascript:;">Interest</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/interest/tiger-safari-india">Tiger Safari India</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-high-end-luxury-safaris">India High End Luxury Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-short-duration-safaris">India Short Duration Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-culture-and-heritage-tours">India Culture and Heritage Tours</a></li>
																	</ul>
							</li>
							<li><a href="https://www.theearthsafari.com/private-safari.php">Private Safari</a></li>
							<li><a href="https://www.theearthsafari.com/group-safari.php">Group Safari</a></li>
						</ul>
					</div><!--end  of exploreDestination-->
				</nav>
			</div>
		</div><!-- End of row -->
	</div><!-- End of container-->
</header>

<section class="masterSection">
	<div class="container">
		<div class="grayBg margin-top-50">
			<div class="row safariList">
				<div class="col-md-9">
					<div class="title"><h2>National Parks of Tanzania</h2></div>
					<h5 class="text-orange">Serengeti National Park</h5>
					<p>Serengeti comes from the Maasai word "Siring" meaning "Endless Plain", which really is what it means: hundreds of kilometers of flat surface land, better termed "The Sea of Grass On Plains". The first understanding about Serengeti comes from its distinction of the ecosystem from the Serengeti National Park itself.</p>
					<p>The ecosystem encompasses the following: Ngorongoro Crater Conservation Area in the south east, Ikorongo, Grumeti and Maswa Game Reserves in the western pockets, the Loliondo Game Control Area (also known as government approved hunting blocks) in the north east, and in the north by the famous Masai Mara National Reserve, Kenya, thus the Serengeti National Park itself is cushioned within these game control and reserves. The Serengeti ecosystem is approximately 27,000 square kilometers and the park is documented at 14,763 square kilometers.</p>
					<p>Serengeti National Park is the staging-zone for one the most spectacular events in the natural world: the annual migration of millions of wildebeest. This commences around June when over 1 million wildebeest, zebra and gazelle head for the Maasai Mara in Kenya in search of pasture. They are followed closely by the predators of the savanna- lion, cheetah, wild dog, jackal, hyena and vultures. The Serengeti also has over 500 species of birds. Check for the various packages offered by us including Serengeti Tours from The Earth Safari.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Ngorongoro Conservation Area</h5>
					<p>The first view of the Ngorongoro Crater is breath taking. The huge caldera (collapsed volcano) covering 25 km in size and 600m deep is an amazing site of the crater. The crater is home to Tanzania’s only remaining Black Rhino population. The elephant, Hippo, Zebra, Antelope, Gazelle, and small creatures such as frogs, snakes and serval cats are also common in this beautiful reserve. The Maskat Soda Lake located inside the crater is a great attraction for flamingos and other water birds making the crater a bird watcher’s haven. The crater is also known for its rich history. It is believed that the earliest sign of mankind (the homo-habilis) was spotted here. It is in this crater that hominid footprints are preserved in a volcanic rock 3.6 m years old.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Lake Manyara National Park</h5>
					<p>Lake Manyara is a lovely scenic park on the road from Arusha to the Ngorongoro Crater. The lake itself takes up much of the park leaving a strip of land running down its shores where game concentrates. Famous for its tree climbing lions, good elephants and baboons, Manyara is often visited for an afternoon's game drive on the way to Ngorongoro. The only negative of this Safari in Tanzania in Lake Manyara is how busy it can be, but spend longer, move deeper into the park, and you can avoid the crowds. Overall a great introduction to safari, but a park that is not a patch on its neighbor. Lake Manyara National Park: Lake Manyara is a lovely scenic park on the road from Arusha to the Ngorongoro Crater. The lake itself takes up much of the park leaving a strip of land running down its shores where game concentrates. Famous for its tree climbing lions, good elephants and baboons.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Tarangire National Park</h5>
					<p>Tarangire National Park is one of the few national parks in Tanzania, who flora and fauna have not been elaborately described to prospective guest, making the park being overlooked and skipped during the Tanzania's northern circuit safaris. Apart from Tarangire National Park's collage of varied colors of vegetation, supported by the water system to create a fantastic hue, the park is home to large concentrations of wildlife, all which can be observed from multiple angles: from the incredible views on the hilltop at Tarangire Safari Lodge where all one needs to do is perch themselves on a chair with a pair of binoculars or experience an alternative game viewing experience at superb camps such as Swala, where the wildlife and the action that follow it are less than 15 feet away from a guest's tent. The birdlife at Tarangire are unmatched attracting 550 species seen easily on the Acacia and Baobab trees and on the riverbeds of the Tarangire River.</p>
					<p>Tarangire National Park has the highest number of elephants in the whole of the northern Tanzania parks, exceeding Lake Manyara and Serengeti. There have also been a 550 bird species recorded in the Tarangire National Park, making a sure pleaser for any bird lover. The park displays a diverse number of wildlife namely: elephant, lesser and great kudu, African buffalo, cheetah, fringe-eared Oryx, leopard, lion, Maasai giraffe, spotted hyena, common zebra, white-bearded wildebeest, warthog, eland, olive baboon, bat-eared fox, impala, common waterbuck, bushbuck, coke's hartebeest, gerenuk, and bohor reedbuck.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Arusha National Park</h5>
					<p>Arusha National Park, often overlooked, is in fact a treasure, a rich tapestry of habitats, teeming with animals and birds. From the lush swamps of the Ngurdoto Crater to the tranquil beauty of the Momela Lakes and the rocky alpine heights of Mount Meru, the terrain of the park is as varied as it is interesting. Zebras graze on the park's red grasslands, and leopards lurk next to waterfalls in the shadowy forest. More than 400 species of bird, both migrant and resident can be found in Arusha National Park alongside rare primates such as the black-and-white colobus monkey.</p>
					<p>The rewarding climb up Mount Meru passes through forests of dripping Spanish moss, carpeted with clover and rises to open heath, spiked with giant lobelia plants. Delicate klipspringer antelope watch the progress of hikers from the top of huge boulders, and everlasting flowers cling to the alpine desert underfoot. Once astride the craggy summit, the reward is a sight of Mount Kilimanjaro, breathtaking in the sunrise.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Ruaha National Park</h5>
					<p>Ruaha National Park is located in south-central Tanzania. The boundary is a national park and is cushioned by multiple ecosystems: to the north of the Ruaha National Park lies Rungwa, Kizigo and Muhesi Game Reserves and to the east are the Rubeho Mountains and Iringa Highlands. The term Ruaha, referring to the river that runs through it, actually comes from "Luvaha", which means water stream, which is more of a generic terminology traditionally used by the natives of the region: The Hehe people.</p>
					<p>The actual indigenous name for the Great Ruaha River is "Lyambangari", pronounced li-yam-bahn-gar-ee. Ruaha National park formally came into existence in 1964 when it was given National Park status, and its relationship with the ecosystem it shared with the northern game reserves forced an official boundary survey in 1973 to what it currently stands: 12,950 square kilometers. Ruaha National Park, the second largest National Park after Serengeti, is in its pristine ecological condition: It is a less frequented park making any visitors experience, a unique one.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Selous Game Reserve</h5>
					<p>Selous Game Reserve Located in Southern Tanzania, is Africa's largest game reserve and one of our favourite game viewing areas in Africa. Much quieter than the Northern parks, the rivers and lakes of the Selous are the lifeblood to a park that hosts phenomenal volumes of game including Africa's largest elephant and wild dog populations and probably it's largest buffalo, hippo, crocodile and lion prides. The reality is that this park is so vast it is impossible to count its game and that is exactly what we love about it; Selous is untouched.</p>
					<p>African wilderness and is yet easily accessible from Dar and Zanzibar. Home to some of Africa's best boat safaris, walking and fly camping trips make the Selous the park in Tanzania with the greatest diversity of safari activities. A great place for the safari enthusiast but also a great introduction to unspoilt Africa.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Katavi National Park</h5>
					<p>Katavi National Park in Western Tanzania is remote and wild, a destination for the true safari aficionado. The name of the park immortalizes a legendary hunter, Katabi, whose spirit is believed to possess a tamarind tree ringed with offerings from locals begging his blessings.</p>
					<p>Despite being Tanzania's third-largest park, Katavi sees relatively few visitors, meaning that those guests who arrive here can look forward to having this huge untouched wilderness to themselves.</p>
					<p>The park's main features are the watery grass plains to the north, the palm-fringed lake Chada in the southeast and the Katuma River. Katavi boasts Tanzania's greatest populations of both crocodile and hippopotamus. Lion and leopard find prey among the huge populations of herbivores at Katavi - impala, eland, topi, zebra and herds of up to 1600 buffalo wander the short grass plains. The rare, honey-coloured puku antelope is one of the park's richest wildlife viewing rewards.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Lake Eyasi</h5>
					<p>Lake Eyasi lies on the southern border of the Ngorongoro Conservation area and is Tanzania’s largest soda lake. This area is where the Wahadzabi hunter-gatherers live. Spend the days exploring on foot this dry and rugged landscape, which is still inhabited by this small group of Bushmen. They live in bands, hunting with bows and arrows; gathering roots, tubers and wild fruits, similar to the way man lived 10,000 years ago. Another interesting tribe in this area is the Datoga (also called the Barabaig or Mang'ati). Initially, they were exercising a lot of rivalry over grazing land with the Maasai, but this is a thing of the past.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Lake Victoria</h5>
					<p>Lake Victoria is the largest lake in Africa, world's second largest freshwater lake and world's largest tropical lake, and the source of the mightiest River Nile that flows all the way to Egypt and the Mediterranean. The lake was discovered in 1858 by the British explorer John Speke who named the lake after the Queen of England. It size totals to 69,000 sq km. The lake is about the size of Switzerland, and twice the size of Wales, and borders Uganda, Tanzania and Kenya.</p>
				</div><!---End of col-sm-8-->
				
				<div class="col-md-3">
	<form class="newsLetter" type="post">
		<input type="email" name="newsletter" id="newsletter" placeholder="Enter your email address" />
		<button type="button" name="button" id="nl-submit">
			<span id="text"><i class="fa fa-check-square-o"></i></span>
			<span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
		</button>
	</form>
	
	<p class="saranVaid"><a href="http://www.saranvaid.com" target="_blank" rel="nofollow"><img src="assets/img/saran-vaid-img.jpg" alt=""></a></p>
</div><!---End of col-sm-3-->				
			</div><!---End of row-->
		<!--end of grayBg-->
	</div>
</section>

<footer>
	<div class="container">
		<p class="membership"><a href="https://www.theearthsafari.com/wildlife-associations.php" title="African Travel & Tourism Association"><img src="assets/img/memberships.jpg" alt="African Travel & Tourism Association" /></a></p>
		
		<div class="links">
			<h6>Information Bank</h6>

							<a href="https://www.theearthsafari.com/responsible-ecotourism.php">RESPONSIBLE ECOTOURISM</a> 
                <a href="https://www.theearthsafari.com/safari-code-of-conduct.php">SAFARI CODE OF CONDUCT</a>
                <a href="https://www.theearthsafari.com/destination/ranthambore-national-park">RANTHAMBORE NATIONAL PARK</a>
                <a href="https://www.theearthsafari.com/interest/tiger-safari-india">TIGER SAFARI INDIA</a>
                <a href="https://www.theearthsafari.com/wildlife-photography-tips.php">WILDLIFE PHOTOGRAPHY TIPS</a> 
                <a href="https://www.theearthsafari.com/checklist-of-birds-of-india.php">CHECKLIST OF BIRDS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/popular-animal-species-of-india.php">POPULAR ANIMAL SPECIES OF INDIA</a> 
                <a href="https://www.theearthsafari.com/safari-packing-check-list.php">SAFARI PACKING CHECK LIST</a>
                <a href="https://www.theearthsafari.com/indian-wildlife-map-table.php">INDIAN WILDLIFE MAP TABLE</a>
                <a href="https://www.theearthsafari.com/list-of-tiger-reserves-in-india.php">LIST OF TIGER RESERVES IN INDIA</a> 
                <a href="https://www.theearthsafari.com/india-wildlife-experience.php">INDIAN WILDLIFE EXPERIENCE</a>
                <a href="https://www.theearthsafari.com/destination/kenya">KENYA SAFARI TOURS</a>
                <a href="https://www.theearthsafari.com/destination/tanzania">TANZANIA SAFARI TOURS</a> 
                <a href="https://www.theearthsafari.com/forests-of-india.php">FORESTS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/india-quick-facts.php">INDIA QUICK FACTS</a> 
                <a href="https://www.theearthsafari.com/tips-for-travel-in-india.php">TIPS FOR TRAVEL IN INDIA</a>
                <a href="https://www.theearthsafari.com/india-visa-info.php">INDIA VISA INFO</a>
		  
		</div><!---end of informationBank-->
		
		<div class="links">
			<h6>About The Earth Safari</h6>
			<a href="https://www.theearthsafari.com/">HOME</a>
			<a href="https://www.theearthsafari.com/about-us">ABOUT US</a>
			<a href="https://www.theearthsafari.com/client-testimonials">CLIENT TESTIMONIALS</a>
			<a href="https://www.theearthsafari.com/contact-us">CONTACT US</a>
			<a href="https://www.theearthsafari.com/terms">TERMS &amp; CONDITIONS</a>
			<a href="https://www.theearthsafari.com/sitemap.xml">XML SiteMap</a>
			<a href="https://www.theearthsafari.com/sitemap.html">HTML Site Map</a>
		</div><!---end of informationBank-->
		
		<div class="links">
			<div class="row">
				<div class="col-xs-9 disclaimer"><span>Disclaimer</span>: THE EARTH SAFARI is not liable for any errors or omissions. All pricing is indicative and subject to exchange rate fluctuations.</div>
				<div class="col-xs-3 media">
					<a href="https://plus.google.com/115282885713632754730" target="_blank" rel="nofollow" title="The Earth Safari Google+ Page"><i class="fa fa-google-plus"></i></a>
					<a href="https://www.facebook.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Facebook Page"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Twitter Page"><i class="fa fa-twitter"></i></a>
					<a href="https://www.theearthsafari.com/blog" target="_blank" title="The Earth Safari Blog"><i class="fa fa-wordpress"></i></a>
				</div>
			</div><!---End of row-->
		</div>
		
		<div class="copyright">Copyright &copy; 2011 - 2022 TheEarthSafari.com</div>
	</div>
</footer>

<div class="enquireBox na">
    <a class="toggle" href="javascript:;">Quick Enquiry <i class="fa fa-angle-double-down"></i></a>
    <h4>Send Your Enquiry now</h4>
    <form class="enquiry">
        <div class="enquiry-message"></div>
        <input type="text" name="name" id="name" class="form-control" placeholder="Name"/>
        <input type="email" name="email" id="email" class="form-control" placeholder="Email"/>
        <input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone"/>
        <textarea name="query" id="query" class="form-control" placeholder="Message"></textarea>
        <button type="button" id="enquiry-submit">
            <span id="text">Submit</span>
            <span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
        </button>
    </form>
</div>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37106525-1']);
  _gaq.push(['_setDomainName', 'theearthsafari.com']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Google Code for Remarketing Tag -->
<!--
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
-->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 972714909;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/972714909/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery("#enquiry-submit").click(function() {
        jQuery("#enquiry-submit #text").hide();
        jQuery("#enquiry-submit #loader").show();
        var from = 1;
        var data = jQuery(".enquiry").serialize();
            jQuery.ajax
            ({
            url: 'ajax/email-query.php?'+data,
            dataType: 'html',
            success: function(msg)
            {
                jQuery(".enquiry-message").show();
                jQuery(".enquiry-message").html(msg);
                jQuery("#enquiry-submit #text").show();
                jQuery("#enquiry-submit #loader").hide();
                if (msg == '<span id="success">Thank you for contact with The Earth Safari.</span>') {
                    jQuery("#name").val("");
                    jQuery("#email").val("");
                    jQuery("#phone").val("");
                    jQuery("#query").val("");
                }
                jQuery(".enquiry-message").delay(3000).hide(1000);
            }
        });
        return false;
    });
    jQuery("#nl-submit").click(function() {
        jQuery("#nl-submit #text").hide();
        jQuery("#nl-submit #loader").show();
        var emails = jQuery('#newsletter').val();
        jQuery.ajax
        ({
            type: 'POST',
            url: 'ajax/newsletter.php',
            data: {email:emails},
            dataType: 'html',
            success: function(msg)
            {
                jQuery("#nl-submit #text").show();
                jQuery("#nl-submit #loader").hide();
                jQuery(".newsletter-popup").show("slow");
                jQuery(".newsletter-popup").html(msg);
                jQuery("#newsletter").val('');
                jQuery(".close").click(function () {
                    jQuery(".newsletter-popup").hide("slow");
                });
            }
        });
    });
});
</script>

<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
  d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
  _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
  $.src='//v2.zopim.com/?1ltJ36Z0ARzUAnTSXmu2o4RKs2ndLWHU';z.t=+new Date;$.
  type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->

<script async src="//www.google.com/recaptcha/api.js"></script>

<script>
function onSubmit(token) {
    $("#enquiryForm").submit();
    return true;
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script type="text/javascript">
$().ready(function() {
  $("#enquiryForm").validate({
    rules: {
      name: "required",
      email: {
        required: true,
        email: true
      },
      phone: {
        required: true,
        minlength: 9
      },
      nationality: "required",
      city: "required",
      adult: "required",
      age_children: {
        required: {
            depends: function() {
              return $("#children").val()
            }
        }
      },
      curr_date: "required",
      month: "required",
      year: "required",
      duration: "required"
    },
    submitHandler: function (form) {
        if (grecaptcha.getResponse()) {
                // 2) finally sending form data
                form.submit();
        }else{
                // 1) Before sending we must validate captcha
            grecaptcha.reset();
            grecaptcha.execute();
        }           
    }
  });
});
</script>
<!--..........Javascript Libraries Start Here..........-->	
<script src="assets/js/slick.js"></script>
<script type="text/javascript" src="assets/js/init.js"></script>

</body>
</html>
