<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta tag properties start here -->
  <meta charset="utf-8">

  <meta name="language" content="english">
	<meta http-equiv="content-language" content="en">

	<meta name="google-site-verification" content="qYC3doxIvybN5KSFiBXT8IohYU9A9Wmer1u2CG7h110" />

	<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
	<meta name="robots" content="NOODP">
	<meta name="robots" content="index, follow" />
	<meta name="DC.title" content="Best African Safari & Indian Tiger Safari" >

  <meta name="keyword" content=""/>
	<meta name="description" content=""/>

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Meta tag properties end here -->
  <title>Private Safari</title>

  <!-- jQuery library file -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
   
  <base href="/" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

	<!--[if lt IE 9]>
		<script src="assets/js/html5shiv.js"> </script>
	<![endif]-->
	<link rel="publisher" href="https://plus.google.com/+Theearthsafaritours"/>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
	<!-- CSS file -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css" />
	<link rel="stylesheet" href="assets/css/slick.css">
	<link rel="stylesheet" type="text/css" media="screen, projection" href="assets/css/main.css" />
	<link rel="stylesheet" href="assets/css/media.css">
</head>

<body class="inner">

<noscript>
<div class="popup-box" style="z-index: 99999999999;"></div>
	<div class="popup-box-container" style="z-index: 99999999999;">
  	<img alt="The Earth Safari" src="assets/img/the-earth-safari-logo.png" style="float:left;" />
    <div class="popup-divider">&nbsp;</div>
    <div class="popup-righ-panel">
    	<span class="popup-heading">Warning!</span>
    	<span class="popup-text">It appears that JavaScript is disabled in your web browser. Please enable it and refresh page to have full system functionality. For instructions on how to enable javascipt in your browser: <a href="http://www.activatejavascript.org/" target="_blank" style="text-decoration: none;" rel="follow" >Click Here</a>.</span>
    </div>
  </div>
</noscript>
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-2 logo"><a href="https://www.theearthsafari.com/"><img src="assets/img/the-earth-safari-logo.png" alt=""/></a></div>
			
			<div class="col-md-10 rightCol">
				<p class="tagline">Inspirational Safaris in India & Africa</p>
				<nav>
					<div class="top">
						<form id="region-selector" name="region_select" action="region.php" method="POST">
							<input type="hidden" name="page" value="http://www.theearthsafari.com/private-safari.php">
															<input type="radio" name="r-selector" value="2" id="africa" onclick="this.form.submit()" style="display: none;">
								<label for="africa">Visit Africa</label>
													</form>

						<a class="menuToggle" href="javascript:;"><i class="fa fa-bars"></i></a>
						<ul>
							<li><a href="https://www.theearthsafari.com/">Home</a></li>
							<li><a href="https://www.theearthsafari.com/about-us">About Us</a></li>
							<li><a href="https://www.theearthsafari.com/client-testimonials">Client testimonials</a></li>
							<li><a href="https://www.theearthsafari.com/contact-us">Contact</a></li>
							<li><a href="https://www.theearthsafari.com/blog">Blog</a></li>
							<li><a href="tel:+91 8447870008">CALL: +91 8447870008</a></li>
						</ul>
					</div><!---End of top-->
					
					<div class="exploreDestination">
						<ul  class="exploreLinkks">
														<li>Explore By : </li>
							<li><a href="javascript:;">Destinations</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/destination/ranthambore-national-park">Ranthambore National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/bandhavgarh-national-park">Bandhavgarh National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kanha-national-park">Kanha National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/pench-national-park">Pench National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/tadoba-andhari-tiger-reserve">Tadoba-Andhari Tiger Reserve</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/jim-corbett-national-park">Jim Corbett National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/gir-forest-national-park">Gir Forest National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kaziranga-national-park">Kaziranga National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/sunderbans-national-park">Sunderbans National Park</a></li>
																	</ul>
							</li>
							<li><a href="javascript:;">Interest</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/interest/tiger-safari-india">Tiger Safari India</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-high-end-luxury-safaris">India High End Luxury Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-short-duration-safaris">India Short Duration Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-culture-and-heritage-tours">India Culture and Heritage Tours</a></li>
																	</ul>
							</li>
							<li><a href="https://www.theearthsafari.com/private-safari.php">Private Safari</a></li>
							<li><a href="https://www.theearthsafari.com/group-safari.php">Group Safari</a></li>
						</ul>
					</div><!--end  of exploreDestination-->
				</nav>
			</div>
		</div><!-- End of row -->
	</div><!-- End of container-->
</header>

<section class="SliderOuter" id="pullUp">
	<div class="container">
		<div id="MainSlider">

							<div>
					<img data-lazy="upload/1353315706_India-safari.jpg" alt="" />
					<div class="caption">Indian Private Safaris</div>
				</div>
					</div><!--End of slider-->
	</div>
</section>

<section class="masterSection destinationSection">
	<div class="container">
		<div class="title">
			<h2> India Private Safari</h2>
			<a class="sendEnquire" href="/private-safari.php#safariType">Find Tour for this Safari type <i class="fa fa-angle-double-down"></i></a>
		</div>	

					<h6 class="text-orange">Explore the wilderness at your own pace and privacy.</h6>

			<p>By choosing The Earth Safari private safaris, you have the luxury of setting your own agenda (with our help) and you won&rsquo;t be shuffled through the rigid itineraries and fixed timetables which group tours are require to adhere to. You may depart on any day of your choice and for any duration of your choosing. All of our safaris are built around your schedule and not ours. We understand that you demand flexibility and our goal is to provide unlimited choices to meet the requirements of your busy life.</p>

			<p>Once on a private safari safari, you have the flexibility to choose and adjust the time you leave and return from your game drives.</p>

			<p>Our Private safaris will be exclusive use of your own vehicle and guide.</p>

			<p>This type of trip has great advantages for those who enjoy independent travel, are serious photographers, or taking children along.</p>
				
		<h2 class="margin-top-50" id="safariType"> India Private Safari Itineraries</h2>
		<div class="divider"></div>
		
		<div class="safariList">
			
							<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/3-days-corbett-tiger-safari"><img src="upload/1444745075_JimCorbett-1-1024x634.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/3-days-corbett-tiger-safari">3 Days Corbett Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 3 Days & 2 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 12,500 Onward</h6>
												<p class="breif">If you are a true nature lover, and wildlife excites you, Jim Corbett National Park safari package is the perfect tour for you. Tour in Jim Corbett National Park, with stunning wildlife locations and huge tiger population, along with vast number of endangered species of flora and fauna, will provide a haven to all the wildlife lovers in India and abroad. The national park also houses approximately 600 different species of birds.</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Jim Corbett National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/3-days-dhikala-safari-package"><img src="upload/1444651272_corbettjeepsafari.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/3-days-dhikala-safari-package">3 Days Dhikala Safari Package</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 3 Days & 2 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 15,000 Onward</h6>
												<p class="breif">Dhikala forest lodge is run and managed by forest department under Corbett national park, it is located in the core area of Corbett national park. The entry gate for Dhikala is Dhangadi gate. You have to show your permits to forest guards here at this point.Dhikala forest lodge is 30 kms from Dhangadi gate, and it will take around 01 Hr to 01 Hr 15 Mins to cover this distance. This journey from Dhangadi gate to Dhikala itself is full of </p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Dhikala Zone (Jim Corbett National Park)</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/5-days-corbett-explorer-safari"><img src="upload/1444655068_Bengal-Tiger_Corbett_Uttarakhand_Dec-2013.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/5-days-corbett-explorer-safari">5 Days Corbett Explorer Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 5 Days & 4 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 26,500 Onward</h6>
												<p class="breif">This Corbett Explorer Safari package of 4 nights and 5 days covers two most preferred zones of Jim Corbett National Park, Dhikala and Bijrani. Dhikala safari zone is heart of corbett and Bijrani zone is the best zone for day visit in the park. So this tour is one of the best safari package to comprehensively explorer this amazing National park.
This tour has great chance of tiger sighting as both zones are famous for tiger sighting for</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Dhikala Range - Bijrani Range (Jim Corbett National Park)</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/inside-the-tiger-s-fortress-"><img src="upload/1354352937_Tiger-india.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/inside-the-tiger-s-fortress-">Inside the Tiger's Fortress </a></h3> 
						<div class="rating">
							<p class="duration">Duration: 9 Days & 8 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 1835 Onward</h6>
												<p class="breif">"Inside the Tiger&rsquo;s Fortress" takes you to the two most famous tiger reserves in India, Ranthambore and Bandhavgarh. Both of them are named after the Historcal Forts located within the tiger reserves. Once a symbol of power and supremacy, these imposing forts are now deserted. But these forts have new occupants, the king of the Jungle &ldquo;Tiger&rdquo;.&nbsp; Read below for more details on this </p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Ranthambore National Park - Bandhavgarh National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/tigers-of-central-india"><img src="upload/1354864320_tigerssmall.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/tigers-of-central-india">Tigers of Central India</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 14 Days & 13 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 3,235 Onward</h6>
												<p class="breif">This 15 Days itinerary includes Tigers safaris of Central India covering all the tiger reserves located in the Madhya Pradesh. It includes Satpura, Pench, Kanha, Bandhavgarh and Panna National Parks. Safari with the Earth Safari.</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Satpura National Park - Pench National Park - Kanha Kanha National Park - Bandhavgarh National Park - Panna National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/the-kipling-s-trail"><img src="upload/1355299170_Tiger safari india4.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/the-kipling-s-trail">The Kipling's Trail</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 11 Days & 10 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 1885 Onward</h6>
												<p class="breif">This itinerary takes you to the amazing Tiger land where the great Author and Explorer Sir Rudyard Kipling wrote the epic, "The Jungle Book". Bandhavgarh National Park boasts of the highest density of tigers in India. Kanha and Pench National Parks were the source of inspiration for Rudyard Kipling&rsquo;s outstanding creation- "The Jungle Book&rdquo;.&nbsp;These jungles / forests are roamed freely by the Tiger, Sloth Bear, Leopard, Gaur, Bark</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Delhi - Bandhavgarh National Park - Kanha National Park - Pench National Park </p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/rhinos--tigers-and-asiatic-lions"><img src="upload/1408610954_R4692.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/rhinos--tigers-and-asiatic-lions">Rhinos, Tigers and Asiatic Lions</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 15 Days & 14 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 3310 Onward</h6>
												<p class="breif">Rhinos, Tigers and Asiatic Lions itinerary integrates the most popular national parks of India. Kaziranga National Park is a national park is in the northeast state of Assam, India. A World Heritage Site, the park hosts two-thirds of the world's Great One-horned Rhinoceroses. Ranthambhore is one of the largest national parks in northern India popular for its tiger population and frequent tiger sighting during the day time. Sasan Gir is the las</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi, Kaziranga National Park, Ranthambhore National Park, Gir Forest National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/rhinos-and-mowgli-s-tigers"><img src="upload/1408695878_tiger.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/rhinos-and-mowgli-s-tigers">Rhinos and Mowgli's Tigers</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 13 Days & 12 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 3035 Onward</h6>
												<p class="breif">Rhinos and Mowgli's Tigers itinerary combines Kaziranga National park with the most popular tiger&rsquo;s reserves of central India Bandhavgarh and Kanha National park. Kaziranga National Park is a national park is in the northeast state of Assam, India. A World Heritage Site, the park hosts two-thirds of the world's Great One-horned Rhinoceroses. Bandhavgarh has one of the highest densities of Bengal tigers known in the world, divided into fo</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Jim Corbett National Park - Bandhavgarh National Park - Kanha National Park - Pench National Park - Tadoba Andheri Tiger Reserve</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/bengal-tigers-and-beaches-of-goa-"><img src="upload/1408713648_Tiger and beach.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/bengal-tigers-and-beaches-of-goa-">Bengal Tigers and Beaches of Goa </a></h3> 
						<div class="rating">
							<p class="duration">Duration: 12 Days & 11 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 2,125 Onward</h6>
												<p class="breif">Along with the excitement of tigers of Central India Bandhavgarh and Kanha we combine the magic of Goa beaches. Bandhavgarh has one of the highest densities of Bengal tigers known in the world. Kanha National Park is the biggest park in Madhya Pradesh, India and has significant population of Royal Bengal Tiger, leopards, the sloth bear, Barasingha and Indian wild dog. The lush sal and bamboo forests, grassy meadows and ravines of Kanha provide</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Bandhavgarh National Park - Kanha National Park - Goa</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/call-of-the-tiger"><img src="upload/1355300491_Tiger-Safari-India20.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/call-of-the-tiger">Call of the Tiger</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 13 Days & 12 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 2,695 Onward</h6>
												<p class="breif">"Call of the Tiger" package takes you through the major tiger reserves in Central India. Tadoba Andheri Tiger Reserve is like a Heaven for Wild life enthusiasts and is also known as the 'Jewel of Vidarbha'. Pench and Kanha National Park were the source of inspiration for Rudyard Kipling, outstanding creation- "The Jungle Book&rdquo; and Bandhavgarh National park- famous for the highest tiger population </p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Tadoba Andheri Tiger Reserve - Pench National Park - Kanha National Park - Bandhavgarh National Park </p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/the-maharajah-s-tiger--high-end-luxury-"><img src="upload/1360327481_tiger-face2.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/the-maharajah-s-tiger--high-end-luxury-">The Maharajah's Tiger (High End Luxury)</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 14 Days & 13 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 5,974 Onward</h6>
												<p class="breif">This High End Luxury Safari is for those who have an intense fascination for the Royal Bengal Tiger and the great Indian empires of old. You will track the Tigers in the most popular Tiger reserves of Ranthambore, Bandhavgarh and Kanha National Parks. All of them famous for spectacular Tiger sightings. Along the tour you will also visit the Golden Triangle which comprises of the most popular cities in India, New Delhi, Agra and Jaipur. All fam</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Agra - Ranthambore National Park - Jaipur - Bandhavgarh National Park - Kanha National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/3-days-ranthambore-tiger-safari-"><img src="upload/1355626864_IMG_2249A.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/3-days-ranthambore-tiger-safari-">3 Days Ranthambore Tiger Safari </a></h3> 
						<div class="rating">
							<p class="duration">Duration: 3 Days & 2 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: On Request Onward</h6>
												<p class="breif">A Short Tiger Safari in Ranthambore National Park,&nbsp;one of the most eminent wild life parks. It is consider as one of the best places in the country to see the Bengal Tiger. It also has deserted castle and lakes. It supports a varied series of flora and fauna which makes it a wonderful destination to visit. Ranthambore is commonly known for its large tiger population and it is the prime example of project tiger&rsquo;s conservation e</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Ranthambore National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/4-days-ranthambore-tiger-safari-"><img src="upload/1355715418_Ranthambore5.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/4-days-ranthambore-tiger-safari-">4 Days Ranthambore Tiger Safari </a></h3> 
						<div class="rating">
							<p class="duration">Duration: 4 Days & 3 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: On Request Onward</h6>
												<p class="breif">A 4 Day Safari in Ranthambore National Park,&nbsp;one of the most eminent wildlife park.&nbsp;Ranthambore&nbsp;National Park is known for its tigers and is one of the best places in India to see these majestic predators in the jungle. Tigers can be easily spotted even during the day time.&nbsp;Well known for the diurnal activity of tigers, Ranthambore is a very special and unusual area where a natural present meets a historical pa</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Ranthambore National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/3-days-bandhavgarh-tiger-safari"><img src="upload/1356087095_Bandhavgarh tiger.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/3-days-bandhavgarh-tiger-safari">3 Days Bandhavgarh Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 3 Days & 2 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 13,500 Onward</h6>
												<p class="breif">A 3 Day Tiger Safari in Bandhavgarh National Park famous for highest known density of tiger population in India. Bandhavgarh National Park as an unspoilt national habitat for a variety of wildlife peculiar to the area. These includes gaur (Indian bison), sloth bear, leopard, porcupine, wild boar, sambhar and spotted deer, among others and of course, the Tiger.&nbsp;The Bandhavgarh national park is a jungle consisting mainly of sal trees. It is</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Bandhavgarh National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/4-days-bandhavgarh-tiger-safari"><img src="upload/1356090775_Bandhavgarh8.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/4-days-bandhavgarh-tiger-safari">4 Days Bandhavgarh Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 4 Days & 3 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 21,500 Onward</h6>
												<p class="breif">A 4 Day Tiger Safari in Bandhavgarh National Park.&nbsp;Bandhavgarh is known across the world for its dense big cat population. But there's much more to see besides the tigers and leopards. Chital (spotted deer), Sambar deer, dhole, nilgai, wild boar, chinkara, sloth bear, rhesus macaque, black faced langur, jungle cat, hyena, porcupine, jackal, fox and wild dog also inhabit these forests.&nbsp;Nestled in the Vindhya range, the breathtakingly </p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Bandhavgarh National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/3-days-kanha-tiger-safari"><img src="upload/1357203729_Kanha-tiger1.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/3-days-kanha-tiger-safari">3 Days Kanha Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 3 Days & 2 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 15,900 Onward</h6>
												<p class="breif">A 3 days short Tiger safari in Kanha National Park in the Mandla and Balaghat districts of Madhya Pradesh. The park has a significant population of Royal Bengal Tiger, leopards, the sloth bear, Barasingha and Indian wild dog. The lush sal and bamboo forests, grassy meadows and ravines of Kanha provided inspiration to Rudyard Kipling for his famous novel "Jungle Book.&nbsp;</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Kanha National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/4-days-kanha-tiger-safari"><img src="upload/1357208069_Pench National Park2.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/4-days-kanha-tiger-safari">4 Days Kanha Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 4 Days & 3 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 25,000 Onward</h6>
												<p class="breif">A 4 Days Safari in Kanha National Park, one of the most beautiful and well managed of all national parks in India. It is well known not only within the tourists, natural history photographers and wildlife lovers but also to public at large. Tourist throng here to see the magnificent big cat Tiger and one of the rarest deer the Hard ground Barasingha (Swamp Deer) also known as the &ndash; Jewel of Kanha national park. Today Kanha is among the f</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Kanha National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/3-days-pench-tiger-safari"><img src="upload/1357213147_Pench-tiger.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/3-days-pench-tiger-safari">3 Days Pench Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 3 Days & 2 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 15,900 Onward</h6>
												<p class="breif">A 3 Days Tiger Safari in Pench National Park which conjures up images of Mowgli, Bagheera and the "bear necessities". Immortalised by Rudyard Kipling in The Jungle Book, it is still sometimes unfairly given the step-sibling treatment next to Bandhavgarh. When, in fact, the Pench river meandering through its entire stretch, along with the open hilly terrain, teak forests and jungle streams form a heart-stoppingly beautiful landscape. A landscap</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Pench National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/4-days-pench-tiger-safari-"><img src="upload/1357218494_Pench tiger.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/4-days-pench-tiger-safari-">4 Days Pench Tiger Safari </a></h3> 
						<div class="rating">
							<p class="duration">Duration: 4 Days & 3 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 25,300 Onward</h6>
												<p class="breif">A 4 Days Safari in Pench National Park&nbsp;also known as Indira Gandhi National Park is known for large population of chital and sambhar and has the highest density of herbivores in India. This is famous for large heards of gaur, nilgai and wild dog. The tiger, leopard, barking deer and chinkara found in large numbers along with over 285 species of resident and migratory birds.&nbsp;The area of the present tiger reserve has a glo</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Pench National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/3-days-tadoba-tiger-safari"><img src="upload/1409745158_Tiger Tadoba.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/3-days-tadoba-tiger-safari">3 Days Tadoba Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 3 Days & 2 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 23,900 Onward</h6>
												<p class="breif">A 3 Days Tiger Safari in Tadoba-Andhari Tiger Reserve located in the Chandrapur District of Maharashtra, India, it is one of the prominent and unique tiger reserves in India and is also one among India's Project Tiger Reserves. It was established in 1935 and declared a national park in 1955. It has an attractive bio-diversity and is also famous for its rich heritage.The name 'Tadoba' is the name of the God "Tadoba" or "Taru", praised by the tr</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Tadoba-Andhari Tiger Reserve</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/4-days-tadoba-tiger-safari"><img src="upload/1409746948_Tadoba1.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/4-days-tadoba-tiger-safari">4 Days Tadoba Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 4 Days & 3 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 38,600 Onward</h6>
												<p class="breif">A 4 Days Tiger Safari in Tadoba-Andhari Tiger Reserve located in the Chandrapur District of Maharashtra, India, it is one of the prominent and unique tiger reserves in India and is also one among India's Project Tiger Reserves. It was established in 1935 and declared a national park in 1955. It has an attractive bio-diversity and is also famous for its rich heritage.The name 'Tadoba' is the name of the God "Tadoba" or "Taru", praised by the tr</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Tadoba-Andhari Tiger Reserve</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/3-days-gir-forest-lion-safari"><img src="upload/1410520794_Gir_National_Park.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/3-days-gir-forest-lion-safari">3 Days Gir Forest Lion Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 3 Days & 2 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 18,500 Onward</h6>
												<p class="breif">A 3 Days Lion Safari in Gir Forest National Park which is the sole home of the pure Asiatic Lions (Panthera leo persica) and is considered to be one of the most important protected areas in Asia due to its supported species. The forest area of Gir and its lions were declared as "protected" in the early 1900s by the then Nawab of the princely state of Junagadh. This initiative assisted in the conservation of the lions whose population had plumm</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Gir Forest National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/4-days-gir-forest-lion-safari"><img src="upload/1410521905_Gir Forest National Park.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/4-days-gir-forest-lion-safari">4 Days Gir Forest Lion Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 4 Days & 3 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: INR 23,550 Onward</h6>
												<p class="breif">A 4 Days Lion Safari in Gir Forest National Park which is the sole home of the pure Asiatic Lions (Panthera leo persica) and is considered to be one of the most important protected areas in Asia due to its supported species. The forest area of Gir and its lions were declared as "protected" in the early 1900s by the then Nawab of the princely state of Junagadh. This initiative assisted in the conservation of the lions whose population had plumm</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Gir Forest National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/king-of-the-jungle--high-end-luxury-"><img src="upload/1360672150_Tiger portrait.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/king-of-the-jungle--high-end-luxury-">King of the Jungle (High End Luxury)</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 14 Days & 13 Nights</p>
													</div><!---End of rating-->
												<p class="breif">This High End Luxury Safari takes you to the Madhya Pradesh in Central India, state with most number of Tiger reserves and also the undisputed Tiger Country since ages. This Safari offers stay at the luxurious Taj Safari lodges at all National Parks. &nbsp;These lodges offer luxurious views of the surrounding forest cover and feature modernistic and lavish interiors to offer you a cocoon of safety and comfort. Strategically positioned on high </p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Agra - Panna National Park - Bandhavgarh National Park - Kanha National Park - Pench National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/8-days-golden-triangle-with-tiger-safari"><img src="upload/1378119457_tajMahal_2360129b.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/8-days-golden-triangle-with-tiger-safari">8 Days Golden Triangle with Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 8 Days & 7 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 1,200 Onward</h6>
												<p class="breif">Discover the rich heritage and culture of India and have a date with the royal Bengal tiger in this 8 days itinerary. Here on this tour you will visit Delhi &amp; New Delhi- consists of seven ancient cities. Agra- the Taj city, Ranthambore National park &ndash; world famous for tiger sightings located at 480 Km from Delhi and lastly you will visit Jaipur &ndash;&nbsp; worlds first planned city on our Shilpshartra by a Hindu scholar Vidyadhar B</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Agra - Ranthambore National Park - Jaipur </p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/11-days-taj--palaces-and-temples-with-tiger-safari"><img src="upload/1378127850_Hawa-Mahal-Jaipur.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/11-days-taj--palaces-and-temples-with-tiger-safari">11 Days Taj, Palaces and Temples with Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 11 Days & 10 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 2,095 Onward</h6>
												<p class="breif">Explore the rich heritage and culture of India. You will visit Delhi &amp; New Delhi- consists of seven ancient cities, Jaipur &ndash; worlds first planned city on our Shilpshartra by a Hindu scholar Vidyadhar Bhattacharya. Agra (the Taj city) Taj is the world&rsquo;s most beautiful monument. Khajuraho is world famous for the exotic temples. Lastly you will visit the Bandhavgarh national park- which has the highest density of tigers. &ldquo;It</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Jaipur - Agra - Khajuraho - Bandhavgarh National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/16-days-glorious-rajasthan--ganges---taj-with-tiger-safari"><img src="upload/1378303130_udaipur_city_palace2.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/16-days-glorious-rajasthan--ganges---taj-with-tiger-safari">16 Days Glorious Rajasthan, Ganges & Taj With Tiger Safari</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 16 Days & 15 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star"></i>						</div><!---End of rating-->
													<h6>Starting from: USD 2,865 Onward</h6>
												<p class="breif">We&rsquo;ve integrated everything you desire to see in India in this itinerary. &nbsp;It covers the history, culture and includes the magic of Rajasthan. Your tour starts from Delhi, which existed since the days of Mahabharta, now a cosmopolitan city (mini India). Varanasi is the oldest living city and the spiritual capital of India. Khajuraho temples represent the expression of a highly matured civilization. Orchha was founded in the 16th cen</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> New Delhi - Varanasi - Khajuraho - Agra - Ranthambore National Park - Jaipur - Deogarh - Udaipur</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  				<div class="row loopRow">
					<div class="col-xs-3">
						<a href="/itinerary-detail/3-days-ranthambore-high-end-luxury-safari-at-oberoi-vanyavilas"><img src="upload/1382014461_Oberoi Vanyavilas.jpg" alt=""/></a>
					</div><!--end of col-xs-4-->
					<div class="col-xs-9">
						<h3 class="packagedays"><a href="/itinerary-detail/3-days-ranthambore-high-end-luxury-safari-at-oberoi-vanyavilas">3 Days Ranthambore High End Luxury Safari at Oberoi Vanyavilas</a></h3> 
						<div class="rating">
							<p class="duration">Duration: 3 Days & 2 Nights</p>
							<i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i><i class="fa fa-star active"></i>						</div><!---End of rating-->
												<p class="breif">A 3 Days High end Luxury Safari Nestling in the natural beauty of the wilds, The Oberoi Vanyavilas is India&rsquo;s leading luxury jungle resort on the edge of the Ranthambhore Tiger Reserve.The perfect base from which to explore the territory of the majestic tiger. While it is warm during the day, mornings and evenings are pleasant.The resort setting is picture-perfect with a dramatic watercourse and sun-kissed private</p>
						<p class="destinationCovered"><strong>Destinations Covered:</strong> Ranthambore National Park</p>
					</div><!--end of col-xs-4-->
				</div><!--End of loopRow-->
				<div class="divider-dark"></div>
		  			
		</div><!--En dof row-->
		
	</div><!--End of cnntainer-->
</section>

<footer>
	<div class="container">
		<p class="membership"><a href="https://www.theearthsafari.com/wildlife-associations.php" title="African Travel & Tourism Association"><img src="assets/img/memberships.jpg" alt="African Travel & Tourism Association" /></a></p>
		
		<div class="links">
			<h6>Information Bank</h6>

							<a href="https://www.theearthsafari.com/responsible-ecotourism.php">RESPONSIBLE ECOTOURISM</a> 
                <a href="https://www.theearthsafari.com/safari-code-of-conduct.php">SAFARI CODE OF CONDUCT</a>
                <a href="https://www.theearthsafari.com/destination/ranthambore-national-park">RANTHAMBORE NATIONAL PARK</a>
                <a href="https://www.theearthsafari.com/interest/tiger-safari-india">TIGER SAFARI INDIA</a>
                <a href="https://www.theearthsafari.com/wildlife-photography-tips.php">WILDLIFE PHOTOGRAPHY TIPS</a> 
                <a href="https://www.theearthsafari.com/checklist-of-birds-of-india.php">CHECKLIST OF BIRDS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/popular-animal-species-of-india.php">POPULAR ANIMAL SPECIES OF INDIA</a> 
                <a href="https://www.theearthsafari.com/safari-packing-check-list.php">SAFARI PACKING CHECK LIST</a>
                <a href="https://www.theearthsafari.com/indian-wildlife-map-table.php">INDIAN WILDLIFE MAP TABLE</a>
                <a href="https://www.theearthsafari.com/list-of-tiger-reserves-in-india.php">LIST OF TIGER RESERVES IN INDIA</a> 
                <a href="https://www.theearthsafari.com/india-wildlife-experience.php">INDIAN WILDLIFE EXPERIENCE</a>
                <a href="https://www.theearthsafari.com/destination/kenya">KENYA SAFARI TOURS</a>
                <a href="https://www.theearthsafari.com/destination/tanzania">TANZANIA SAFARI TOURS</a> 
                <a href="https://www.theearthsafari.com/forests-of-india.php">FORESTS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/india-quick-facts.php">INDIA QUICK FACTS</a> 
                <a href="https://www.theearthsafari.com/tips-for-travel-in-india.php">TIPS FOR TRAVEL IN INDIA</a>
                <a href="https://www.theearthsafari.com/india-visa-info.php">INDIA VISA INFO</a>
		  
		</div><!---end of informationBank-->
		
		<div class="links">
			<h6>About The Earth Safari</h6>
			<a href="https://www.theearthsafari.com/">HOME</a>
			<a href="https://www.theearthsafari.com/about-us">ABOUT US</a>
			<a href="https://www.theearthsafari.com/client-testimonials">CLIENT TESTIMONIALS</a>
			<a href="https://www.theearthsafari.com/contact-us">CONTACT US</a>
			<a href="https://www.theearthsafari.com/terms">TERMS &amp; CONDITIONS</a>
			<a href="https://www.theearthsafari.com/sitemap.xml">XML SiteMap</a>
			<a href="https://www.theearthsafari.com/sitemap.html">HTML Site Map</a>
		</div><!---end of informationBank-->
		
		<div class="links">
			<div class="row">
				<div class="col-xs-9 disclaimer"><span>Disclaimer</span>: THE EARTH SAFARI is not liable for any errors or omissions. All pricing is indicative and subject to exchange rate fluctuations.</div>
				<div class="col-xs-3 media">
					<a href="https://plus.google.com/115282885713632754730" target="_blank" rel="nofollow" title="The Earth Safari Google+ Page"><i class="fa fa-google-plus"></i></a>
					<a href="https://www.facebook.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Facebook Page"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Twitter Page"><i class="fa fa-twitter"></i></a>
					<a href="https://www.theearthsafari.com/blog" target="_blank" title="The Earth Safari Blog"><i class="fa fa-wordpress"></i></a>
				</div>
			</div><!---End of row-->
		</div>
		
		<div class="copyright">Copyright &copy; 2011 - 2022 TheEarthSafari.com</div>
	</div>
</footer>

<div class="enquireBox na">
    <a class="toggle" href="javascript:;">Quick Enquiry <i class="fa fa-angle-double-down"></i></a>
    <h4>Send Your Enquiry now</h4>
    <form class="enquiry">
        <div class="enquiry-message"></div>
        <input type="text" name="name" id="name" class="form-control" placeholder="Name"/>
        <input type="email" name="email" id="email" class="form-control" placeholder="Email"/>
        <input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone"/>
        <textarea name="query" id="query" class="form-control" placeholder="Message"></textarea>
        <button type="button" id="enquiry-submit">
            <span id="text">Submit</span>
            <span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
        </button>
    </form>
</div>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37106525-1']);
  _gaq.push(['_setDomainName', 'theearthsafari.com']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Google Code for Remarketing Tag -->
<!--
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
-->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 972714909;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/972714909/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery("#enquiry-submit").click(function() {
        jQuery("#enquiry-submit #text").hide();
        jQuery("#enquiry-submit #loader").show();
        var from = 1;
        var data = jQuery(".enquiry").serialize();
            jQuery.ajax
            ({
            url: 'ajax/email-query.php?'+data,
            dataType: 'html',
            success: function(msg)
            {
                jQuery(".enquiry-message").show();
                jQuery(".enquiry-message").html(msg);
                jQuery("#enquiry-submit #text").show();
                jQuery("#enquiry-submit #loader").hide();
                if (msg == '<span id="success">Thank you for contact with The Earth Safari.</span>') {
                    jQuery("#name").val("");
                    jQuery("#email").val("");
                    jQuery("#phone").val("");
                    jQuery("#query").val("");
                }
                jQuery(".enquiry-message").delay(3000).hide(1000);
            }
        });
        return false;
    });
    jQuery("#nl-submit").click(function() {
        jQuery("#nl-submit #text").hide();
        jQuery("#nl-submit #loader").show();
        var emails = jQuery('#newsletter').val();
        jQuery.ajax
        ({
            type: 'POST',
            url: 'ajax/newsletter.php',
            data: {email:emails},
            dataType: 'html',
            success: function(msg)
            {
                jQuery("#nl-submit #text").show();
                jQuery("#nl-submit #loader").hide();
                jQuery(".newsletter-popup").show("slow");
                jQuery(".newsletter-popup").html(msg);
                jQuery("#newsletter").val('');
                jQuery(".close").click(function () {
                    jQuery(".newsletter-popup").hide("slow");
                });
            }
        });
    });
});
</script>

<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
  d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
  _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
  $.src='//v2.zopim.com/?1ltJ36Z0ARzUAnTSXmu2o4RKs2ndLWHU';z.t=+new Date;$.
  type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->

<script async src="//www.google.com/recaptcha/api.js"></script>

<script>
function onSubmit(token) {
    $("#enquiryForm").submit();
    return true;
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script type="text/javascript">
$().ready(function() {
  $("#enquiryForm").validate({
    rules: {
      name: "required",
      email: {
        required: true,
        email: true
      },
      phone: {
        required: true,
        minlength: 9
      },
      nationality: "required",
      city: "required",
      adult: "required",
      age_children: {
        required: {
            depends: function() {
              return $("#children").val()
            }
        }
      },
      curr_date: "required",
      month: "required",
      year: "required",
      duration: "required"
    },
    submitHandler: function (form) {
        if (grecaptcha.getResponse()) {
                // 2) finally sending form data
                form.submit();
        }else{
                // 1) Before sending we must validate captcha
            grecaptcha.reset();
            grecaptcha.execute();
        }           
    }
  });
});
</script>
<!--..........Javascript Libraries Start Here..........-->	
<script src="assets/js/slick.js"></script>
<script type="text/javascript" src="assets/js/init.js"></script>

</body>
</html>
