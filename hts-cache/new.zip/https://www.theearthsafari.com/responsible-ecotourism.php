<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta tag properties start here -->
  <meta charset="utf-8">

  <meta name="language" content="english">
	<meta http-equiv="content-language" content="en">

	<meta name="google-site-verification" content="qYC3doxIvybN5KSFiBXT8IohYU9A9Wmer1u2CG7h110" />

	<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
	<meta name="robots" content="NOODP">
	<meta name="robots" content="index, follow" />
	<meta name="DC.title" content="Best African Safari & Indian Tiger Safari" >

  <meta name="description" content="We strongly recommend all viewers to consider the various guidelines associated to Ecotourism and guidelines related to various national parks of the world. It is more of a responsibility of the visitors than the governments and the authorities of the various national parks to safeguard the interest of all animals and the natural things of the parks." />
	<meta name="keywords" content="safari responsibility,ecotourism,eco tourism,national parks,guidelines,theearthsafari.com" />

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Meta tag properties end here -->
  <title>Responsible Eco tourism- The Earth Safari</title>

  <!-- jQuery library file -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
   
  <base href="" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

	<!--[if lt IE 9]>
		<script src="assets/js/html5shiv.js"> </script>
	<![endif]-->
	<link rel="publisher" href="https://plus.google.com/+Theearthsafaritours"/>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
	<!-- CSS file -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css" />
	<link rel="stylesheet" href="assets/css/slick.css">
	<link rel="stylesheet" type="text/css" media="screen, projection" href="assets/css/main.css" />
	<link rel="stylesheet" href="assets/css/media.css">
</head>

<body class="inner">

<noscript>
<div class="popup-box" style="z-index: 99999999999;"></div>
	<div class="popup-box-container" style="z-index: 99999999999;">
  	<img alt="The Earth Safari" src="assets/img/the-earth-safari-logo.png" style="float:left;" />
    <div class="popup-divider">&nbsp;</div>
    <div class="popup-righ-panel">
    	<span class="popup-heading">Warning!</span>
    	<span class="popup-text">It appears that JavaScript is disabled in your web browser. Please enable it and refresh page to have full system functionality. For instructions on how to enable javascipt in your browser: <a href="http://www.activatejavascript.org/" target="_blank" style="text-decoration: none;" rel="follow" >Click Here</a>.</span>
    </div>
  </div>
</noscript>
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-2 logo"><a href="https://www.theearthsafari.com/"><img src="assets/img/the-earth-safari-logo.png" alt=""/></a></div>
			
			<div class="col-md-10 rightCol">
				<p class="tagline">Inspirational Safaris in India & Africa</p>
				<nav>
					<div class="top">
						<form id="region-selector" name="region_select" action="region.php" method="POST">
							<input type="hidden" name="page" value="http://www.theearthsafari.com/responsible-ecotourism.php">
															<input type="radio" name="r-selector" value="2" id="africa" onclick="this.form.submit()" style="display: none;">
								<label for="africa">Visit Africa</label>
													</form>

						<a class="menuToggle" href="javascript:;"><i class="fa fa-bars"></i></a>
						<ul>
							<li><a href="https://www.theearthsafari.com/">Home</a></li>
							<li><a href="https://www.theearthsafari.com/about-us">About Us</a></li>
							<li><a href="https://www.theearthsafari.com/client-testimonials">Client testimonials</a></li>
							<li><a href="https://www.theearthsafari.com/contact-us">Contact</a></li>
							<li><a href="https://www.theearthsafari.com/blog">Blog</a></li>
							<li><a href="tel:+91 8447870008">CALL: +91 8447870008</a></li>
						</ul>
					</div><!---End of top-->
					
					<div class="exploreDestination">
						<ul  class="exploreLinkks">
														<li>Explore By : </li>
							<li><a href="javascript:;">Destinations</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/destination/ranthambore-national-park">Ranthambore National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/bandhavgarh-national-park">Bandhavgarh National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kanha-national-park">Kanha National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/pench-national-park">Pench National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/tadoba-andhari-tiger-reserve">Tadoba-Andhari Tiger Reserve</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/jim-corbett-national-park">Jim Corbett National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/gir-forest-national-park">Gir Forest National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kaziranga-national-park">Kaziranga National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/sunderbans-national-park">Sunderbans National Park</a></li>
																	</ul>
							</li>
							<li><a href="javascript:;">Interest</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/interest/tiger-safari-india">Tiger Safari India</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-high-end-luxury-safaris">India High End Luxury Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-short-duration-safaris">India Short Duration Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-culture-and-heritage-tours">India Culture and Heritage Tours</a></li>
																	</ul>
							</li>
							<li><a href="https://www.theearthsafari.com/private-safari.php">Private Safari</a></li>
							<li><a href="https://www.theearthsafari.com/group-safari.php">Group Safari</a></li>
						</ul>
					</div><!--end  of exploreDestination-->
				</nav>
			</div>
		</div><!-- End of row -->
	</div><!-- End of container-->
</header>

<section class="masterSection staticPage">
	<div class="container">
		<div class="grayBg margin-top-50">
			<div class="row safariList">
				<div class="col-md-9">
					<div class="title"><h2>Responsible Eco tourism</h2></div>
					
					<p class="profilePic"><img src="assets/img/resp-eco.jpg" alt=""/></p>
					<p>Eco tourism (also known as ecological tourism) is travel to fragile, pristine and usually protected areas that strive to be of low impact and (often) small scale. It helps educate the traveler; provides funds for conservation; directly benefits the economic development and political empowerment of local communities and fosters respect for different cultures and for human rights.</p>
					<p>Eco tourism is not only a good sounding word but also carries a deeper meaning. When it comes to wildlife, beauty and nature comes to the mind at once. It becomes the moral responsibility of all nature lovers esp. those visiting the ecological jungle to promote security, growth and beauty of the region.</p>
					<p>It is also concerned with promoting the economies of the nearby regions of the national parks and sanctuaries. All the nearby populations who survive on the economy from the natural habitats are to be paid special care and attention by the government authorities and also by the tourists coming from diverse global locations.</p>
					<p>Eco-tourism focuses on local cultures, wilderness adventures, volunteering, personal growth and learning new ways to live on our vulnerable planet. It is typically defined as travel to destinations where the flora, fauna and cultural heritage are the primary attractions. Responsible Eco-tourism includes programs that minimize the adverse effects of traditional tourism on the natural environment, and enhance the cultural integrity of local people. Therefore, in addition to evaluating environmental and cultural factors, initiatives by hospitality providers to promote recycling, energy efficiency, water re-use, and the creation of economic opportunities for local communities are an integral part of Eco-tourism. </p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">How can we promote Eco tourism by Minimizing impact</h5>
					<ul class="bulletPoints">
						<li>Build environmental and cultural awareness and respect</li>
						<li>Provide positive experiences for both visitors and hosts</li>
						<li>Provide direct financial benefits for conservation</li>
						<li>Provide financial benefits and empowerment for local people</li>
						<li>Raise sensitivity to host countries' political, environmental and social climate Support</li>
						<li>international human rights and labour agreements</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">The Basic DO’s and DONT’s for Eco Tourism:</h5>
					<h6>DO'S</h6>
					<ul class="bulletPoints">
						<li>Carry back all non-degradable litter such as empty bottles, tins, plastic bags etc. These must not litter the environment or be buried. They must be disposed in municipal dustbins only.</li>
						<li>Observe the sanctity of holy sites, temples and local cultures.</li>
						<li>Cut noise pollution. Do not blare aloud radios, tape recorders or other electronic entertainment equipment in nature resorts, sanctuaries and wildlife parks.</li>
						<li>In case temporary toilets are set-up near campsites, after defecation, cover with mud or sand. Make sure that the spot is at least 30 meters away from the water source.</li>
						<li>Respect people's privacy while taking photographs. Ask for prior permission before taking a photograph.</li>
					</ul>
					<p>&nbsp;</p>
					
					<h6>DON'TS</h6>
					<ul class="bulletPoints">
						<li>Do not take away flora and fauna in the forms of cuttings, seeds or roots. It is illegal, especially in the Himalayas. The environment is really delicate in this region and the bio-diversity of the region has to be protected at all costs.</li>
						<li>Do not use pollutants such as detergent, in streams or springs while washing and bathing.</li>
						<li>Do not use wood as fuel to cook food at the campsite.</li>
						<li>Do not leave cigarette butts or make open fires in the forests.</li>
						<li>Do not consume aerated drinks, alcohol, drugs or any other intoxicants and throw bottles in the wild.</li>
						<li>Do not tempt the locals, especially children by offering them foodstuff or sweets. Respect local traditions.</li>
						<li>Polythene and plastics are non biodegradable and unhealthy for the environment and must not be used and littered.</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Golden Rules When You Travel</h5>
					<ul class="bulletPoints">
						<li>Learn about your destination before you get there. Read guidebooks, travel articles, histories and/or novels by local authors and pay particular attention to customs such as greetings, appropriate dress, eating behaviors, etc. Being sensitive to these customs will increase local acceptance of you as a tourist and enrich your trip.</li>
						<li>Follow established guidelines. Ask your eco-tour operator, guide and/or the local authorities what their guidelines are for limiting tourism's impact on the environment and local culture. Staying on trails, packing up your trash, and remaining set distances away from wildlife are a few ways to minimizing your impact in sensitive areas.</li>
						<li>Seek out and support locally owned businesses. Support local businesses during your eco-travels to ensure maximum community and conservation benefit from your spending.</li>
					</ul>
					
					
				</div><!---End of col-sm-8-->
				
				<div class="col-md-3">
	<form class="newsLetter" type="post">
		<input type="email" name="newsletter" id="newsletter" placeholder="Enter your email address" />
		<button type="button" name="button" id="nl-submit">
			<span id="text"><i class="fa fa-check-square-o"></i></span>
			<span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
		</button>
	</form>
	
	<p class="saranVaid"><a href="http://www.saranvaid.com" target="_blank" rel="nofollow"><img src="assets/img/saran-vaid-img.jpg" alt=""></a></p>
</div><!---End of col-sm-3-->				
			</div><!---End of row-->
		<!--end of grayBg-->
	</div>
</section>



<footer>
	<div class="container">
		<p class="membership"><a href="https://www.theearthsafari.com/wildlife-associations.php" title="African Travel & Tourism Association"><img src="assets/img/memberships.jpg" alt="African Travel & Tourism Association" /></a></p>
		
		<div class="links">
			<h6>Information Bank</h6>

							<a href="https://www.theearthsafari.com/responsible-ecotourism.php">RESPONSIBLE ECOTOURISM</a> 
                <a href="https://www.theearthsafari.com/safari-code-of-conduct.php">SAFARI CODE OF CONDUCT</a>
                <a href="https://www.theearthsafari.com/destination/ranthambore-national-park">RANTHAMBORE NATIONAL PARK</a>
                <a href="https://www.theearthsafari.com/interest/tiger-safari-india">TIGER SAFARI INDIA</a>
                <a href="https://www.theearthsafari.com/wildlife-photography-tips.php">WILDLIFE PHOTOGRAPHY TIPS</a> 
                <a href="https://www.theearthsafari.com/checklist-of-birds-of-india.php">CHECKLIST OF BIRDS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/popular-animal-species-of-india.php">POPULAR ANIMAL SPECIES OF INDIA</a> 
                <a href="https://www.theearthsafari.com/safari-packing-check-list.php">SAFARI PACKING CHECK LIST</a>
                <a href="https://www.theearthsafari.com/indian-wildlife-map-table.php">INDIAN WILDLIFE MAP TABLE</a>
                <a href="https://www.theearthsafari.com/list-of-tiger-reserves-in-india.php">LIST OF TIGER RESERVES IN INDIA</a> 
                <a href="https://www.theearthsafari.com/india-wildlife-experience.php">INDIAN WILDLIFE EXPERIENCE</a>
                <a href="https://www.theearthsafari.com/destination/kenya">KENYA SAFARI TOURS</a>
                <a href="https://www.theearthsafari.com/destination/tanzania">TANZANIA SAFARI TOURS</a> 
                <a href="https://www.theearthsafari.com/forests-of-india.php">FORESTS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/india-quick-facts.php">INDIA QUICK FACTS</a> 
                <a href="https://www.theearthsafari.com/tips-for-travel-in-india.php">TIPS FOR TRAVEL IN INDIA</a>
                <a href="https://www.theearthsafari.com/india-visa-info.php">INDIA VISA INFO</a>
		  
		</div><!---end of informationBank-->
		
		<div class="links">
			<h6>About The Earth Safari</h6>
			<a href="https://www.theearthsafari.com/">HOME</a>
			<a href="https://www.theearthsafari.com/about-us">ABOUT US</a>
			<a href="https://www.theearthsafari.com/client-testimonials">CLIENT TESTIMONIALS</a>
			<a href="https://www.theearthsafari.com/contact-us">CONTACT US</a>
			<a href="https://www.theearthsafari.com/terms">TERMS &amp; CONDITIONS</a>
			<a href="https://www.theearthsafari.com/sitemap.xml">XML SiteMap</a>
			<a href="https://www.theearthsafari.com/sitemap.html">HTML Site Map</a>
		</div><!---end of informationBank-->
		
		<div class="links">
			<div class="row">
				<div class="col-xs-9 disclaimer"><span>Disclaimer</span>: THE EARTH SAFARI is not liable for any errors or omissions. All pricing is indicative and subject to exchange rate fluctuations.</div>
				<div class="col-xs-3 media">
					<a href="https://plus.google.com/115282885713632754730" target="_blank" rel="nofollow" title="The Earth Safari Google+ Page"><i class="fa fa-google-plus"></i></a>
					<a href="https://www.facebook.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Facebook Page"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Twitter Page"><i class="fa fa-twitter"></i></a>
					<a href="https://www.theearthsafari.com/blog" target="_blank" title="The Earth Safari Blog"><i class="fa fa-wordpress"></i></a>
				</div>
			</div><!---End of row-->
		</div>
		
		<div class="copyright">Copyright &copy; 2011 - 2022 TheEarthSafari.com</div>
	</div>
</footer>

<div class="enquireBox na">
    <a class="toggle" href="javascript:;">Quick Enquiry <i class="fa fa-angle-double-down"></i></a>
    <h4>Send Your Enquiry now</h4>
    <form class="enquiry">
        <div class="enquiry-message"></div>
        <input type="text" name="name" id="name" class="form-control" placeholder="Name"/>
        <input type="email" name="email" id="email" class="form-control" placeholder="Email"/>
        <input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone"/>
        <textarea name="query" id="query" class="form-control" placeholder="Message"></textarea>
        <button type="button" id="enquiry-submit">
            <span id="text">Submit</span>
            <span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
        </button>
    </form>
</div>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37106525-1']);
  _gaq.push(['_setDomainName', 'theearthsafari.com']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Google Code for Remarketing Tag -->
<!--
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
-->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 972714909;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/972714909/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery("#enquiry-submit").click(function() {
        jQuery("#enquiry-submit #text").hide();
        jQuery("#enquiry-submit #loader").show();
        var from = 1;
        var data = jQuery(".enquiry").serialize();
            jQuery.ajax
            ({
            url: 'ajax/email-query.php?'+data,
            dataType: 'html',
            success: function(msg)
            {
                jQuery(".enquiry-message").show();
                jQuery(".enquiry-message").html(msg);
                jQuery("#enquiry-submit #text").show();
                jQuery("#enquiry-submit #loader").hide();
                if (msg == '<span id="success">Thank you for contact with The Earth Safari.</span>') {
                    jQuery("#name").val("");
                    jQuery("#email").val("");
                    jQuery("#phone").val("");
                    jQuery("#query").val("");
                }
                jQuery(".enquiry-message").delay(3000).hide(1000);
            }
        });
        return false;
    });
    jQuery("#nl-submit").click(function() {
        jQuery("#nl-submit #text").hide();
        jQuery("#nl-submit #loader").show();
        var emails = jQuery('#newsletter').val();
        jQuery.ajax
        ({
            type: 'POST',
            url: 'ajax/newsletter.php',
            data: {email:emails},
            dataType: 'html',
            success: function(msg)
            {
                jQuery("#nl-submit #text").show();
                jQuery("#nl-submit #loader").hide();
                jQuery(".newsletter-popup").show("slow");
                jQuery(".newsletter-popup").html(msg);
                jQuery("#newsletter").val('');
                jQuery(".close").click(function () {
                    jQuery(".newsletter-popup").hide("slow");
                });
            }
        });
    });
});
</script>

<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
  d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
  _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
  $.src='//v2.zopim.com/?1ltJ36Z0ARzUAnTSXmu2o4RKs2ndLWHU';z.t=+new Date;$.
  type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->

<script async src="//www.google.com/recaptcha/api.js"></script>

<script>
function onSubmit(token) {
    $("#enquiryForm").submit();
    return true;
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script type="text/javascript">
$().ready(function() {
  $("#enquiryForm").validate({
    rules: {
      name: "required",
      email: {
        required: true,
        email: true
      },
      phone: {
        required: true,
        minlength: 9
      },
      nationality: "required",
      city: "required",
      adult: "required",
      age_children: {
        required: {
            depends: function() {
              return $("#children").val()
            }
        }
      },
      curr_date: "required",
      month: "required",
      year: "required",
      duration: "required"
    },
    submitHandler: function (form) {
        if (grecaptcha.getResponse()) {
                // 2) finally sending form data
                form.submit();
        }else{
                // 1) Before sending we must validate captcha
            grecaptcha.reset();
            grecaptcha.execute();
        }           
    }
  });
});
</script>
<!--..........Javascript Libraries Start Here..........-->	
<script src="assets/js/slick.js"></script>
<script type="text/javascript" src="assets/js/init.js"></script>

</body>
</html>
