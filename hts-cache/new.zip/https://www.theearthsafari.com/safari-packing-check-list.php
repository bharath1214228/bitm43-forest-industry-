<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta tag properties start here -->
  <meta charset="utf-8">

  <meta name="language" content="english">
	<meta http-equiv="content-language" content="en">

	<meta name="google-site-verification" content="qYC3doxIvybN5KSFiBXT8IohYU9A9Wmer1u2CG7h110" />

	<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
	<meta name="robots" content="NOODP">
	<meta name="robots" content="index, follow" />
	<meta name="DC.title" content="Best African Safari & Indian Tiger Safari" >

  <meta name="description" content="Safari is a separate sport altogether and there is a special code to be observed for having a proper safari. Get a comprehensive packing check list to ensure you have a great safari trip including Safari Gear, Safari Luggage, Saffari supplies and equipment." />
	<meta name="keywords" content="safari packing list,safari equipment checklist,safari supplies checklist,theearthsafari.com" />

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Meta tag properties end here -->
  <title>Safari Packing Checklist</title>

  <!-- jQuery library file -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
   
  <base href="" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

	<!--[if lt IE 9]>
		<script src="assets/js/html5shiv.js"> </script>
	<![endif]-->
	<link rel="publisher" href="https://plus.google.com/+Theearthsafaritours"/>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
	<!-- CSS file -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css" />
	<link rel="stylesheet" href="assets/css/slick.css">
	<link rel="stylesheet" type="text/css" media="screen, projection" href="assets/css/main.css" />
	<link rel="stylesheet" href="assets/css/media.css">
</head>

<body class="inner">

<noscript>
<div class="popup-box" style="z-index: 99999999999;"></div>
	<div class="popup-box-container" style="z-index: 99999999999;">
  	<img alt="The Earth Safari" src="assets/img/the-earth-safari-logo.png" style="float:left;" />
    <div class="popup-divider">&nbsp;</div>
    <div class="popup-righ-panel">
    	<span class="popup-heading">Warning!</span>
    	<span class="popup-text">It appears that JavaScript is disabled in your web browser. Please enable it and refresh page to have full system functionality. For instructions on how to enable javascipt in your browser: <a href="http://www.activatejavascript.org/" target="_blank" style="text-decoration: none;" rel="follow" >Click Here</a>.</span>
    </div>
  </div>
</noscript>
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-2 logo"><a href="https://www.theearthsafari.com/"><img src="assets/img/the-earth-safari-logo.png" alt=""/></a></div>
			
			<div class="col-md-10 rightCol">
				<p class="tagline">Inspirational Safaris in India & Africa</p>
				<nav>
					<div class="top">
						<form id="region-selector" name="region_select" action="region.php" method="POST">
							<input type="hidden" name="page" value="http://www.theearthsafari.com/safari-packing-check-list.php">
															<input type="radio" name="r-selector" value="2" id="africa" onclick="this.form.submit()" style="display: none;">
								<label for="africa">Visit Africa</label>
													</form>

						<a class="menuToggle" href="javascript:;"><i class="fa fa-bars"></i></a>
						<ul>
							<li><a href="https://www.theearthsafari.com/">Home</a></li>
							<li><a href="https://www.theearthsafari.com/about-us">About Us</a></li>
							<li><a href="https://www.theearthsafari.com/client-testimonials">Client testimonials</a></li>
							<li><a href="https://www.theearthsafari.com/contact-us">Contact</a></li>
							<li><a href="https://www.theearthsafari.com/blog">Blog</a></li>
							<li><a href="tel:+91 8447870008">CALL: +91 8447870008</a></li>
						</ul>
					</div><!---End of top-->
					
					<div class="exploreDestination">
						<ul  class="exploreLinkks">
														<li>Explore By : </li>
							<li><a href="javascript:;">Destinations</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/destination/ranthambore-national-park">Ranthambore National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/bandhavgarh-national-park">Bandhavgarh National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kanha-national-park">Kanha National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/pench-national-park">Pench National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/tadoba-andhari-tiger-reserve">Tadoba-Andhari Tiger Reserve</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/jim-corbett-national-park">Jim Corbett National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/gir-forest-national-park">Gir Forest National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kaziranga-national-park">Kaziranga National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/sunderbans-national-park">Sunderbans National Park</a></li>
																	</ul>
							</li>
							<li><a href="javascript:;">Interest</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/interest/tiger-safari-india">Tiger Safari India</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-high-end-luxury-safaris">India High End Luxury Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-short-duration-safaris">India Short Duration Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-culture-and-heritage-tours">India Culture and Heritage Tours</a></li>
																	</ul>
							</li>
							<li><a href="https://www.theearthsafari.com/private-safari.php">Private Safari</a></li>
							<li><a href="https://www.theearthsafari.com/group-safari.php">Group Safari</a></li>
						</ul>
					</div><!--end  of exploreDestination-->
				</nav>
			</div>
		</div><!-- End of row -->
	</div><!-- End of container-->
</header>

<section class="masterSection staticPage">
	<div class="container">
		<div class="grayBg margin-top-50">
			<div class="row safariList">
				<div class="col-md-9">
					<div class="title"><h2>Safari Packing Check List</h2></div>
					
					<p class="profilePic"><img src="assets/img/Safari-luggage.jpg" alt=""/></p>
					<p>Space will be at a premium on your international flight, light aircraft transfers and safari vehicle so with that in mind, the safari packing list below will help you to pack only the necessary and correct items.</p>
					<p>It may look long at first glance but depending on your personal circumstances and the type of trip you are going on some of the items won't be applicable to you and you can safely ignore them.</p>
					<p>The safari packing list is based on the advice and recommendations from all the trip reports over the year.</p>
					<h5 class="text-orange clear">Safari Gear</h5>
					
					<ul class="bulletPoints">
						<li>Safari Hats</li>
						<li>Clothing in neutral colours: khaki, light brown/green, tan. Avoid bright colours & white for improved game viewing.</li>
						<li>A safari jacket is a very handy accessory to take with on your trip.</li>
						<li>Comfortable non-synthetic short- and long sleeved safari shirts</li>
						<li>Comfortable non-synthetic shorts and long trousers</li>
						<li>Pyjamas</li>
						<li>Swimming costume</li>
						<li>Flip-flops or sport sandals</li>
						<li>Comfortable safari hiking/walking shoes (not white). These are very important on a walking safari.</li>
						<li>Pairs of socks</li>
						<li>Extra shoelace</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Safari Supplies</h5>
					<p>Some of these supplies might be available in the first aid kit that every safari company should carry but make sure before leaving them off your safari packing list.</p>
					<ul class="bulletPoints">
						<li>Insect repellent/ Mosquito Coil (do not use coils in a tent)</li>
						<li>Sunblock and after sun lotion</li>
						<li>A travel towel is light and takes very little space</li>
						<li>Skin cream</li>
						<li>Malaria tablets (very important)</li>
						<li>Body soap/shower gel</li>
						<li>Sunglasses - make sure they have polarised lenses</li>
						<li>Biological Water Filtration Bottle or you can stick to the bottled water</li>
						<li>Wet wipes/hand sanitizer or no-water/antibacterial soap – very handy in the safari vehicle.</li>
						<li>Pocket Knife</li>
						<li>Small scissors</li>
						<li>Toothbrush/toothpaste/dental floss</li>
						<li>2-in-1 shampoo/conditioner</li>
						<li>Tweezers</li>
						<li>Lip balm</li>
						<li>Q-tips & cotton balls</li>
						<li>Razor & shaving cream/gel</li>
						<li>Sanitary requirements (shops are sometimes few and far between, and very basic)</li>
						<li>Contact lens solution & extra set of disposable lenses</li>
						<li>Band aids & moleskin</li>
						<li>Vitamins</li>
						<li>Painkiller</li>
						<li>Antiseptic cream</li>
						<li>Motion sickness tablets</li>
						<li>Anti-diarrhoea medicine</li>
						<li>Re-hydration salts</li>
						<li>Pen/pencil</li>
						<li>Small unbreakable mirror</li>
						<li>Plastic bags (wet washing/muddy shoes/organise clothes in suitcase)</li>
						<li>Deck of cards/travel size game</li>
						<li>Book to read between game viewing and other leisure time</li>
						<li>Cold/flu tablets</li>
						<li>Allergy remedy</li>
						<li>Some people take a basic antibiotic in case</li>
						<li>Prescribed medicine (enough to last your trip)</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Safari Luggage</h5>
					<ul class="bulletPoints">
						<li>The thing to remember when choosing safari luggage is mobility. You will probably be moving between several different modes of transport (airplanes, cars, light aircraft, trucks, boats) so plan accordingly.</li>
						<li>Suitcases with wheels don't work very well in the jungles but they are adequate if you don't mind carrying them. (A good safari company will probably have someone on hand to carry your luggage for you).</li>
						<li>A daypack is very handy to transport the items you need while driving around in the safari vehicle or walking through the bush.</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Safari Equipment</h5>
					<ul class="bulletPoints">
						<li>Safari Binoculars. Essential for a successful trip. No safari packing list is complete without them.</li>
						<li>Flashlight or headlamp.</li>
						<li>Cameras, Lenses, Memory Cards & Film (can be expensive and/or difficult to obtain) & extra flash batteries and lens cleaner.</li>
						<li>Small bean bag to substitute a tripod.</li>
						<li>Sleeping Bag if on a camping safari (may be supplied by safari company so check first).</li>
						<li>Travel pillow, or you can use your polar fleece/windbreaker.</li>
						<li>Small calculator (or if you're taking your mobile phone) for currency calculations.</li>
						<li>Money belt.</li>
						<li>Washing powder/travel soap for laundry.</li>
						<li>Plug adaptors.</li>
						<li>Lighter/waterproof matches.</li>
						<li>Travel alarm clock.</li>
						<li>Mini combination locks (keys get lost).</li>
						<li>Mini sewing kit.</li>
					</ul>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">Documents</h5>
					<ul class="bulletPoints">
						<li>Passport & correct visas.</li>
						<li>Emergency phone numbers</li>
						<li>Travel insurance policy</li>
						<li>Guide books covering the area you're visiting – it should include animals/birds pages for easy identification.</li>
						<li>Your itinerary</li>
						<li>Addresses and mobile numbers (postcards/e-mails/texts).</li>
						<li>Any vaccinations certificates.</li>
						<li>Phone card and international access numbers.</li>
						<li>Extra passport photos.</li>
						<li>Copy of your passport, kept in a separate place than your passport.</li>
						<li>Copy of marriage certificate, if applicable especially if you recently tied the knot.</li>
						<li>Medical history.</li>
						<li>Copies of prescriptions.</li>
						<li>Small stickers to label your used films.</li>
					</ul>
					<p>&nbsp;</p>
					
					<p>Follow this safari packing list and you will never have to worry about the frustration of leaving something behind or taking something that you won't need on your Jungle safari.</p>
					
				</div><!---End of col-sm-8-->
				
				<div class="col-md-3">
	<form class="newsLetter" type="post">
		<input type="email" name="newsletter" id="newsletter" placeholder="Enter your email address" />
		<button type="button" name="button" id="nl-submit">
			<span id="text"><i class="fa fa-check-square-o"></i></span>
			<span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
		</button>
	</form>
	
	<p class="saranVaid"><a href="http://www.saranvaid.com" target="_blank" rel="nofollow"><img src="assets/img/saran-vaid-img.jpg" alt=""></a></p>
</div><!---End of col-sm-3-->				
			</div><!---End of row-->
		<!--end of grayBg-->
	</div>
</section>

<footer>
	<div class="container">
		<p class="membership"><a href="https://www.theearthsafari.com/wildlife-associations.php" title="African Travel & Tourism Association"><img src="assets/img/memberships.jpg" alt="African Travel & Tourism Association" /></a></p>
		
		<div class="links">
			<h6>Information Bank</h6>

							<a href="https://www.theearthsafari.com/responsible-ecotourism.php">RESPONSIBLE ECOTOURISM</a> 
                <a href="https://www.theearthsafari.com/safari-code-of-conduct.php">SAFARI CODE OF CONDUCT</a>
                <a href="https://www.theearthsafari.com/destination/ranthambore-national-park">RANTHAMBORE NATIONAL PARK</a>
                <a href="https://www.theearthsafari.com/interest/tiger-safari-india">TIGER SAFARI INDIA</a>
                <a href="https://www.theearthsafari.com/wildlife-photography-tips.php">WILDLIFE PHOTOGRAPHY TIPS</a> 
                <a href="https://www.theearthsafari.com/checklist-of-birds-of-india.php">CHECKLIST OF BIRDS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/popular-animal-species-of-india.php">POPULAR ANIMAL SPECIES OF INDIA</a> 
                <a href="https://www.theearthsafari.com/safari-packing-check-list.php">SAFARI PACKING CHECK LIST</a>
                <a href="https://www.theearthsafari.com/indian-wildlife-map-table.php">INDIAN WILDLIFE MAP TABLE</a>
                <a href="https://www.theearthsafari.com/list-of-tiger-reserves-in-india.php">LIST OF TIGER RESERVES IN INDIA</a> 
                <a href="https://www.theearthsafari.com/india-wildlife-experience.php">INDIAN WILDLIFE EXPERIENCE</a>
                <a href="https://www.theearthsafari.com/destination/kenya">KENYA SAFARI TOURS</a>
                <a href="https://www.theearthsafari.com/destination/tanzania">TANZANIA SAFARI TOURS</a> 
                <a href="https://www.theearthsafari.com/forests-of-india.php">FORESTS OF INDIA</a> 
                <a href="https://www.theearthsafari.com/india-quick-facts.php">INDIA QUICK FACTS</a> 
                <a href="https://www.theearthsafari.com/tips-for-travel-in-india.php">TIPS FOR TRAVEL IN INDIA</a>
                <a href="https://www.theearthsafari.com/india-visa-info.php">INDIA VISA INFO</a>
		  
		</div><!---end of informationBank-->
		
		<div class="links">
			<h6>About The Earth Safari</h6>
			<a href="https://www.theearthsafari.com/">HOME</a>
			<a href="https://www.theearthsafari.com/about-us">ABOUT US</a>
			<a href="https://www.theearthsafari.com/client-testimonials">CLIENT TESTIMONIALS</a>
			<a href="https://www.theearthsafari.com/contact-us">CONTACT US</a>
			<a href="https://www.theearthsafari.com/terms">TERMS &amp; CONDITIONS</a>
			<a href="https://www.theearthsafari.com/sitemap.xml">XML SiteMap</a>
			<a href="https://www.theearthsafari.com/sitemap.html">HTML Site Map</a>
		</div><!---end of informationBank-->
		
		<div class="links">
			<div class="row">
				<div class="col-xs-9 disclaimer"><span>Disclaimer</span>: THE EARTH SAFARI is not liable for any errors or omissions. All pricing is indicative and subject to exchange rate fluctuations.</div>
				<div class="col-xs-3 media">
					<a href="https://plus.google.com/115282885713632754730" target="_blank" rel="nofollow" title="The Earth Safari Google+ Page"><i class="fa fa-google-plus"></i></a>
					<a href="https://www.facebook.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Facebook Page"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Twitter Page"><i class="fa fa-twitter"></i></a>
					<a href="https://www.theearthsafari.com/blog" target="_blank" title="The Earth Safari Blog"><i class="fa fa-wordpress"></i></a>
				</div>
			</div><!---End of row-->
		</div>
		
		<div class="copyright">Copyright &copy; 2011 - 2022 TheEarthSafari.com</div>
	</div>
</footer>

<div class="enquireBox na">
    <a class="toggle" href="javascript:;">Quick Enquiry <i class="fa fa-angle-double-down"></i></a>
    <h4>Send Your Enquiry now</h4>
    <form class="enquiry">
        <div class="enquiry-message"></div>
        <input type="text" name="name" id="name" class="form-control" placeholder="Name"/>
        <input type="email" name="email" id="email" class="form-control" placeholder="Email"/>
        <input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone"/>
        <textarea name="query" id="query" class="form-control" placeholder="Message"></textarea>
        <button type="button" id="enquiry-submit">
            <span id="text">Submit</span>
            <span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
        </button>
    </form>
</div>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37106525-1']);
  _gaq.push(['_setDomainName', 'theearthsafari.com']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Google Code for Remarketing Tag -->
<!--
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
-->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 972714909;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/972714909/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery("#enquiry-submit").click(function() {
        jQuery("#enquiry-submit #text").hide();
        jQuery("#enquiry-submit #loader").show();
        var from = 1;
        var data = jQuery(".enquiry").serialize();
            jQuery.ajax
            ({
            url: 'ajax/email-query.php?'+data,
            dataType: 'html',
            success: function(msg)
            {
                jQuery(".enquiry-message").show();
                jQuery(".enquiry-message").html(msg);
                jQuery("#enquiry-submit #text").show();
                jQuery("#enquiry-submit #loader").hide();
                if (msg == '<span id="success">Thank you for contact with The Earth Safari.</span>') {
                    jQuery("#name").val("");
                    jQuery("#email").val("");
                    jQuery("#phone").val("");
                    jQuery("#query").val("");
                }
                jQuery(".enquiry-message").delay(3000).hide(1000);
            }
        });
        return false;
    });
    jQuery("#nl-submit").click(function() {
        jQuery("#nl-submit #text").hide();
        jQuery("#nl-submit #loader").show();
        var emails = jQuery('#newsletter').val();
        jQuery.ajax
        ({
            type: 'POST',
            url: 'ajax/newsletter.php',
            data: {email:emails},
            dataType: 'html',
            success: function(msg)
            {
                jQuery("#nl-submit #text").show();
                jQuery("#nl-submit #loader").hide();
                jQuery(".newsletter-popup").show("slow");
                jQuery(".newsletter-popup").html(msg);
                jQuery("#newsletter").val('');
                jQuery(".close").click(function () {
                    jQuery(".newsletter-popup").hide("slow");
                });
            }
        });
    });
});
</script>

<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
  d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
  _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
  $.src='//v2.zopim.com/?1ltJ36Z0ARzUAnTSXmu2o4RKs2ndLWHU';z.t=+new Date;$.
  type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->

<script async src="//www.google.com/recaptcha/api.js"></script>

<script>
function onSubmit(token) {
    $("#enquiryForm").submit();
    return true;
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script type="text/javascript">
$().ready(function() {
  $("#enquiryForm").validate({
    rules: {
      name: "required",
      email: {
        required: true,
        email: true
      },
      phone: {
        required: true,
        minlength: 9
      },
      nationality: "required",
      city: "required",
      adult: "required",
      age_children: {
        required: {
            depends: function() {
              return $("#children").val()
            }
        }
      },
      curr_date: "required",
      month: "required",
      year: "required",
      duration: "required"
    },
    submitHandler: function (form) {
        if (grecaptcha.getResponse()) {
                // 2) finally sending form data
                form.submit();
        }else{
                // 1) Before sending we must validate captcha
            grecaptcha.reset();
            grecaptcha.execute();
        }           
    }
  });
});
</script>
<!--..........Javascript Libraries Start Here..........-->	
<script src="assets/js/slick.js"></script>
<script type="text/javascript" src="assets/js/init.js"></script>

</body>
</html>
