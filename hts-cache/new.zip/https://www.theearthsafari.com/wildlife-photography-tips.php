<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta tag properties start here -->
  <meta charset="utf-8">

  <meta name="language" content="english">
	<meta http-equiv="content-language" content="en">

	<meta name="google-site-verification" content="qYC3doxIvybN5KSFiBXT8IohYU9A9Wmer1u2CG7h110" />

	<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
	<meta name="robots" content="NOODP">
	<meta name="robots" content="index, follow" />
	<meta name="DC.title" content="Best African Safari & Indian Tiger Safari" >

  <meta name="description" content="Our expert Saran Vaid is a well known photographer in the field of wildlife photography. Get remarkable wildlife photography tips on behalf of the The earth Safari to get life time photo shoots of your safaris." />
	<meta name="keywords" content="photography tips,wildlife photography,tips,saran vaid" />

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Meta tag properties end here -->
  <title>Wildlife Photography Tips from Saran Vaid of TheEarthSafari.com</title>

  <!-- jQuery library file -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
   
  <base href="" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

	<!--[if lt IE 9]>
		<script src="assets/js/html5shiv.js"> </script>
	<![endif]-->
	<link rel="publisher" href="https://plus.google.com/+Theearthsafaritours"/>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
	<!-- CSS file -->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css" />
	<link rel="stylesheet" href="assets/css/slick.css">
	<link rel="stylesheet" type="text/css" media="screen, projection" href="assets/css/main.css" />
	<link rel="stylesheet" href="assets/css/media.css">
</head>

<body class="inner">

<div class="popup-box"></div>

        <div class="popup-box-container">

	        <img src="https://www.theearthsafari.com/images/popup-logo.png" style="float:left;" />

		        <div class="popup-right-panel">

			                <span class="popup-heading">Where would you like to travel? </span>  <span class="popup-text"><font size="2">(You can change the region from the top menu anytime.)</font></span><span class="popup-form"><br/>
					                </span>

							                <span class="popup-form">

									                <form name="region_select" action="https://www.theearthsafari.com/region.php" method="POST">

											            <input type="hidden" name="page" value="http://www.theearthsafari.com/wildlife-photography-tips.php" />

												                  <div style="float: left; width: 40%" class="popup-heading"><input type="radio" name="r-selector" id="r-select" value="1" /> India</div>

														                <div style="float: right; width: 60%" class="popup-heading"><input type="radio" name="r-selector" id="r-select" value="2" /> Africa</div>

																              <br/><br/><br/>

																	                    <input type="submit" name="submit" class="popup-button" value="Submit" />

																			                </form>

																					          </span>

																						        </div>

																							    </div>
<noscript>
<div class="popup-box" style="z-index: 99999999999;"></div>
	<div class="popup-box-container" style="z-index: 99999999999;">
  	<img alt="The Earth Safari" src="assets/img/the-earth-safari-logo.png" style="float:left;" />
    <div class="popup-divider">&nbsp;</div>
    <div class="popup-righ-panel">
    	<span class="popup-heading">Warning!</span>
    	<span class="popup-text">It appears that JavaScript is disabled in your web browser. Please enable it and refresh page to have full system functionality. For instructions on how to enable javascipt in your browser: <a href="http://www.activatejavascript.org/" target="_blank" style="text-decoration: none;" rel="follow" >Click Here</a>.</span>
    </div>
  </div>
</noscript>
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-2 logo"><a href="https://www.theearthsafari.com/"><img src="assets/img/the-earth-safari-logo.png" alt=""/></a></div>
			
			<div class="col-md-10 rightCol">
				<p class="tagline">Inspirational Safaris in India & Africa</p>
				<nav>
					<div class="top">
						<form id="region-selector" name="region_select" action="region.php" method="POST">
							<input type="hidden" name="page" value="http://www.theearthsafari.com/wildlife-photography-tips.php">
															<input type="radio" name="r-selector" value="1" id="india" onclick="this.form.submit()" style="display: none;">
								<label for="india">Visit India</label>
													</form>

						<a class="menuToggle" href="javascript:;"><i class="fa fa-bars"></i></a>
						<ul>
							<li><a href="https://www.theearthsafari.com/">Home</a></li>
							<li><a href="https://www.theearthsafari.com/about-us">About Us</a></li>
							<li><a href="https://www.theearthsafari.com/client-testimonials">Client testimonials</a></li>
							<li><a href="https://www.theearthsafari.com/contact-us">Contact</a></li>
							<li><a href="https://www.theearthsafari.com/blog">Blog</a></li>
							<li><a href="tel:+91 8447870008">CALL: +91 8447870008</a></li>
						</ul>
					</div><!---End of top-->
					
					<div class="exploreDestination">
						<ul  class="exploreLinkks">
														<li>Explore By : </li>
							<li><a href="javascript:;">Destinations</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/destination/ranthambore-national-park">Ranthambore National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/bandhavgarh-national-park">Bandhavgarh National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kanha-national-park">Kanha National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/pench-national-park">Pench National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/tadoba-andhari-tiger-reserve">Tadoba-Andhari Tiger Reserve</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/jim-corbett-national-park">Jim Corbett National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/gir-forest-national-park">Gir Forest National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kaziranga-national-park">Kaziranga National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/sunderbans-national-park">Sunderbans National Park</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/kenya">Kenya</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/tanzania">Tanzania</a></li>
																			<li><a href="https://www.theearthsafari.com/destination/south-africa">South Africa</a></li>
																	</ul>
							</li>
							<li><a href="javascript:;">Interest</a>
								<ul>
																			<li><a href="https://www.theearthsafari.com/interest/tiger-safari-india">Tiger Safari India</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/africa-safari-">Africa Safari </a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-high-end-luxury-safaris">India High End Luxury Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-short-duration-safaris">India Short Duration Safaris</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/africa-high-end-luxury-safaris-">Africa High End Luxury Safaris </a></li>
																			<li><a href="https://www.theearthsafari.com/interest/great-annual-wildebeest-migration">Great Annual Wildebeest Migration</a></li>
																			<li><a href="https://www.theearthsafari.com/interest/india-culture-and-heritage-tours">India Culture and Heritage Tours</a></li>
																	</ul>
							</li>
							<li><a href="https://www.theearthsafari.com/private-safari.php">Private Safari</a></li>
							<li><a href="https://www.theearthsafari.com/group-safari.php">Group Safari</a></li>
						</ul>
					</div><!--end  of exploreDestination-->
				</nav>
			</div>
		</div><!-- End of row -->
	</div><!-- End of container-->
</header>

<section class="masterSection staticPage">
	<div class="container">
		<div class="grayBg margin-top-50">
			<div class="row safariList">
				<div class="col-md-9">
					<div class="title"><h2>Wildlife Photography Tips</h2></div>
					
					<p class="profilePic"><img src="assets/img/Wildlife-Photography-Tips.jpg" alt=""/></p>
					<p>Nature and wildlife photography is a photographic discipline that encompasses a wide range of subject matter. Some nature and wildlife photographers focus on beautiful pictures of impressive landscapes...even stitching photos together to create wide, stunning panoramic images.</p>
					<p>Most wildlife photographers, though, have to go to places like parks, free-roaming zoos, and wildlife reserves in search of wildlife subjects to photograph.</p>
					<p>Those photographers who are lucky enough to live near game reserves or large lakes are especially blessed with great opportunities to capture photos of animals in their own natural habitat.</p>
					<p>There is something immensely satisfying about photographing wildlife and nature. In many cases, it requires a great deal of patience and persistence to get the image that you want...sometimes the only way is a lot of trial and error. Animals and wildlife don’t pose for the camera or take direction, so it can be very challenging to get a great shot. Sometimes, it's simply a matter of good luck more than anything else!</p>
					<p>Wildlife photography also requires photographers to develop their skills and knowledge of their tools of the trade. Skills such as adding or changing lenses for the proper focal length...depending on whether they are photographing a bumble bee or a moose. Even the basics such as learning to adjust the flash, ISO, and exposure time properly to capture images in less than perfect lighting conditions, such as in a dimly lit forest.</p>
					<p>Probably the most compelling reason people are drawn to photographing nature and wildlife is that it provides an opportunity to connect with our natural world.</p>
					<p>&nbsp;</p>
					
					<h5 class="text-orange">These wildlife photography tips will help you take better animal pictures on your safari.</h5>
					<h6 class="text-yellow">Lighting :</h6>
					<p>Top lighting effect is not ideal for photographing wildlife or landscapes; low side lighting is better for showing detail in wildlife subjects and creates more interesting shadows in landscapes. So it’s important to make full use of the light at sunrise and again in the later afternoon. While most wildlife photographs are taken with the sunlight behind the photographer thereby fully lighting the subject, it should be remembered that some spectacular images can be taken using side or back lighting, particularly using the warm glow created at sunrise and sunset. See our Tanzania Image Gallery depicting the various tactics used while photographing in the wild. 
					
					<h6>Exposure :</h6>
					<p>Correct exposure is the key to successful photography and modern cameras, with their built-in metering systems, go a long way to reducing the possibility of incorrect exposure. However there are situations where even the most complex metering system is going to struggle. A good example would be a white bird on very dark background, the meter is likely to try and expose correctly for the background, which will over exposure the bird. This is where a good understanding of your camera comes into play. Most SLR cameras will have a +/- (over/under exposure) override and, in the situation outlined above, you will need to under expose by about 1 to 2 stops to ensure correct exposure. The same effect can be obtained by doubling the (ISO) film speed i.e. 100 to 200ISO, but remember to change these setting back before moving on. In any situation where you are not sure about the exposure you can always bracket. For example if your metering reading is 1/60th at f8, take one picture at this setting, then two further exposures at 1/60th at f11 and 1/60th at f5.6, to do this you may have to switch the camera to manual mode or use the +/- override. See our Kenya Safari Photo Gallery depicting the usage of these various settings.

					<h6>Depth of Field :</h6>
					<p>When the camera lens is focused to give a sharp image of a particular subject, other objects, closer or further away, do not appear equally as sharp. They can be made sharp by ‘stopping down’ using a smaller ‘f stop’. The higher the ‘f stop’ number, the more depth of field is available. It should be remembered that as you stop down your shutter speed will get slower and subject movement will become more of a problem.</p>
					<p>‘Stopping down’ is important when photographing plants, insects and other small subjects as it reduces out of focus distractions. The opposite procedure can be used to help isolate your main centre of interest by making background or foreground distractions go out of focus.</p>
					<p>Don’t forget that you can check the depth of field created by any given ‘f stop’, by using the depth of field button on your camera, This button allows you to preview the finished image though the view finder and to make adjustments to your own satisfaction prior to making any exposure.</p>

					<h6>Shutter Speed :</h6>
					<p>Different shutter speeds produce varying effects with regard to subject blur and camera shake. Fast shutter speeds are desirable for stopping movement, such as flying birds and eliminating camera shake. It is worth remembering that is some situations movement of the subject during exposure can often result in a pleasing pictorial image.

					<h6>Composition :</h6>
					<p>The automation of modern cameras has taken away most of the technical pit falls of photography. Composition is the tool by which we can express our artistic thoughts and so demands an active input. It is therefore in your own interest to be fully conversant with the factors relating to good composition. Many newcomers to photography tend to produce all their images in a horizontal format, partly because of the layout of modern cameras which lend themselves to this shape. Remember they work equally well when turned through 90 degrees to a vertical format. 
					<p>Changing your viewpoint can totally alter your image, we get used to seeing everything from a standing position, by kneeling or even lying down you are going to show an angle that we are not familiar with, which will often produce a more unusual result. A wide-angle lens used in this way can create some very interesting effects.
					<p>Think about where you are going to place the main point of interest in your image, avoid placing your subject in the centre of the frame. If it’s an animal, it needs room to move or to look into the picture space. A flying bird should be flying into the picture rather than out of it. Always attempt to get a ‘highlight’ in the eye, as this gives life to the subject. Do pay attention to the horizon line, particularly in landscapes and avoid splitting your picture in half, think in ‘thirds’. Zoom lenses have become a great asset by allowing control over subject size and perspective, with out moving the camera position.
					<p>By utilising a range of lenses it is often possible to secure an interesting sequence of images of an animal. The longest lenses for a close up of the head, through to a wide angle, which will show the landscape.

					<h6>Blur The Background :</h6>
					<p>This is one of those wildlife photography tips that is particularly handy on a safari because often there is vegetation in the image that is distracting and blurring it gives more emphasis to the wildlife subject. If you are photographing a herd of elephant you might want to make sure that they are all in focus so you will try and limit the blurring present in the scene. The fancy name to describe the portion of the scene that appears sharp throughout the whole image is depth of field. But more important then knowing what it's called is knowing how to control it. Three factors affect depth of field: the aperture, the focal length of the lens, and the camera to subject distance. 
					<p>Of these three, the aperture is the one that you have the most control over on a safari. A big aperture opening (e.g f/4.5) will lead to more background blurring while a small aperture (e.g f/22) will lead to the overall scene being sharper. 
					<p>Remember which is which by matching up the similar first letters, so Big = Blurred and Small = Sharp. That tends to limit the confusion to a minimum. Make sure you know how to change the aperture opening on your gear before you go on safari.

					<h6>Focus on the Eyes :</h6>
					<p>A wildlife photograph where the subjects eyes are out of focus loses a lot of its appeal. The reason is probably that we as humans are naturally drawn towards looking at eyes and if you can't see them due to blurring it's a little jarring. Whatever the reason, always keep the eyes of your subject in focus and if you can capture the sun glinting in the pupil you get bonus points because that really livens up the picture.

					<h6>Create Active Space :</h6>
					<p>Leave space for animals to move into when you frame your images. This may seem like one of the obvious wildlife photography tips but in the heat of the moment it's easy to forget the basics.

					<h6>Use a Beanbag or Window Mounted Tripod :</h6>
					<p>Hand holding your camera in safari wildlife photography is often a luxury because of the large lenses which magnify every vibration and the low light of dawn and dusk when the subjects are most active. So some kind of rest to lean your camera equipment on is a very good idea to keep your pictures pin sharp. 
					<p>Most of your photography on safari will be done from inside a vehicle so a tripod to stabilize your camera is impractical. A beanbag does the job very well and it's very quick to set up. Simply place it on a convenient surface, rest your camera lens on it and click away. In open safari vehicles, a clamp onto an armrest or seat back is just what the doctor ordered to minimize blur. In closed vehicles, you can make use of window mounts. It's a little more inconvenient than a bean bag because you need to affix the camera to the mount each time you want to take a photo (the mount stays fixed to the window while you drive) but it does the job well.

					<h6>Know Your Gear Before You Go :</h6>
					<p>Buying or renting a new camera and/or lens shortly before going on safari is not a good idea if you don't have time to practice and get some experience with it.
					<p>A safari is not the best time to learn because wildlife is unpredictable and often they aren't going to give you enough time to fiddle with the camera settings and setup before they disappear into the undergrowth. So you need a reasonable amount of practice with your camera and lens so that you can do things quickly. Also, it will be a huge disappointment if you go all the way to India and Africa and your safari pictures are not as good as they should be because you are inexperienced with your equipment. A safari is often a one time trip so you won't get any second chances. Make sure you are well acquainted with your equipment before you go.
					<p>Visit your local zoo or safari park to prepare. Pets also make excellent subjects to test your photographic skills on.

					<h6>Notes :</h6>
					<p>Either date and or number each film, using an indelible felt tip pen. Then, by keeping details notes of what you saw each day, you will then be able to accurately caption your photographs.

					<h6>Code of Conduct :</h6>
					<p>It should always be remembered that the welfare of the subject is more important the photograph. Do not go too close, Do not use flash if it might disturb the subject, Do not make lots of noise. Do not discard any form of litter. Take only pictures leave only memories!

					<p class="text-orange"><strong>The beauty of the natural world inspires us and frequently takes our breath away. So when we can capture that feeling or effect with beautiful nature photography, it's just an incredible sense of achievement!</strong></p>
					
				</div><!---End of col-sm-8-->
				
				<div class="col-md-3">
	<form class="newsLetter" type="post">
		<input type="email" name="newsletter" id="newsletter" placeholder="Enter your email address" />
		<button type="button" name="button" id="nl-submit">
			<span id="text"><i class="fa fa-check-square-o"></i></span>
			<span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
		</button>
	</form>
	
	<p class="saranVaid"><a href="http://www.saranvaid.com" target="_blank" rel="nofollow"><img src="assets/img/saran-vaid-img.jpg" alt=""></a></p>
</div><!---End of col-sm-3-->				
			</div><!---End of row-->
		<!--end of grayBg-->
	</div>
</section>

<footer>
	<div class="container">
		<p class="membership"><a href="https://www.theearthsafari.com/wildlife-associations.php" title="African Travel & Tourism Association"><img src="assets/img/memberships.jpg" alt="African Travel & Tourism Association" /></a></p>
		
		<div class="links">
			<h6>Information Bank</h6>

							<a href="https://www.theearthsafari.com/responsible-ecotourism.php">RESPONSIBLE ECOTOURISM</a>
                <a href="https://www.theearthsafari.com/safari-code-of-conduct.php">SAFARI CODE OF CONDUCT</a>
                <a href="https://www.theearthsafari.com/wildlife-photography-tips.php">WILDLIFE PHOTOGRAPHY TIPS</a>
                <a href="https://www.theearthsafari.com/destination/kenya">KENYA SAFARI TOURS</a>
                <a href="https://www.theearthsafari.com/destination/tanzania">TANZANIA SAFARI TOURS</a> 
                <a href="https://www.theearthsafari.com/checklist-of-birds-of-india.php">CHECKLIST OF BIRDS OF INDIA</a>
                <a href="https://www.theearthsafari.com/popular-animal-species-of-india.php">POPULAR ANIMAL SPECIES OF INDIA</a>
                <a href="https://www.theearthsafari.com/safari-packing-check-list.php">SAFARI PACKING CHECK LIST</a>
                <a href="https://www.theearthsafari.com/indian-multilife-map-table.php">INDIAN WILDLIFE MAP TABLE</a>
                <a href="https://www.theearthsafari.com/list-of-tiger-reserves-in-india.php">LIST OF TIGER RESERVES IN INDIA</a>
                <a href="https://www.theearthsafari.com/india-wildlife-experience.php">INDIAN WILDLIFE EXPERIENCE</a>
                <a href="https://www.theearthsafari.com/forests-of-india.php">FORESTS OF INDIA</a>
                <a href="https://www.theearthsafari.com/india-quick-facts.php">INDIA QUICK FACTS</a>
                <a href="https://www.theearthsafari.com/tips-for-travel-in-india.php">TIPS FOR TRAVEL IN INDIA</a>
                <a href="https://www.theearthsafari.com/india-visa-info.php">INDIA VISA INFO</a>
                <a href="https://www.theearthsafari.com/popular-national-parks-of-kenya.php">POPULAR NATIONAL PARKS OF KENYA</a>
                <a href="https://www.theearthsafari.com/popular-national-parks-of-tanzania.php">POPULAR NATIONAL PARKS OF TANZANIA</a>
		  
		</div><!---end of informationBank-->
		
		<div class="links">
			<h6>About The Earth Safari</h6>
			<a href="https://www.theearthsafari.com/">HOME</a>
			<a href="https://www.theearthsafari.com/about-us">ABOUT US</a>
			<a href="https://www.theearthsafari.com/client-testimonials">CLIENT TESTIMONIALS</a>
			<a href="https://www.theearthsafari.com/contact-us">CONTACT US</a>
			<a href="https://www.theearthsafari.com/terms">TERMS &amp; CONDITIONS</a>
			<a href="https://www.theearthsafari.com/sitemap.xml">XML SiteMap</a>
			<a href="https://www.theearthsafari.com/sitemap.html">HTML Site Map</a>
		</div><!---end of informationBank-->
		
		<div class="links">
			<div class="row">
				<div class="col-xs-9 disclaimer"><span>Disclaimer</span>: THE EARTH SAFARI is not liable for any errors or omissions. All pricing is indicative and subject to exchange rate fluctuations.</div>
				<div class="col-xs-3 media">
					<a href="https://plus.google.com/115282885713632754730" target="_blank" rel="nofollow" title="The Earth Safari Google+ Page"><i class="fa fa-google-plus"></i></a>
					<a href="https://www.facebook.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Facebook Page"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/theearthsafari" target="_blank" rel="nofollow" title="The Earth Safari Twitter Page"><i class="fa fa-twitter"></i></a>
					<a href="https://www.theearthsafari.com/blog" target="_blank" title="The Earth Safari Blog"><i class="fa fa-wordpress"></i></a>
				</div>
			</div><!---End of row-->
		</div>
		
		<div class="copyright">Copyright &copy; 2011 - 2022 TheEarthSafari.com</div>
	</div>
</footer>

<div class="enquireBox na">
    <a class="toggle" href="javascript:;">Quick Enquiry <i class="fa fa-angle-double-down"></i></a>
    <h4>Send Your Enquiry now</h4>
    <form class="enquiry">
        <div class="enquiry-message"></div>
        <input type="text" name="name" id="name" class="form-control" placeholder="Name"/>
        <input type="email" name="email" id="email" class="form-control" placeholder="Email"/>
        <input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone"/>
        <textarea name="query" id="query" class="form-control" placeholder="Message"></textarea>
        <button type="button" id="enquiry-submit">
            <span id="text">Submit</span>
            <span id="loader" class="is-hidden"><i class="fa fa-spinner fa-spin"></i></span>
        </button>
    </form>
</div>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37106525-1']);
  _gaq.push(['_setDomainName', 'theearthsafari.com']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-- Google Code for Remarketing Tag -->
<!--
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
-->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 972714909;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/972714909/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<script type="text/javascript">
jQuery(document).ready(function() {
    jQuery("#enquiry-submit").click(function() {
        jQuery("#enquiry-submit #text").hide();
        jQuery("#enquiry-submit #loader").show();
        var from = 1;
        var data = jQuery(".enquiry").serialize();
            jQuery.ajax
            ({
            url: 'ajax/email-query.php?'+data,
            dataType: 'html',
            success: function(msg)
            {
                jQuery(".enquiry-message").show();
                jQuery(".enquiry-message").html(msg);
                jQuery("#enquiry-submit #text").show();
                jQuery("#enquiry-submit #loader").hide();
                if (msg == '<span id="success">Thank you for contact with The Earth Safari.</span>') {
                    jQuery("#name").val("");
                    jQuery("#email").val("");
                    jQuery("#phone").val("");
                    jQuery("#query").val("");
                }
                jQuery(".enquiry-message").delay(3000).hide(1000);
            }
        });
        return false;
    });
    jQuery("#nl-submit").click(function() {
        jQuery("#nl-submit #text").hide();
        jQuery("#nl-submit #loader").show();
        var emails = jQuery('#newsletter').val();
        jQuery.ajax
        ({
            type: 'POST',
            url: 'ajax/newsletter.php',
            data: {email:emails},
            dataType: 'html',
            success: function(msg)
            {
                jQuery("#nl-submit #text").show();
                jQuery("#nl-submit #loader").hide();
                jQuery(".newsletter-popup").show("slow");
                jQuery(".newsletter-popup").html(msg);
                jQuery("#newsletter").val('');
                jQuery(".close").click(function () {
                    jQuery(".newsletter-popup").hide("slow");
                });
            }
        });
    });
});
</script>

<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
  d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
  _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
  $.src='//v2.zopim.com/?1ltJ36Z0ARzUAnTSXmu2o4RKs2ndLWHU';z.t=+new Date;$.
  type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->

<script async src="//www.google.com/recaptcha/api.js"></script>

<script>
function onSubmit(token) {
    $("#enquiryForm").submit();
    return true;
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script type="text/javascript">
$().ready(function() {
  $("#enquiryForm").validate({
    rules: {
      name: "required",
      email: {
        required: true,
        email: true
      },
      phone: {
        required: true,
        minlength: 9
      },
      nationality: "required",
      city: "required",
      adult: "required",
      age_children: {
        required: {
            depends: function() {
              return $("#children").val()
            }
        }
      },
      curr_date: "required",
      month: "required",
      year: "required",
      duration: "required"
    },
    submitHandler: function (form) {
        if (grecaptcha.getResponse()) {
                // 2) finally sending form data
                form.submit();
        }else{
                // 1) Before sending we must validate captcha
            grecaptcha.reset();
            grecaptcha.execute();
        }           
    }
  });
});
</script>
<!--..........Javascript Libraries Start Here..........-->	
<script src="assets/js/slick.js"></script>
<script type="text/javascript" src="assets/js/init.js"></script>

</body>
</html>
